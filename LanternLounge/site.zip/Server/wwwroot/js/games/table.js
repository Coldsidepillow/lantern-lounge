// A round table seen from above, shared by the card games. You sit at the bottom;
// the other players sit around the rim, clockwise from your left. Each game fills the middle.
import { h, SEAT_COLORS } from "../ui.js";

// Where the other players sit (percent of the table box), by how many people are playing.
const SPOTS = {
  1: [{ x: 50, y: 10 }],
  2: [{ x: 14, y: 30 }, { x: 86, y: 30 }],
  3: [{ x: 12, y: 52 }, { x: 50, y: 10 }, { x: 88, y: 52 }]
};

/** The other seats in the order they sit around the table, clockwise from your left. */
export function opponentSeats(you, count) {
  const out = [];
  for (let i = 1; i < count; i++) out.push((you + i) % count);
  return out;
}

function initial(name) { return ((name || "?").trim()[0] || "?").toUpperCase(); }

function fan(count) {
  const n = Math.min(count, 7);
  const wrap = h("div.tbl-fan");
  for (let i = 0; i < n; i++) wrap.appendChild(h("span.tbl-cb", { style: { "--i": String(i), "--n": String(n) } }));
  return wrap;
}

/**
 * opts.count     how many people sit at the table
 * opts.you       your seat number
 * opts.opponents [{ seat, name, bot, cards, note, turn, target, clickable, onClick }] in seat order
 * opts.centre    the node for the middle of the table
 * opts.mine      { name, turn, cards, note } for your own nameplate
 * opts.tone      "sea" | "prism": the colour of the cloth
 */
export function tableEl(opts) {
  const spots = SPOTS[Math.max(1, Math.min(3, opts.count - 1))];
  const box = h("div.tbl", { class: `tone-${opts.tone || "sea"} players-${opts.count}` },
    h("div.tbl-rim", h("div.tbl-felt")),
    h("div.tbl-centre", opts.centre));

  opts.opponents.forEach((o, i) => {
    const spot = spots[i] || spots[spots.length - 1];
    const classes = [o.turn ? "turn" : "", o.target ? "target" : "", o.clickable ? "clickable" : ""].join(" ");
    box.appendChild(h("div.tbl-seat", {
      class: classes, style: { left: spot.x + "%", top: spot.y + "%" },
      role: o.clickable ? "button" : null, tabindex: o.clickable ? 0 : null,
      "aria-label": `${o.name}${o.bot ? " (bot)" : ""}, ${o.cards} cards`,
      onclick: o.clickable ? o.onClick : null,
      onkeydown: o.clickable ? (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); o.onClick(); } } : null
    },
      h("div.tbl-av", { style: { background: SEAT_COLORS[o.seat % 4] } }, initial(o.name)),
      h("div.tbl-name", o.bot ? `🤖 ${o.name}` : o.name),
      fan(o.cards),
      h("div.tbl-count", `${o.cards} ${o.cards === 1 ? "card" : "cards"}`),
      o.note ? h("div.tbl-note", o.note) : null));
  });

  const me = opts.mine;
  box.appendChild(h("div.tbl-you", { class: me.turn ? "turn" : "" },
    h("div.tbl-av", { style: { background: SEAT_COLORS[opts.you % 4] } }, initial(me.name)),
    h("div", h("div.tbl-name", `${me.name} (you)`), me.note ? h("div.tbl-note", me.note) : null)));
  return box;
}
