// Draws the whole Hide & Seek maze once, in detail, onto a hidden canvas. The game then just
// copies the part you can see onto the screen each frame (so it stays fast on phones).
// Wood-plank halls, carpeted rooms, brick walls with torches, and props to hide behind.

export const BAKE = 48;   // pixels per tile on the hidden canvas

// A steady "random" number from a tile position, so the maze looks the same every time it is drawn.
function hash(x, y, k = 0) {
  let n = (Math.imul(x + 1, 374761393) + Math.imul(y + 1, 668265263) + Math.imul(k + 1, 2147483647)) | 0;
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

const HALL_WOOD = ["#3d3252", "#41364f", "#3a2f4c", "#443855"];
const OPEN_RUG = ["#6a3347", "#743b50"];
const SECRET_RUG = ["#245a63", "#2b6670"];

/** Returns { canvas, torches: [{ x, y }] } where torches are tile positions (centre of the lit floor tile). */
export function bakeMaze(map, W, H) {
  const T = BAKE;
  const canvas = document.createElement("canvas");
  canvas.width = W * T;
  canvas.height = H * T;
  const g = canvas.getContext("2d");
  const at = (x, y) => (x < 0 || y < 0 || x >= W || y >= H ? "#" : map[y * W + x]);
  const wallish = (x, y) => { const c = at(x, y); return c === "#" || c === "S"; };
  const openish = (x, y) => !wallish(x, y);

  // Which tiles are inside a room (an open 2 x 2 block can only be a room), and which rooms are secret.
  const room = new Int32Array(W * H).fill(-1);
  for (let y = 0; y < H - 1; y++) {
    for (let x = 0; x < W - 1; x++) {
      if (openish(x, y) && openish(x + 1, y) && openish(x, y + 1) && openish(x + 1, y + 1)) {
        for (const [dx, dy] of [[0, 0], [1, 0], [0, 1], [1, 1]]) room[(y + dy) * W + x + dx] = 0;
      }
    }
  }
  const secretRoom = new Uint8Array(W * H);
  let roomId = 0;
  for (let i = 0; i < W * H; i++) {
    if (room[i] !== 0) continue;
    const stack = [i], members = [];
    room[i] = ++roomId;
    let secret = false;
    while (stack.length) {
      const cur = stack.pop();
      members.push(cur);
      const x = cur % W, y = (cur / W) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy;
        const c = at(nx, ny);
        if (c === "S" || c === "D") secret = true;
        if (nx >= 0 && ny >= 0 && nx < W && ny < H && room[ny * W + nx] === 0) { room[ny * W + nx] = roomId; stack.push(ny * W + nx); }
      }
    }
    if (secret) for (const m of members) secretRoom[m] = 1;
  }

  const torches = [];

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const c = at(x, y);
      const px = x * T, py = y * T;
      if (c === "#" || c === "S") drawWall(x, y, px, py, c === "S");
      else drawFloor(x, y, px, py, c);
    }
  }
  // props go on last so their shadows sit on the floor
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      if (at(x, y) === "H") drawProp(x, y, x * T, y * T, secretRoom[y * W + x] === 1);
    }
  }
  // name plaques: each room is named after one of the four friends (reading order, top-left first)
  const NAMES = ["Nelly", "Kimmy", "Amanda", "Coley"];
  const sums = new Map();
  for (let i = 0; i < W * H; i++) {
    if (room[i] <= 0) continue;
    const s = sums.get(room[i]) || { x: 0, y: 0, n: 0 };
    s.x += (i % W) + 0.5; s.y += ((i / W) | 0) + 0.5; s.n++;
    sums.set(room[i], s);
  }
  [...sums.entries()].sort((a, b) => a[0] - b[0]).slice(0, 4).forEach(([, s], k) => {
    const cx = (s.x / s.n) * T, cy = (s.y / s.n) * T;
    const label = NAMES[k] + "'s room";
    g.save();
    g.font = `800 ${T * 0.3}px Nunito, sans-serif`;
    g.textAlign = "center"; g.textBaseline = "middle";
    const w = g.measureText(label).width + T * 0.3, hh = T * 0.42;
    g.fillStyle = "rgba(40,24,12,.78)";
    g.beginPath(); g.roundRect(cx - w / 2, cy - hh / 2, w, hh, hh / 2); g.fill();
    g.strokeStyle = "rgba(255,214,102,.8)"; g.lineWidth = 2; g.stroke();
    g.fillStyle = "#ffe9b0";
    g.fillText(label, cx, cy + 1);
    g.restore();
  });
  return { canvas, torches };

  // ---------- floors ----------
  function drawFloor(x, y, px, py, c) {
    const inRoom = room[y * W + x] > 0;
    if (inRoom) {
      const rug = secretRoom[y * W + x] ? SECRET_RUG : OPEN_RUG;
      g.fillStyle = rug[(x + y) % 2];
      g.fillRect(px, py, T, T);
      // woven pattern and a gold edge to the rug
      g.strokeStyle = "rgba(255, 224, 150, .22)"; g.lineWidth = 2;
      g.beginPath();
      g.moveTo(px + T / 2, py + T * 0.22); g.lineTo(px + T * 0.78, py + T / 2); g.lineTo(px + T / 2, py + T * 0.78); g.lineTo(px + T * 0.22, py + T / 2); g.closePath();
      g.stroke();
      g.fillStyle = "rgba(255, 224, 150, .35)";
      g.beginPath(); g.arc(px + T / 2, py + T / 2, 2.2, 0, Math.PI * 2); g.fill();
      if (room[y * W + x - 1] !== room[y * W + x]) { g.fillStyle = "rgba(255, 214, 102, .55)"; g.fillRect(px, py, 3, T); }
      if (room[y * W + x + 1] !== room[y * W + x]) { g.fillStyle = "rgba(255, 214, 102, .55)"; g.fillRect(px + T - 3, py, 3, T); }
      if (room[(y + 1) * W + x] !== room[y * W + x]) { g.fillStyle = "rgba(255, 214, 102, .55)"; g.fillRect(px, py + T - 3, T, 3); }
      if (y > 0 && room[(y - 1) * W + x] !== room[y * W + x]) { g.fillStyle = "rgba(255, 214, 102, .55)"; g.fillRect(px, py, T, 3); }
    } else {
      g.fillStyle = HALL_WOOD[(hash(x, y, 1) * HALL_WOOD.length) | 0];
      g.fillRect(px, py, T, T);
      // planks
      const horizontal = hash(x, y, 2) < 0.5;
      g.fillStyle = "rgba(0, 0, 0, .22)";
      for (let k = 1; k < 4; k++) {
        if (horizontal) g.fillRect(px, py + (T / 4) * k - 1, T, 2); else g.fillRect(px + (T / 4) * k - 1, py, 2, T);
      }
      g.fillStyle = "rgba(255, 255, 255, .05)";
      for (let k = 0; k < 4; k++) {
        if (horizontal) g.fillRect(px, py + (T / 4) * k, T, 2); else g.fillRect(px + (T / 4) * k, py, 2, T);
      }
      // a knot or two
      if (hash(x, y, 3) < 0.35) {
        g.fillStyle = "rgba(0, 0, 0, .18)";
        g.beginPath(); g.ellipse(px + hash(x, y, 4) * T * 0.7 + T * 0.15, py + hash(x, y, 5) * T * 0.7 + T * 0.15, 5, 3, 0, 0, Math.PI * 2); g.fill();
      }
    }

    if (c === "D") {
      // an open doorway: wooden frame with a warm light
      g.fillStyle = "rgba(255, 200, 100, .16)"; g.fillRect(px, py, T, T);
      g.strokeStyle = "#c58a3b"; g.lineWidth = 4;
      g.strokeRect(px + 3, py + 3, T - 6, T - 6);
      g.strokeStyle = "rgba(255, 230, 150, .7)"; g.lineWidth = 1.5;
      g.strokeRect(px + 7, py + 7, T - 14, T - 14);
    }

    // shadows cast by the walls around this tile
    if (wallish(x, y - 1)) {
      const sh = g.createLinearGradient(0, py, 0, py + T * 0.42);
      sh.addColorStop(0, "rgba(0, 0, 0, .5)"); sh.addColorStop(1, "rgba(0, 0, 0, 0)");
      g.fillStyle = sh; g.fillRect(px, py, T, T * 0.42);
    }
    if (wallish(x - 1, y)) {
      const sh = g.createLinearGradient(px, 0, px + T * 0.22, 0);
      sh.addColorStop(0, "rgba(0, 0, 0, .3)"); sh.addColorStop(1, "rgba(0, 0, 0, 0)");
      g.fillStyle = sh; g.fillRect(px, py, T * 0.22, T);
    }
    if (wallish(x + 1, y)) {
      const sh = g.createLinearGradient(px + T, 0, px + T * 0.82, 0);
      sh.addColorStop(0, "rgba(0, 0, 0, .22)"); sh.addColorStop(1, "rgba(0, 0, 0, 0)");
      g.fillStyle = sh; g.fillRect(px + T * 0.78, py, T * 0.22, T);
    }
  }

  // ---------- walls ----------
  function drawWall(x, y, px, py, secret) {
    const face = openish(x, y + 1);        // we can see the front of this wall
    const f = face ? T * 0.4 : 0;
    // top surface
    const top = g.createLinearGradient(0, py, 0, py + T - f);
    top.addColorStop(0, "#9488bb"); top.addColorStop(1, "#7d71a5");
    g.fillStyle = top; g.fillRect(px, py, T, T - f);
    // stone speckle
    for (let k = 0; k < 3; k++) {
      g.fillStyle = hash(x, y, 10 + k) < 0.5 ? "rgba(255,255,255,.07)" : "rgba(0,0,0,.08)";
      g.beginPath(); g.ellipse(px + hash(x, y, 20 + k) * T, py + hash(x, y, 30 + k) * (T - f), 6, 4, 0, 0, Math.PI * 2); g.fill();
    }
    // lit edges where the wall meets open floor
    if (openish(x, y - 1)) { g.fillStyle = "rgba(255,255,255,.28)"; g.fillRect(px, py, T, 3); }
    if (openish(x - 1, y)) { g.fillStyle = "rgba(255,255,255,.16)"; g.fillRect(px, py, 3, T - f); }
    if (openish(x + 1, y)) { g.fillStyle = "rgba(0,0,0,.18)"; g.fillRect(px + T - 3, py, 3, T - f); }
    if (face) {
      // the brick front
      g.fillStyle = "#4b4274"; g.fillRect(px, py + T - f, T, f);
      g.fillStyle = "rgba(0,0,0,.25)";
      const rowH = f / 2;
      for (let r = 0; r < 2; r++) {
        const yy = py + T - f + r * rowH;
        g.fillRect(px, yy, T, 1.5);
        const off = (r + x) % 2 ? 0 : T / 4;
        for (let bx = off; bx < T; bx += T / 2) g.fillRect(px + bx, yy, 1.5, rowH);
      }
      g.fillStyle = "rgba(0,0,0,.45)"; g.fillRect(px, py + T - 3, T, 3);
      g.fillStyle = "rgba(255,255,255,.12)"; g.fillRect(px, py + T - f, T, 2);
    }
    if (secret) {
      // a hider's secret: a faint golden keyhole
      const kx = px + T / 2, ky = face ? py + T - f / 2 : py + (T - f) / 2;
      g.fillStyle = "rgba(255, 214, 102, .9)";
      g.beginPath(); g.arc(kx, ky - 3, 4.5, 0, Math.PI * 2); g.fill();
      g.fillRect(kx - 1.7, ky - 2, 3.4, 9);
    } else if (face && hash(x, y, 40) > 0.84 && x > 0 && x < W - 1) {
      // a wall torch
      const tx = px + T / 2, ty = py + T - f / 2;
      g.fillStyle = "#2a1d12"; g.fillRect(tx - 2, ty - 2, 4, 12);
      g.fillStyle = "#ffb13b";
      g.beginPath(); g.moveTo(tx, ty - 14); g.quadraticCurveTo(tx + 8, ty - 4, tx, ty + 1); g.quadraticCurveTo(tx - 8, ty - 4, tx, ty - 14); g.fill();
      g.fillStyle = "#fff0a8";
      g.beginPath(); g.ellipse(tx, ty - 5, 2.5, 5, 0, 0, Math.PI * 2); g.fill();
      const glow = g.createRadialGradient(tx, ty + T * 0.5, 2, tx, ty + T * 0.5, T * 1.3);
      glow.addColorStop(0, "rgba(255, 170, 60, .32)"); glow.addColorStop(1, "rgba(255, 170, 60, 0)");
      g.fillStyle = glow; g.fillRect(px - T, py + T * 0.2, T * 3, T * 2.2);
      torches.push({ x: x + 0.5, y: y + 1.5 });
    }
  }

  // ---------- things to hide in or behind ----------
  function drawProp(x, y, px, py, secret) {
    const cx = px + T / 2, cy = py + T / 2;
    g.fillStyle = "rgba(0,0,0,.35)";
    g.beginPath(); g.ellipse(cx, cy + T * 0.3, T * 0.36, T * 0.12, 0, 0, Math.PI * 2); g.fill();
    const kind = secret ? 3 + ((hash(x, y, 50) * 2) | 0) : (hash(x, y, 51) * 3) | 0;
    if (kind === 0) {                      // leafy bush
      for (const [dx, dy, r, col] of [[-0.2, 0.08, 0.26, "#2f8a4c"], [0.22, 0.06, 0.25, "#359a55"], [0, -0.14, 0.3, "#3fae62"], [-0.08, 0.12, 0.2, "#47bb6b"]]) {
        g.fillStyle = col; g.beginPath(); g.arc(cx + dx * T, cy + dy * T, r * T, 0, Math.PI * 2); g.fill();
      }
      g.fillStyle = "#e8584f";
      for (const [dx, dy] of [[-0.18, -0.1], [0.16, 0.0], [0.02, -0.26]]) { g.beginPath(); g.arc(cx + dx * T, cy + dy * T, 2.6, 0, Math.PI * 2); g.fill(); }
    } else if (kind === 1) {               // barrel
      g.fillStyle = "#8d5b2e"; g.beginPath(); g.arc(cx, cy, T * 0.34, 0, Math.PI * 2); g.fill();
      g.strokeStyle = "#5a3818"; g.lineWidth = 3; g.beginPath(); g.arc(cx, cy, T * 0.34, 0, Math.PI * 2); g.stroke();
      g.strokeStyle = "#caa266"; g.lineWidth = 2; g.beginPath(); g.arc(cx, cy, T * 0.2, 0, Math.PI * 2); g.stroke();
      g.fillStyle = "#3b2410"; g.beginPath(); g.arc(cx, cy, T * 0.08, 0, Math.PI * 2); g.fill();
    } else if (kind === 2) {               // crate
      g.fillStyle = "#b9803b"; g.fillRect(cx - T * 0.34, cy - T * 0.34, T * 0.68, T * 0.68);
      g.strokeStyle = "#6f4818"; g.lineWidth = 3; g.strokeRect(cx - T * 0.34, cy - T * 0.34, T * 0.68, T * 0.68);
      g.lineWidth = 2; g.beginPath();
      g.moveTo(cx - T * 0.34, cy - T * 0.34); g.lineTo(cx + T * 0.34, cy + T * 0.34);
      g.moveTo(cx + T * 0.34, cy - T * 0.34); g.lineTo(cx - T * 0.34, cy + T * 0.34); g.stroke();
    } else if (kind === 3) {               // big clay urn
      g.fillStyle = "#b5593d"; g.beginPath(); g.ellipse(cx, cy + 2, T * 0.3, T * 0.34, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = "#d07a52"; g.beginPath(); g.ellipse(cx - 4, cy - 2, T * 0.1, T * 0.2, 0.3, 0, Math.PI * 2); g.fill();
      g.fillStyle = "#2a1410"; g.beginPath(); g.ellipse(cx, cy - T * 0.26, T * 0.17, T * 0.07, 0, 0, Math.PI * 2); g.fill();
      g.strokeStyle = "#ffd666"; g.lineWidth = 2; g.beginPath(); g.ellipse(cx, cy + 2, T * 0.3, T * 0.34, 0, 0.2, Math.PI - 0.2); g.stroke();
    } else {                               // treasure chest
      g.fillStyle = "#7a4a22"; g.fillRect(cx - T * 0.36, cy - T * 0.2, T * 0.72, T * 0.46);
      g.fillStyle = "#98602d"; g.beginPath(); g.ellipse(cx, cy - T * 0.2, T * 0.36, T * 0.16, 0, Math.PI, 0); g.fill();
      g.strokeStyle = "#ffd666"; g.lineWidth = 2.5; g.strokeRect(cx - T * 0.36, cy - T * 0.2, T * 0.72, T * 0.46);
      g.fillStyle = "#ffd666"; g.fillRect(cx - 3, cy - T * 0.06, 6, 8);
    }
  }
}
