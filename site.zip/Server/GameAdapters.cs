using System.Text.Json;
using LanternLounge.Core;
using LanternLounge.Games.CatsAndLadders;
using LanternLounge.Games.HideSeek;
using LanternLounge.Games.PebbleDrop;
using LanternLounge.Games.PrismRush;
using LanternLounge.Games.Trouble;
using LanternLounge.Games.Tidebound;
using LanternLounge.Games.TreehouseHoldem;

namespace LanternLounge.Server;

/// <summary>
/// Connects one game's shared rules to the server: how many seats the online table has,
/// how to read a move from JSON, what each player is allowed to see, and how a bot plays.
/// The rules themselves always come from the game's module, the same code the app runs.
/// </summary>
public abstract class GameAdapter
{
    public abstract string GameId { get; }
    public abstract IGameModule Module { get; }

    /// <summary>Seats at an online table. Empty seats are filled by bots when the game starts.</summary>
    public virtual int Seats => Module.Info.MaxPlayers;

    /// <summary>Whether players can type to each other at this game's table. Pebble Drop turns it off.</summary>
    public virtual bool ChatEnabled => true;

    public virtual MatchConfig Config(ulong seed) => new MatchConfig(Seats, seed);

    /// <summary>The config for a new match, given the match that just ended (null for the first). Lets a game rotate roles on a rematch.</summary>
    public virtual MatchConfig Config(ulong seed, object previousState) => Config(seed);

    /// <summary>The config for a match with this many players (fewer than <see cref="Seats"/> when the host turned the bots off).</summary>
    public virtual MatchConfig Config(ulong seed, object previousState, int players) =>
        players == Seats ? Config(seed, previousState) : new MatchConfig(players, seed);

    /// <summary>Like <see cref="Config(ulong, object, int)"/>, but also told what each seat asked to be (games with roles use it).</summary>
    public virtual MatchConfig ConfigWithRoles(ulong seed, object previousState, int players, IReadOnlyList<string> rolePrefs) => Config(seed, previousState, players);

    /// <summary>A bot for a table of <paramref name="players"/> seats. Most bots don't care how many.</summary>
    public virtual BotPlayer CreateBot(int seat, ulong seed, int players) => CreateBot(seat, seed);

    /// <summary>The fewest people that can play. If this is less than <see cref="Seats"/>, the host may turn the bots off.</summary>
    public virtual int MinPlayers => Module.Info.MinPlayers;

    /// <summary>
    /// Real-time games don't wait for turns. The server runs a clock instead: every <see cref="TickMs"/> it
    /// gathers everyone's latest controls (people send them as "moves", bots choose them) and applies one tick.
    /// </summary>
    public virtual bool IsRealtime => false;
    public virtual int TickMs => 100;

    /// <summary>Builds the one action for a tick from every seat's latest controls (null where a seat has none).</summary>
    public virtual object MakeTick(object[] inputs, int dtMs) => throw new NotSupportedException();

    /// <summary>Characters (or colors) players pick in the waiting room. Empty if this game has no choice.</summary>
    public virtual IReadOnlyList<string> Choices => Array.Empty<string>();

    /// <summary>True for games where each player makes their own look (any valid value, duplicates allowed) instead of taking one of <see cref="Choices"/>.</summary>
    public virtual bool FreeChoice => false;
    public virtual bool IsValidChoice(string choice) => false;
    public virtual string DefaultChoice(int seatIndex) => null;

    /// <summary>Turns the "move" object a player sent into this game's action type.</summary>
    public abstract bool TryParseMove(JsonElement move, out object action, out string error);

    /// <summary>What one seat may see, as an object that serializes to JSON.</summary>
    public abstract object ViewFor(object state, int seat);

    /// <summary>A computer player for one seat.</summary>
    public abstract BotPlayer CreateBot(int seat, ulong seed);

    /// <summary>Some moments move on by themselves (e.g. Treehouse Hold'em between rounds).</summary>
    public virtual TimeSpan? AutoAdvanceDelay(object state) => null;

    protected static bool TryGetInt(JsonElement obj, string name, out int value)
    {
        value = 0;
        return obj.ValueKind == JsonValueKind.Object &&
               obj.TryGetProperty(name, out var p) &&
               p.ValueKind == JsonValueKind.Number &&
               p.TryGetInt32(out value);
    }

    protected static string GetString(JsonElement obj, string name)
    {
        return obj.ValueKind == JsonValueKind.Object && obj.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.String
            ? p.GetString()
            : null;
    }
}

/// <summary>A computer player sitting in one seat.</summary>
public abstract class BotPlayer
{
    /// <summary>Called after every accepted move, so bots that remember things can learn.</summary>
    public virtual void Observe(object state) { }

    public abstract object ChooseMove(object state);
}

public static class GameCatalog
{
    private static readonly Dictionary<string, GameAdapter> Adapters = new GameAdapter[]
    {
        new PebbleDropAdapter(),
        new TideboundAdapter(),
        new PrismRushAdapter(),
        new HoldemAdapter(),
        new HideSeekAdapter(),
        new CatsAndLaddersAdapter(),
        new TroubleAdapter()
    }.ToDictionary(a => a.GameId);

    public static IEnumerable<GameAdapter> All => Adapters.Values;

    public static bool TryGet(string gameId, out GameAdapter adapter)
    {
        adapter = null;
        return gameId != null && Adapters.TryGetValue(gameId, out adapter);
    }
}

// ---------------- Pebble Drop ----------------

public sealed class PebbleDropAdapter : GameAdapter
{
    private readonly PebbleDropModule module = new PebbleDropModule();
    public override string GameId => PebbleDropModule.GameId;
    public override IGameModule Module => module;
    public override bool ChatEnabled => false;
    public override int MinPlayers => Seats;

    /// <summary>Move: { "column": 0-15 }</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        if (!TryGetInt(move, "column", out int column))
        {
            error = "A Pebble Drop move needs a column number.";
            return false;
        }
        action = new DropAction(column);
        return true;
    }

    public override object ViewFor(object state, int seat)
    {
        var s = (PebbleDropState)state;
        var cells = new int[PebbleDropState.CellCount];
        for (int r = 0; r < PebbleDropState.Rows; r++)
        {
            for (int c = 0; c < PebbleDropState.Columns; c++) cells[PebbleDropState.Index(r, c)] = s.CellAt(r, c);
        }
        return new
        {
            columns = PebbleDropState.Columns,
            rows = PebbleDropState.Rows,
            cells,
            currentSeat = s.CurrentSeat,
            firstSeat = s.FirstSeat,
            moveCount = s.MoveCount,
            winner = s.Winner,
            winningCells = s.WinningCells,
            isDraw = s.IsDraw,
            lastCell = s.LastCell
        };
    }

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(seat, seed);

    private sealed class Bot : BotPlayer
    {
        private readonly int seat;
        private readonly SeededRandom random;

        public Bot(int seat, ulong seed)
        {
            this.seat = seat;
            random = new SeededRandom(seed);
        }

        public override object ChooseMove(object state) =>
            PebbleDropBot.ChooseMove((PebbleDropState)state, seat, random, BotLevel.Normal);
    }
}

// ---------------- Tidebound ----------------

public sealed class TideboundAdapter : GameAdapter
{
    private readonly TideboundModule module = new TideboundModule();
    public override string GameId => TideboundModule.GameId;
    public override IGameModule Module => module;

    /// <summary>Move: { "target": seat, "creature": 0-15 }</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        if (!TryGetInt(move, "target", out int target) || !TryGetInt(move, "creature", out int creature))
        {
            error = "A Tidebound move needs a target seat and a creature.";
            return false;
        }
        action = new AskAction(target, creature);
        return true;
    }

    public override object ViewFor(object state, int seat) => module.ViewFor((TideboundState)state, seat);

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(module, seat, Seats, seed);

    public override BotPlayer CreateBot(int seat, ulong seed, int players) => new Bot(module, seat, players, seed);

    private sealed class Bot : BotPlayer
    {
        private readonly TideboundModule module;
        private readonly TideboundBot bot;
        private readonly int seat;

        public Bot(TideboundModule module, int seat, int players, ulong seed)
        {
            this.module = module;
            this.seat = seat;
            bot = new TideboundBot(seat, players, new SeededRandom(seed));
        }

        public override void Observe(object state) => bot.Observe(module.ViewFor((TideboundState)state, seat));

        public override object ChooseMove(object state) => bot.ChooseAsk(module.ViewFor((TideboundState)state, seat));
    }
}

// ---------------- Prism Rush ----------------

public sealed class PrismRushAdapter : GameAdapter
{
    private readonly PrismModule module = new PrismModule();
    public override string GameId => PrismModule.GameId;
    public override IGameModule Module => module;

    /// <summary>Move: { "kind": "play", "cards": [ids], "color": 0-3 (Prism only) } or { "kind": "draw" } or { "kind": "keep" }</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        switch (GetString(move, "kind"))
        {
            case "draw":
                action = PrismMove.Draw();
                return true;
            case "keep":
                action = PrismMove.Keep();
                return true;
            case "play":
                if (!move.TryGetProperty("cards", out var cardsElement) || cardsElement.ValueKind != JsonValueKind.Array ||
                    cardsElement.GetArrayLength() == 0 || cardsElement.GetArrayLength() > PrismCards.DeckSize)
                {
                    error = "Pick at least one card to play.";
                    return false;
                }
                var cards = new List<int>();
                foreach (var c in cardsElement.EnumerateArray())
                {
                    if (c.ValueKind != JsonValueKind.Number || !c.TryGetInt32(out int id))
                    {
                        error = "Cards are sent as numbers.";
                        return false;
                    }
                    cards.Add(id);
                }
                int color = TryGetInt(move, "color", out int chosen) ? chosen : -1;
                action = PrismMove.PlayCards(cards, color);
                return true;
            default:
                error = "A Prism Rush move is play, draw or keep.";
                return false;
        }
    }

    public override object ViewFor(object state, int seat) => module.ViewFor((PrismState)state, seat);

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(module, seat);

    private sealed class Bot : BotPlayer
    {
        private readonly PrismModule module;
        private readonly int seat;

        public Bot(PrismModule module, int seat)
        {
            this.module = module;
            this.seat = seat;
        }

        public override object ChooseMove(object state) => PrismBot.ChooseMove(module.ViewFor((PrismState)state, seat));
    }
}

// ---------------- Treehouse Hold'em ----------------

public sealed class HoldemAdapter : GameAdapter
{
    private readonly HoldemModule module = new HoldemModule();
    public override string GameId => HoldemModule.GameId;
    public override IGameModule Module => module;

    /// <summary>Move: { "kind": "fold" | "check" | "call" | "raise" | "next" }</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        switch (GetString(move, "kind"))
        {
            case "fold": action = HoldemMove.Fold; return true;
            case "check": action = HoldemMove.Check; return true;
            case "call": action = HoldemMove.Call; return true;
            case "raise": action = HoldemMove.Raise; return true;
            case "next": action = HoldemMove.NextRound; return true;
            default:
                error = "A Treehouse Hold'em move is fold, check, call, raise or next.";
                return false;
        }
    }

    public override object ViewFor(object state, int seat)
    {
        var view = module.ViewFor((HoldemState)state, seat);
        // Cards each player may see: always your own, others' only once shown at the showdown.
        var cardsBySeat = new IReadOnlyList<int>[view.PlayerCount];
        for (int s = 0; s < view.PlayerCount; s++) cardsBySeat[s] = view.CardsOf(s);
        return new { view, cardsBySeat };
    }

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(module, seat, seed);

    /// <summary>Between rounds, the next round starts by itself after a short pause.</summary>
    public override TimeSpan? AutoAdvanceDelay(object state) =>
        ((HoldemState)state).Phase == Phase.RoundOver ? TimeSpan.FromSeconds(8) : null;

    private sealed class Bot : BotPlayer
    {
        private readonly HoldemModule module;
        private readonly HoldemBot bot;
        private readonly int seat;

        public Bot(HoldemModule module, int seat, ulong seed)
        {
            this.module = module;
            this.seat = seat;
            bot = new HoldemBot(seed, 0.35f + 0.1f * seat);
        }

        public override object ChooseMove(object state) => bot.ChooseMove(module.ViewFor((HoldemState)state, seat));
    }
}

// ---------------- Hide & Seek ----------------

public sealed class HideSeekAdapter : GameAdapter
{
    private readonly HideSeekModule module = new HideSeekModule();
    public override string GameId => HideSeekModule.GameId;
    public override IGameModule Module => module;

    public override bool IsRealtime => true;
    public override int TickMs => HideSeekRules.TickMs;

    /// <summary>Characters, in the order the picker shows them.</summary>
    public override IReadOnlyList<string> Choices { get; } = new[] { "red-panda", "siamese-cat", "honey-badger", "brown-cat", "bobcat", "grim-reaper" };

    /// <summary>After a round the next seat becomes the seeker; the first round picks one at random.</summary>
    /// <summary>A full table of four people and bots is the only way to play.</summary>
    public override int MinPlayers => HideSeekRules.Players;

    /// <summary>
    /// Who seeks: someone who asked to seek (chosen by chance if several did); otherwise anyone who didn't ask to hide;
    /// otherwise anyone. Seats that said "random" (or nothing) are left to chance.
    /// </summary>
    public override MatchConfig ConfigWithRoles(ulong seed, object previousState, int players, IReadOnlyList<string> rolePrefs)
    {
        var wants = new List<int>();
        var open = new List<int>();
        for (int i = 0; i < HideSeekRules.Players; i++)
        {
            string pref = i < rolePrefs.Count ? rolePrefs[i] : null;
            if (pref == "seeker") wants.Add(i);
            if (pref != "hider") open.Add(i);
        }
        var pool = wants.Count > 0 ? wants : open.Count > 0 ? open : new List<int> { 0, 1, 2, 3 };
        int seeker = pool[new SeededRandom(seed).NextInt(pool.Count)];
        return new MatchConfig(Seats, seed, new Dictionary<string, string> { { "seeker", seeker.ToString() } });
    }

    public override MatchConfig Config(ulong seed, object previousState)
    {
        if (previousState is HideSeekState previous)
        {
            var options = new Dictionary<string, string> { { "seeker", ((previous.Seeker + 1) % HideSeekRules.Players).ToString() } };
            return new MatchConfig(Seats, seed, options);
        }
        return Config(seed);
    }

    /// <summary>Move (sent about ten times a second while a finger is down, or when the button is pressed): { "dx": -100..100, "dy": -100..100, "actSeq": number }</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        if (move.ValueKind != JsonValueKind.Object ||
            !move.TryGetProperty("dx", out var dx) || dx.ValueKind != JsonValueKind.Number ||
            !move.TryGetProperty("dy", out var dy) || dy.ValueKind != JsonValueKind.Number ||
            !TryGetInt(move, "actSeq", out int actSeq))
        {
            error = "A Hide & Seek move needs dx, dy and actSeq.";
            return false;
        }
        action = new HideInput((int)Math.Round(dx.GetDouble()), (int)Math.Round(dy.GetDouble()), actSeq);
        return true;
    }

    public override object MakeTick(object[] inputs, int dtMs)
    {
        var list = new HideInput[HideSeekRules.Players];
        for (int i = 0; i < list.Length && i < inputs.Length; i++) list[i] = inputs[i] as HideInput;
        return new HideSeekTick(dtMs, list);
    }

    public override object ViewFor(object state, int seat) => module.ViewFor((HideSeekState)state, seat);

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(seat, seed);

    private sealed class Bot : BotPlayer
    {
        private readonly int seat;
        private readonly HideSeekBot bot;

        public Bot(int seat, ulong seed)
        {
            this.seat = seat;
            bot = new HideSeekBot(seed);
        }

        /// <summary>For this game a bot's "move" is its controls for the next tick.</summary>
        public override object ChooseMove(object state) => bot.ChooseInput((HideSeekState)state, seat);
    }
}
