using System.Text.Json;
using LanternLounge.Core;
using LanternLounge.Games.KittyClash;

namespace LanternLounge.Server;

// Kitty Clash online: a 20-pair cat memory match for two to four players.
public sealed class KittyClashAdapter : GameAdapter
{
    private readonly KittyClashModule module = new KittyClashModule();
    public override string GameId => KittyClashModule.GameId;
    public override IGameModule Module => module;
    public override int MinPlayers => 2;

    /// <summary>Move: { "card": 0..39 } flips that card.</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        if (!TryGetInt(move, "card", out int card) || card < 0 || card >= KittyClashRules.Cards)
        {
            error = "Pick one of the cards.";
            return false;
        }
        action = KittyClashAction.Flip(card);
        return true;
    }

    private static readonly string[] Kinds = { "none", "first", "match", "miss" };

    public override object ViewFor(object state, int seat)
    {
        var v = module.ViewFor((KittyClashState)state, seat);
        var e = v.Last;
        return new
        {
            cards = v.Cards,
            owner = v.Owner,
            scores = v.Scores,
            first = v.First,
            missA = v.MissA,
            missB = v.MissB,
            currentSeat = v.CurrentSeat,
            players = v.Players,
            actions = v.Actions,
            pairsLeft = v.PairsLeft,
            last = e.Kind == KittyKind.None ? null : new
            {
                kind = Kinds[(int)e.Kind],
                seat = e.Seat,
                a = e.A,
                faceA = e.FaceA,
                b = e.B,
                faceB = e.FaceB
            }
        };
    }

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(seat, seed);

    /// <summary>
    /// A bot that plays fairly: it only remembers cards that were flipped face up for everyone, and it forgets some of them,
    /// so it is beatable. It looks only at the public record (Seen and Last), never at the hidden cards.
    /// </summary>
    private sealed class Bot : BotPlayer
    {
        private readonly int seat;
        private readonly ulong seed;
        private readonly int[] memory = new int[KittyClashRules.Cards];
        private int tick;

        public Bot(int seat, ulong seed)
        {
            this.seat = seat;
            this.seed = seed;
            for (int i = 0; i < memory.Length; i++) memory[i] = -1;
        }

        public override void Observe(object state)
        {
            var s = (KittyClashState)state;
            var e = s.Last;
            if (e.Kind == KittyKind.None) return;
            tick++;
            Learn(e.A, e.FaceA);
            if (e.Kind != KittyKind.First) Learn(e.B, e.FaceB);
            for (int i = 0; i < memory.Length; i++) if (s.Owner[i] != KittyClashRules.NoSeat) memory[i] = -1;
        }

        // Remembers a flipped card about 7 times out of 10.
        private void Learn(int card, int face)
        {
            if (card < 0) return;
            if (KittyClashRules.Pick(seed, tick * 7 + card + seat * 131, 10) < 7) memory[card] = face;
        }

        public override object ChooseMove(object state)
        {
            var s = (KittyClashState)state;
            if (s.First != KittyClashRules.NoCard)
            {
                // second card: if the first one's partner is remembered, go there
                int faceA = s.Faces[s.First];  // the bot already saw this card flipped, so this is public knowledge
                for (int i = 0; i < memory.Length; i++)
                    if (i != s.First && s.Owner[i] == KittyClashRules.NoSeat && memory[i] == faceA) return KittyClashAction.Flip(i);
                return KittyClashAction.Flip(RandomUnknown(s, s.First));
            }
            // first card: if two remembered cards match, take that pair
            for (int i = 0; i < memory.Length; i++)
            {
                if (memory[i] < 0 || s.Owner[i] != KittyClashRules.NoSeat) continue;
                for (int j = i + 1; j < memory.Length; j++)
                    if (memory[j] == memory[i] && s.Owner[j] == KittyClashRules.NoSeat) return KittyClashAction.Flip(i);
            }
            return KittyClashAction.Flip(RandomUnknown(s, -1));
        }

        /// <summary>A card the bot doesn't remember, if there is one; otherwise any card still in play.</summary>
        private int RandomUnknown(KittyClashState s, int skip)
        {
            var open = new System.Collections.Generic.List<int>();
            var unknown = new System.Collections.Generic.List<int>();
            for (int i = 0; i < memory.Length; i++)
            {
                if (i == skip || s.Owner[i] != KittyClashRules.NoSeat) continue;
                open.Add(i);
                if (memory[i] < 0) unknown.Add(i);
            }
            var pool = unknown.Count > 0 ? unknown : open;
            return pool[KittyClashRules.Pick(seed, tick * 13 + s.Actions + seat, pool.Count)];
        }
    }
}
