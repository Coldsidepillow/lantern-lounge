// Kitty Clash online: a memory match with 20 pairs of cats. Flip two cards; keep a pair and go again,
// or the cards flip back and everyone else gets a turn to remember them.
import { h, SEAT_COLORS } from "../ui.js";
import { catPiece, catName } from "./catpieces.js";

const CAT_FOR = ["tabby", "tuxedo", "siamese", "calico", "gray", "fluffy", "black", "witch", "eagle", "reaper",
  "mochi", "pepper", "luna", "biscuit", "snowball", "clover", "cocoa", "ember", "dusk", "honey"];
const PEEK_MS = 2400;
const GLANCE_MS = 850;   // the opening glance at the cats before the shuffle   // how long a miss stays face up before it flips back (on every screen)

export default {
  id: "kitty-clash",
  name: "Kitty Clash",
  theme: "theme-kitty",
  hideSeats: false,
  artClass: "art-kitty",
  blurb: "Flip two cards. Match the cats to keep the pair. If they don't match they flip back, so watch what everyone else flips!",
  art: () => ["tabby", "siamese", "witch", "eagle"].map(id => h("span.kc-art", catPiece(id, 56))),
  create
};

function create(area, api) {
  let room = null, view = null;
  let waiting = false, lastActions = -1, lastMatch = -1;
  let peekOver = false, peekTimer = 0, destroyed = false, intro = false;
  const cardEls = [];

  const grid = h("div.kc-grid");
  for (let i = 0; i < 40; i++) {
    const el = h("button.kc-card", { type: "button", "aria-label": "Card " + (i + 1), onclick: () => flip(i) },
      h("div.kc-in", h("div.kc-back"), h("div.kc-face")));
    el.dataset.face = "-1";
    cardEls.push(el);
    grid.appendChild(el);
  }
  const status = h("div.kc-status");
  const pairs = h("div.kc-pairs");
  const topRow = h("div.kc-seats");
  const meRow = h("div.kc-seats.me");
  area.replaceChildren(h("div.kc-wrap", h("div.kc-table", topRow, h("div.kc-felt", grid), meRow), pairs, status));

  // The players sit around the table; each one's won pairs pile up beside their name so everyone can see the score.
  const initial = (name) => ((name || "?").trim()[0] || "?").toUpperCase();
  function seatEl(seat) {
    const n = view.scores[seat] || 0, bot = room.seats[seat] && room.seats[seat].isBot;
    const turn = room.status === "playing" && view.currentSeat === seat && view.pairsLeft > 0;
    const nm = api.seatName(seat);
    const stack = h("div.kc-won", Array.from({ length: n }, (_, i) => h("span", { style: { "--i": String(i), borderColor: SEAT_COLORS[seat % 4] } })));
    return h("div.kc-seat", { class: (turn ? "turn " : "") + (seat === api.you ? "you" : "") },
      h("div.tbl-av", { style: { background: SEAT_COLORS[seat % 4] } }, initial(nm)),
      h("div.kc-who", h("div.tbl-name", (bot ? "🤖 " : "") + nm + (seat === api.you ? " (you)" : "")),
        h("div.kc-score", `${n} ${n === 1 ? "pair" : "pairs"}`), stack));
  }
  function paintSeats() {
    const count = view.players, order = [];
    for (let i = 1; i < count; i++) order.push((api.you + i) % count);
    topRow.replaceChildren(...order.map(seatEl));
    meRow.replaceChildren(seatEl(api.you));
  }

  const myTurn = () => !intro && view && room && room.status === "playing" && view.currentSeat === api.you && view.pairsLeft > 0;
  const peeking = () => view && view.missA >= 0 && !peekOver;

  function flip(i) {
    if (!myTurn() || waiting) return;
    if (view.owner[i] >= 0 || i === view.first) return;
    if (peeking()) { api.toast("Watch the cats first..."); return; }
    waiting = true;
    api.send({ card: i });
    paint();
  }

  // The opening: every card flips up for a split second (just a glimpse of which cats are in the box, in a made-up
  // order that has nothing to do with the real layout), flips back, and then the cards are shuffled around the table.
  const wait = (ms) => new Promise(res => setTimeout(res, ms));
  async function startIntro() {
    intro = true;
    const preview = Array.from({ length: 40 }, (_, i) => i >> 1);
    for (let i = 39; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [preview[i], preview[j]] = [preview[j], preview[i]]; }
    cardEls.forEach((el, i) => {
      el.dataset.face = String(preview[i]);
      el.querySelector(".kc-face").replaceChildren(catPiece(CAT_FOR[preview[i]], 60), h("span.kc-name", catName(CAT_FOR[preview[i]])));
      el.classList.remove("up", "won", "miss"); el.disabled = true;
    });
    status.textContent = "Here come the cats...";
    await wait(250); if (destroyed) return;
    cardEls.forEach(el => el.classList.add("up"));
    await wait(GLANCE_MS); if (destroyed) return;
    cardEls.forEach(el => el.classList.remove("up"));
    await wait(450); if (destroyed) return;
    status.textContent = "Shuffling...";
    for (let round = 0; round < 3 && !destroyed; round++) {
      const rects = cardEls.map(el => el.getBoundingClientRect());
      const order = cardEls.map((_, i) => i);
      for (let i = 39; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
      cardEls.forEach((el, i) => {
        const to = rects[order[i]], from = rects[i];
        el.classList.add("shuffling");
        el.style.transform = `translate(${to.left - from.left}px, ${to.top - from.top}px) rotate(${(Math.random() * 14 - 7).toFixed(1)}deg)`;
      });
      await wait(420);
      cardEls.forEach(el => { el.classList.remove("shuffling"); el.style.transform = ""; });
      await wait(60);
    }
    if (destroyed) return;
    intro = false;
    paint();
    api.refresh && api.refresh();
  }

  function paint() {
    if (!view || intro) return;
    const mine = myTurn() && !waiting;
    for (let i = 0; i < 40; i++) {
      const el = cardEls[i], face = view.cards[i], owner = view.owner[i];
      const up = owner >= 0 || i === view.first || ((i === view.missA || i === view.missB) && !peekOver);
      const shownFace = up ? face : -1;
      const inner = el.querySelector(".kc-face");
      if (shownFace >= 0 && el.dataset.face !== String(shownFace)) {
        el.dataset.face = String(shownFace);
        inner.replaceChildren(catPiece(CAT_FOR[shownFace], 60), h("span.kc-name", catName(CAT_FOR[shownFace])));
      }
      el.classList.toggle("up", up);
      el.classList.toggle("won", owner >= 0);
      el.classList.toggle("miss", (i === view.missA || i === view.missB) && !peekOver && owner < 0);
      el.style.setProperty("--owner", owner >= 0 ? SEAT_COLORS[owner % 4] : "transparent");
      el.disabled = !(mine && owner < 0 && i !== view.first);
    }
    paintSeats();
    pairs.textContent = `${view.pairsLeft} ${view.pairsLeft === 1 ? "pair" : "pairs"} left`;
    status.textContent = statusText();
  }

  function statusText() {
    if (!view || !room) return "";
    if (view.pairsLeft === 0) return "";
    if (view.currentSeat !== api.you) return `${api.seatName(view.currentSeat)}'s turn`;
    return view.first >= 0 ? "Pick a second card." : "Flip a card.";
  }

  return {
    update(r) {
      room = r;
      const v = r.view;
      if (!v) return;
      const newMatch = r.match !== lastMatch;
      if (newMatch) { lastMatch = r.match; lastActions = -1; waiting = false; if (v.actions === 0 && r.status === "playing") startIntro(); }
      const fresh = v.actions !== lastActions;
      view = v;
      if (fresh) {
        waiting = false;
        lastActions = v.actions;
        clearTimeout(peekTimer);
        peekOver = false;
        const ev = v.last;
        if (ev && ev.kind === "miss") {
          peekTimer = setTimeout(() => { if (!destroyed) { peekOver = true; paint(); api.refresh && api.refresh(); } }, PEEK_MS);
          if (ev.seat === api.you) api.sound.card && api.sound.card();
        } else if (ev && ev.kind === "match") {
          if (ev.seat === api.you) api.sound.win && api.sound.win(); else api.sound.card && api.sound.card();
        } else if (ev) {
          api.sound.tap && api.sound.tap();
        }
      }
      paint();
    },
    onError(request) { if (request === "move") { waiting = false; paint(); } },
    seatInfo(seat) { return view ? `${view.scores[seat] || 0} ${view.scores[seat] === 1 ? "pair" : "pairs"}` : ""; },
    seatClass(seat) { return view && room && room.status === "playing" && view.currentSeat === seat ? "turn" : ""; },
    banner(r) {
      const v = r.view;
      if (!v || r.status !== "playing") return ["", false];
      if (intro) return ["Shuffling the cats...", false];
      if (v.currentSeat === api.you) {
        if (waiting) return ["", false];
        if (v.missA >= 0 && !peekOver) return ["Watch the cats...", false];
        return [v.first >= 0 ? "Flip a second card." : "Your turn! Flip a card.", true];
      }
      const bot = r.seats[v.currentSeat] && r.seats[v.currentSeat].isBot;
      return [`${api.seatName(v.currentSeat)}${bot ? " (bot)" : ""}'s turn`, false];
    },
    ranking(r) {
      const v = r.view;
      if (!v) return [];
      return v.scores.map((n, seat) => ({ seat, n }))
        .sort((a, b) => b.n - a.n)
        .map(x => ({ seat: x.seat, text: `${x.n} ${x.n === 1 ? "pair" : "pairs"}` }));
    },
    destroy() { destroyed = true; clearTimeout(peekTimer); }
  };
}
