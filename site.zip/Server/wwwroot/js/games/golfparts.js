// Mini Golf look-and-feel pieces: ball colors, the ten hats, and the course drawing.
// Pure drawing code (no game rules), so the lobby picker and the course both use it.

export const BALL_COLORS = [
  { id: "red", name: "Red", hex: "#E5484D" },
  { id: "orange", name: "Orange", hex: "#FF8A3D" },
  { id: "yellow", name: "Yellow", hex: "#F5C518" },
  { id: "lime", name: "Lime", hex: "#9BE03A" },
  { id: "green", name: "Green", hex: "#2FB86B" },
  { id: "teal", name: "Teal", hex: "#1FC2B3" },
  { id: "sky", name: "Sky", hex: "#4CC9F0" },
  { id: "blue", name: "Blue", hex: "#3E7BF7" },
  { id: "purple", name: "Purple", hex: "#8C5CF6" },
  { id: "pink", name: "Pink", hex: "#FF6FB5" },
  { id: "white", name: "White", hex: "#F4F4F8" },
  { id: "black", name: "Black", hex: "#2B2B36" }
];

export const HATS = [
  { id: "none", name: "No hat" },
  { id: "tophat", name: "Top hat" },
  { id: "party", name: "Party hat" },
  { id: "cap", name: "Cap" },
  { id: "crown", name: "Crown" },
  { id: "cowboy", name: "Cowboy" },
  { id: "wizard", name: "Wizard" },
  { id: "propeller", name: "Propeller" },
  { id: "chef", name: "Chef" },
  { id: "pirate", name: "Pirate" },
  { id: "halo", name: "Halo" }
];

export const DEFAULT_CHOICE = (seat) => `${BALL_COLORS[(seat * 3) % BALL_COLORS.length].id}:none`;

export function parseChoice(choice, seat) {
  const [c, hat] = String(choice || DEFAULT_CHOICE(seat)).split(":");
  const color = BALL_COLORS.find(x => x.id === c) || BALL_COLORS[seat % BALL_COLORS.length];
  const h = HATS.find(x => x.id === hat) || HATS[0];
  return { color, hat: h.id };
}

export function shade(hex, amount) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const f = (v) => Math.max(0, Math.min(255, Math.round(amount >= 0 ? v + (255 - v) * amount : v * (1 + amount))));
  r = f(r); g = f(g); b = f(b);
  return `rgb(${r},${g},${b})`;
}

/** A shiny ball with its hat. (x, y) is the ball's centre, r its radius in pixels. */
export function drawBall(ctx, x, y, r, hex, hat, t = 0, opts = {}) {
  if (opts.shadow !== false) {   // soft contact shadow
    const sg = ctx.createRadialGradient(x + r * 0.15, y + r * 0.7, r * 0.1, x + r * 0.15, y + r * 0.7, r * 1.05);
    sg.addColorStop(0, "rgba(0,0,0,.34)"); sg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = sg; ctx.beginPath(); ctx.ellipse(x + r * 0.15, y + r * 0.7, r * 1.05, r * 0.4, 0, 0, Math.PI * 2); ctx.fill();
  }
  // the sphere: lit from the top left, with a cool bounce of light from below
  const g = ctx.createRadialGradient(x - r * 0.38, y - r * 0.42, r * 0.05, x - r * 0.1, y - r * 0.1, r * 1.12);
  g.addColorStop(0, shade(hex, 0.62)); g.addColorStop(0.35, shade(hex, 0.12)); g.addColorStop(0.75, shade(hex, -0.22)); g.addColorStop(1, shade(hex, -0.5));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  ctx.save();
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.clip();
  if (r > 7) {   // golf ball dimples, bunched toward the edges so it reads as round
    for (let ring = 0; ring < 3; ring++) {
      const rr = r * (0.28 + ring * 0.28), n = 5 + ring * 4;
      for (let i = 0; i < n; i++) {
        const a = i / n * Math.PI * 2 + ring * 0.6, px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
        const lit = (px - x) * -0.6 + (py - y) * -0.7;
        ctx.fillStyle = lit > 0 ? "rgba(255,255,255,.16)" : "rgba(0,0,0,.16)";
        ctx.beginPath(); ctx.ellipse(px, py, r * 0.085, r * 0.065, a, 0, Math.PI * 2); ctx.fill();
      }
    }
  }
  const bounce = ctx.createRadialGradient(x + r * 0.3, y + r * 0.85, 0, x + r * 0.3, y + r * 0.85, r * 0.7);
  bounce.addColorStop(0, "rgba(160,210,255,.28)"); bounce.addColorStop(1, "rgba(160,210,255,0)");
  ctx.fillStyle = bounce; ctx.fillRect(x - r, y - r, r * 2, r * 2);
  ctx.restore();
  ctx.strokeStyle = "rgba(0,0,0,.28)"; ctx.lineWidth = Math.max(0.8, r * 0.05);
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
  // a soft, small highlight rather than a hard white blob
  const hl = ctx.createRadialGradient(x - r * 0.4, y - r * 0.44, 0, x - r * 0.4, y - r * 0.44, r * 0.34);
  hl.addColorStop(0, "rgba(255,255,255,.9)"); hl.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = hl; ctx.beginPath(); ctx.arc(x - r * 0.4, y - r * 0.44, r * 0.34, 0, Math.PI * 2); ctx.fill();
  drawHat(ctx, hat, x, y, r, t);
}

const isHex = (c) => typeof c === "string" && /^#[0-9a-f]{6}$/i.test(c);
/** A flat color becomes a soft light-to-dark gradient across the shape, so hats look rounded instead of flat. */
function lit(ctx, c, x0, y0, x1, y1) {
  if (!isHex(c)) return c;
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, shade(c, 0.3)); g.addColorStop(0.5, c); g.addColorStop(1, shade(c, -0.32));
  return g;
}
function poly(ctx, pts, fill, stroke, lw) {
  ctx.beginPath();
  pts.forEach(([px, py], i) => (i ? ctx.lineTo(px, py) : ctx.moveTo(px, py)));
  ctx.closePath();
  if (fill) {
    const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
    ctx.fillStyle = lit(ctx, fill, Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)); ctx.fill();
  }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw; ctx.stroke(); }
}
function ell(ctx, x, y, rx, ry, fill, stroke, lw, rot = 0) {
  ctx.beginPath(); ctx.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
  if (fill) { ctx.fillStyle = lit(ctx, fill, x - rx, y - ry, x + rx, y + ry); ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw; ctx.stroke(); }
}

/** The ten hats (plus none). Drawn sitting on top of a ball of radius r centred at (x, y). */
export function drawHat(ctx, hat, x, y, r, t = 0) {
  if (!hat || hat === "none") return;
  const lw = Math.max(0.8, r * 0.05), ink = "rgba(25,15,35,.5)";
  const top = y - r * 0.82;          // where the hat sits
  ctx.save();
  switch (hat) {
    case "tophat": {
      ell(ctx, x, top + r * 0.05, r * 1.0, r * 0.3, "#1d1b26", ink, lw);
      ctx.fillStyle = "#26232f"; ctx.fillRect(x - r * 0.55, top - r * 1.05, r * 1.1, r * 1.1);
      ell(ctx, x, top - r * 1.05, r * 0.55, r * 0.2, "#34303f", ink, lw);
      ctx.fillStyle = "#E5484D"; ctx.fillRect(x - r * 0.55, top - r * 0.3, r * 1.1, r * 0.22);
      ctx.strokeStyle = ink; ctx.lineWidth = lw; ctx.strokeRect(x - r * 0.55, top - r * 1.05, r * 1.1, r * 1.1);
      break;
    }
    case "party": {
      poly(ctx, [[x - r * 0.6, top + r * 0.1], [x + r * 0.6, top + r * 0.1], [x + r * 0.05, top - r * 1.5]], "#FF6FB5", ink, lw);
      ctx.fillStyle = "#FFE066";
      for (const [fx, fy] of [[-0.18, -0.3], [0.12, -0.65], [-0.05, -1.0], [0.28, -0.2]]) { ctx.beginPath(); ctx.arc(x + fx * r, top + fy * r, r * 0.09, 0, 7); ctx.fill(); }
      ell(ctx, x + r * 0.05, top - r * 1.55, r * 0.2, r * 0.2, "#4CC9F0", ink, lw);
      break;
    }
    case "cap": {
      ctx.beginPath(); ctx.moveTo(x - r * 0.75, top + r * 0.18); ctx.quadraticCurveTo(x - r * 0.7, top - r * 0.95, x, top - r * 0.95);
      ctx.quadraticCurveTo(x + r * 0.75, top - r * 0.95, x + r * 0.75, top + r * 0.18); ctx.closePath();
      ctx.fillStyle = "#3E7BF7"; ctx.fill(); ctx.strokeStyle = ink; ctx.lineWidth = lw; ctx.stroke();
      ell(ctx, x + r * 0.75, top + r * 0.18, r * 0.6, r * 0.17, "#2557C4", ink, lw);
      ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(x, top - r * 0.95, r * 0.1, 0, 7); ctx.fill();
      break;
    }
    case "crown": {
      const b = top + r * 0.12, hgt = r * 0.95;
      poly(ctx, [[x - r * 0.68, b], [x - r * 0.68, b - hgt * 0.55], [x - r * 0.34, b - hgt * 0.2], [x, b - hgt], [x + r * 0.34, b - hgt * 0.2], [x + r * 0.68, b - hgt * 0.55], [x + r * 0.68, b]], "#FFC93C", ink, lw);
      ctx.fillStyle = "#E5484D"; ctx.beginPath(); ctx.arc(x, b - hgt * 0.3, r * 0.1, 0, 7); ctx.fill();
      ctx.fillStyle = "#4CC9F0"; ctx.beginPath(); ctx.arc(x - r * 0.4, b - hgt * 0.18, r * 0.07, 0, 7); ctx.arc(x + r * 0.4, b - hgt * 0.18, r * 0.07, 0, 7); ctx.fill();
      break;
    }
    case "cowboy": {
      ctx.beginPath(); ctx.moveTo(x - r * 1.25, top + r * 0.12); ctx.quadraticCurveTo(x - r * 0.9, top + r * 0.4, x - r * 0.45, top + r * 0.2);
      ctx.lineTo(x + r * 0.45, top + r * 0.2); ctx.quadraticCurveTo(x + r * 0.9, top + r * 0.4, x + r * 1.25, top + r * 0.12);
      ctx.quadraticCurveTo(x + r * 0.9, top - r * 0.15, x + r * 0.5, top - r * 0.12); ctx.lineTo(x - r * 0.5, top - r * 0.12);
      ctx.quadraticCurveTo(x - r * 0.9, top - r * 0.15, x - r * 1.25, top + r * 0.12); ctx.closePath();
      ctx.fillStyle = "#A8642D"; ctx.fill(); ctx.strokeStyle = ink; ctx.lineWidth = lw; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x - r * 0.5, top - r * 0.1); ctx.quadraticCurveTo(x - r * 0.55, top - r * 0.85, x - r * 0.2, top - r * 0.8);
      ctx.quadraticCurveTo(x, top - r * 0.62, x + r * 0.2, top - r * 0.8); ctx.quadraticCurveTo(x + r * 0.55, top - r * 0.85, x + r * 0.5, top - r * 0.1); ctx.closePath();
      ctx.fillStyle = "#C27A3A"; ctx.fill(); ctx.stroke();
      ctx.fillStyle = "#5A3A1E"; ctx.fillRect(x - r * 0.5, top - r * 0.3, r, r * 0.17);
      break;
    }
    case "wizard": {
      ell(ctx, x, top + r * 0.1, r * 1.0, r * 0.28, "#5B3AA8", ink, lw);
      ctx.beginPath(); ctx.moveTo(x - r * 0.62, top + r * 0.08); ctx.quadraticCurveTo(x - r * 0.3, top - r * 1.2, x + r * 0.5, top - r * 1.75);
      ctx.quadraticCurveTo(x + r * 0.35, top - r * 0.8, x + r * 0.62, top + r * 0.08); ctx.closePath();
      ctx.fillStyle = "#7A4FD6"; ctx.fill(); ctx.strokeStyle = ink; ctx.lineWidth = lw; ctx.stroke();
      ctx.fillStyle = "#FFE066";
      for (const [fx, fy, s] of [[0, -0.5, 0.14], [0.22, -1.05, 0.1], [-0.15, -0.95, 0.08]]) star(ctx, x + fx * r, top + fy * r, r * s);
      break;
    }
    case "propeller": {
      ctx.beginPath(); ctx.moveTo(x - r * 0.7, top + r * 0.2); ctx.quadraticCurveTo(x - r * 0.7, top - r * 0.8, x, top - r * 0.8);
      ctx.quadraticCurveTo(x + r * 0.7, top - r * 0.8, x + r * 0.7, top + r * 0.2); ctx.closePath();
      const gg = ctx.createLinearGradient(x - r * 0.7, 0, x + r * 0.7, 0);
      gg.addColorStop(0, "#E5484D"); gg.addColorStop(0.33, "#F5C518"); gg.addColorStop(0.66, "#2FB86B"); gg.addColorStop(1, "#3E7BF7");
      ctx.fillStyle = gg; ctx.fill(); ctx.strokeStyle = ink; ctx.lineWidth = lw; ctx.stroke();
      ctx.fillStyle = "#444"; ctx.fillRect(x - r * 0.05, top - r * 1.05, r * 0.1, r * 0.3);
      const sp = Math.cos(t * 14);
      ell(ctx, x, top - r * 1.07, r * 0.75 * Math.abs(sp) + r * 0.08, r * 0.1, "#FF8A3D", ink, lw);
      break;
    }
    case "chef": {
      ctx.fillStyle = "#fff"; ctx.strokeStyle = ink; ctx.lineWidth = lw;
      ctx.fillRect(x - r * 0.5, top - r * 0.4, r, r * 0.55); ctx.strokeRect(x - r * 0.5, top - r * 0.4, r, r * 0.55);
      for (const [fx, fy, s] of [[-0.42, -0.62, 0.38], [0.42, -0.62, 0.38], [0, -0.88, 0.45], [-0.2, -0.7, 0.35], [0.2, -0.7, 0.35]]) ell(ctx, x + fx * r, top + fy * r, r * s, r * s, "#fff", ink, lw);
      ctx.fillStyle = "#fff"; ctx.fillRect(x - r * 0.45, top - r * 0.62, r * 0.9, r * 0.3);
      break;
    }
    case "pirate": {
      poly(ctx, [[x - r * 1.05, top + r * 0.2], [x - r * 0.55, top - r * 0.85], [x + r * 0.55, top - r * 0.85], [x + r * 1.05, top + r * 0.2], [x, top + r * 0.02]], "#1f1d29", ink, lw);
      ctx.fillStyle = "#f4f4f8"; ctx.beginPath(); ctx.arc(x, top - r * 0.45, r * 0.17, 0, 7); ctx.fill();
      ctx.strokeStyle = "#f4f4f8"; ctx.lineWidth = lw * 1.2;
      ctx.beginPath(); ctx.moveTo(x - r * 0.25, top - r * 0.22); ctx.lineTo(x + r * 0.25, top - r * 0.62); ctx.moveTo(x + r * 0.25, top - r * 0.22); ctx.lineTo(x - r * 0.25, top - r * 0.62); ctx.stroke();
      ctx.strokeStyle = "#FFC93C"; ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(x - r * 0.95, top + r * 0.14); ctx.lineTo(x + r * 0.95, top + r * 0.14); ctx.stroke();
      break;
    }
    case "halo": {
      const bob = Math.sin(t * 3) * r * 0.05;
      ell(ctx, x, top - r * 0.55 + bob, r * 0.7, r * 0.22, null, "rgba(255,200,60,.35)", r * 0.28);
      ell(ctx, x, top - r * 0.55 + bob, r * 0.7, r * 0.22, null, "#FFD84A", r * 0.13);
      break;
    }
  }
  ctx.restore();
}

function star(ctx, x, y, s) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + i * Math.PI / 5, rad = i % 2 ? s * 0.45 : s;
    ctx[i ? "lineTo" : "moveTo"](x + Math.cos(a) * rad, y + Math.sin(a) * rad);
  }
  ctx.closePath(); ctx.fill();
}

/** A small canvas showing a ball with a hat (for pickers and the scoreboard). */
export function ballCanvas(hex, hat, size = 48) {
  const c = document.createElement("canvas");
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  c.width = c.height = Math.round(size * dpr);
  c.style.width = c.style.height = size + "px";
  c.className = "golf-ball-art";
  const ctx = c.getContext("2d");
  ctx.scale(dpr, dpr);
  drawBall(ctx, size / 2, size * 0.64, size * 0.27, hex, hat, 0, { shadow: false });
  return c;
}
