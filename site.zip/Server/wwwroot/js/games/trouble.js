// Benson online: a ring of 28 squares, four pegs each, and a pop-the-die dome in the middle.
// The server rolls the die (so nobody can cheat). This page plays it back: the dome pops, the die settles,
// the peg hops square by square, and a peg that gets landed on slides back home.
import { h } from "../ui.js";
import { CAT_IDS, catName, catPiece } from "./catpieces.js";

const SIZE = 1000;
const CX = 500, CY = 500, R = 330;            // the ring of 28 squares
const STEP = 360 / 28, PHI0 = 38.57;          // degrees; square 0 (red's start) sits just clockwise of the top-right corner
const INK = "#3a2a1f";
const SEATS = [   // clockwise from the top-right corner
  { name: "Blue",   c: "#4A82AE", d: "#2E5B80" },
  { name: "Red",    c: "#C8553D", d: "#8F3524" },
  { name: "Green",  c: "#5B9A6B", d: "#38694A" },
  { name: "Yellow", c: "#E2B33D", d: "#A97E16" }
];
const PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };

const FACE_FOR = { 1: [0, 0], 2: [0, -90], 3: [-90, 0], 4: [90, 0], 5: [0, 90], 6: [0, 180] };   // rotateX, rotateY that bring face n to the front
function makeDie() {
  const faces = [[1, "translateZ(var(--h))"], [2, "rotateY(90deg) translateZ(var(--h))"], [3, "rotateX(90deg) translateZ(var(--h))"],
    [4, "rotateX(-90deg) translateZ(var(--h))"], [5, "rotateY(-90deg) translateZ(var(--h))"], [6, "rotateY(180deg) translateZ(var(--h))"]]
    .map(([n, t]) => h("div.tr-face", { style: { transform: t } }, Array.from({ length: 9 }, (_, i) => h("i", { class: PIPS[n].includes(i) ? "pip" : "" }))));
  const cube = h("div.tr-cube", faces);
  const hopper = h("div.tr-hopper", cube);
  const root = h("div.tr-die", { "aria-hidden": "true" }, hopper);
  let x = 0, y = 0, z = 0, lift = 0, raf = 0;
  const draw = () => { cube.style.transform = `rotateX(${x}deg) rotateY(${y}deg) rotateZ(${z}deg)`; hopper.style.transform = `translateY(${lift}%)`; };
  const stop = () => { if (raf) cancelAnimationFrame(raf); raf = 0; };
  const set = (n) => { stop(); [x, y] = FACE_FOR[n]; z = 0; lift = 0; draw(); };
  set(1);
  const later = (a, t, turns) => t + 360 * Math.ceil((a + turns - t) / 360);        // the next angle that shows face-on and is at least `turns` degrees further round
  return {
    root, set,
    /** Keep turning (while we wait to hear the number). */
    spin() {
      stop(); let last = performance.now();
      const loop = (now) => { const dt = Math.min(0.05, (now - last) / 1000); last = now; x += 430 * dt; y += 610 * dt; z += 150 * dt; draw(); raf = requestAnimationFrame(loop); };
      raf = requestAnimationFrame(loop);
    },
    /** Settle from wherever it is now and land showing `n`: slows smoothly, with a couple of small bounces. */
    land(n, ms) {
      stop();
      const [tx, ty] = FACE_FOR[n], x0 = x, y0 = y, z0 = z, x1 = later(x0, tx, 540), y1 = later(y0, ty, 720), z1 = later(z0, 0, 200);
      const t0 = performance.now();
      const loop = (now) => {
        const u = Math.min(1, (now - t0) / ms), e = 1 - Math.pow(1 - u, 3);
        x = x0 + (x1 - x0) * e; y = y0 + (y1 - y0) * e; z = z0 + (z1 - z0) * e;
        lift = -26 * Math.abs(Math.sin(u * Math.PI * 2.5)) * Math.pow(1 - u, 1.6);
        draw();
        if (u < 1) raf = requestAnimationFrame(loop); else { raf = 0; x = tx; y = ty; z = 0; lift = 0; draw(); }
      };
      raf = requestAnimationFrame(loop);
    }
  };
}

// ----- geometry (all in board units, 0 to 1000) -----
// The track is a rounded square of 28 spaces, seven between each pair of corners. Each corner has a start space and the mouth of that
// player's finish lane, which runs diagonally in toward the middle.
const H = 300, RC = 100;                                  // half-size of the track, and how round its corners are
const SIDE = 2 * (H - RC), PERIM = 4 * SIDE + 2 * Math.PI * RC, SP = PERIM / 28;
/** The point d units clockwise round the track, counting from the middle of the top-right corner. */
function pathXY(d) {
  d = ((d % PERIM) + PERIM) % PERIM;
  const I = H - RC;
  const arc = (cx, cy, t0, t1) => ({ len: RC * Math.abs(t1 - t0) * Math.PI / 180, at: (u) => { const t = (t0 + (t1 - t0) * u) * Math.PI / 180; return [cx + RC * Math.sin(t), cy - RC * Math.cos(t)]; } });
  const line = (x0, y0, x1, y1) => ({ len: Math.hypot(x1 - x0, y1 - y0), at: (u) => [x0 + (x1 - x0) * u, y0 + (y1 - y0) * u] });
  const pieces = [
    arc(CX + I, CY - I, 45, 90), line(CX + H, CY - I, CX + H, CY + I),
    arc(CX + I, CY + I, 90, 180), line(CX + I, CY + H, CX - I, CY + H),
    arc(CX - I, CY + I, 180, 270), line(CX - H, CY + I, CX - H, CY - I),
    arc(CX - I, CY - I, 270, 360), line(CX - I, CY - H, CX + I, CY - H),
    arc(CX + I, CY - I, 0, 45)
  ];
  for (const piece of pieces) { if (d <= piece.len) return piece.at(d / piece.len); d -= piece.len; }
  return pieces[0].at(0);
}
const ringXY = (j) => pathXY((j + 0.5) * SP);                  // space j sits just past the corner of seat j/7
const cornerXY = (seat) => pathXY(seat * 7 * SP);
const dirOut = (seat) => { const [x, y] = cornerXY(seat), l = Math.hypot(x - CX, y - CY); return [(x - CX) / l, (y - CY) / l]; };
const LANE_AT = [325, 270, 215, 160];                         // how far from the middle each finish square is
const laneXY = (seat, k) => { const [ux, uy] = dirOut(seat); return [CX + ux * LANE_AT[k], CY + uy * LANE_AT[k]]; };
const homeCentre = (seat) => { const [ux, uy] = dirOut(seat); return [CX + ux * 520, CY + uy * 520]; };
const homeXY = (seat, peg) => { const [ux, uy] = dirOut(seat), [cx, cy] = homeCentre(seat); return [cx - uy * (peg - 1.5) * 58, cy + ux * (peg - 1.5) * 58]; };
/** Where a peg stands: progress -1 = at home, 0..27 = the ring, 28..31 = its finish lane. */
const lerp2 = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
/** Like spotXY, but progress can be a fraction: a point part-way between two squares, following the curve of the track. */
function posAt(seat, peg, f) {
  if (f <= -1) return homeXY(seat, peg);
  if (f < 0) return lerp2(homeXY(seat, peg), ringXY(seat * 7), f + 1);
  if (f <= 27) return pathXY((seat * 7 + f + 0.5) * SP);
  if (f < 28) return lerp2(ringXY((seat * 7 + 27) % 28), laneXY(seat, 0), f - 27);
  const k = Math.min(3, f - 28), k0 = Math.floor(k);
  return lerp2(laneXY(seat, k0), laneXY(seat, Math.min(3, k0 + 1)), k - k0);
}
const spotXY = (seat, peg, p) => p < 0 ? homeXY(seat, peg) : p < 28 ? ringXY((seat * 7 + p) % 28) : laneXY(seat, p - 28);

// ----- the star board (5 players): 30 squares round a five-point star, three squares along each of its ten edges -----
const STAR_SEATS = [
  { name: "Blue",   c: "#4A82AE", d: "#2E5B80" },
  { name: "Red",    c: "#C8553D", d: "#8F3524" },
  { name: "Green",  c: "#5B9A6B", d: "#38694A" },
  { name: "Yellow", c: "#E2B33D", d: "#A97E16" },
  { name: "Purple", c: "#8E5BB5", d: "#5F3A80" }
];
const S_RING = 30, S_GAP = 6, S_RO = 360, S_RI = 205;           // squares, squares between start spaces, tip radius, notch radius
const sAngle = (i) => (-90 + 36 * i) * Math.PI / 180;           // vertex i of the star outline: even = a tip, odd = a notch (clockwise from the top)
const sVert = (i) => { const r = ((i % 2) + 2) % 2 === 0 ? S_RO : S_RI, a = sAngle(((i % 10) + 10) % 10); return [CX + r * Math.cos(a), CY + r * Math.sin(a)]; };
const S_EDGE = Math.hypot(sVert(0)[0] - sVert(1)[0], sVert(0)[1] - sVert(1)[1]), S_SP = S_EDGE / 3, S_PERIM = S_EDGE * 10;
const lerpPt = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
/** The point d units clockwise round the star outline, counting from the top tip. */
function starXY(d) {
  d = ((d % S_PERIM) + S_PERIM) % S_PERIM;
  const e = Math.min(9, Math.floor(d / S_EDGE));
  return lerpPt(sVert(e), sVert(e + 1), (d - e * S_EDGE) / S_EDGE);
}
const sRingXY = (j) => starXY(j * S_SP);
const sDir = (seat) => [Math.cos(sAngle(seat * 2)), Math.sin(sAngle(seat * 2))];
const S_LANE = [255, 203, 151, 99];                              // how far from the middle each finish square is
const sLaneXY = (seat, k) => { const [ux, uy] = sDir(seat); return [CX + ux * S_LANE[k], CY + uy * S_LANE[k]]; };
const sHomeXY = (seat, peg) => { const [ux, uy] = sDir(seat); return [CX + ux * 440 - uy * (peg - 1.5) * 58, CY + uy * 440 + ux * (peg - 1.5) * 58]; };
function sPosAt(seat, peg, f) {
  if (f <= -1) return sHomeXY(seat, peg);
  if (f < 0) return lerpPt(sHomeXY(seat, peg), sRingXY(seat * S_GAP), f + 1);
  if (f <= S_RING - 1) return starXY((seat * S_GAP + f) * S_SP);
  if (f < S_RING) return lerpPt(sRingXY((seat * S_GAP + S_RING - 1) % S_RING), sLaneXY(seat, 0), f - (S_RING - 1));
  const k = Math.min(3, f - S_RING), k0 = Math.floor(k);
  return lerpPt(sLaneXY(seat, k0), sLaneXY(seat, Math.min(3, k0 + 1)), k - k0);
}
const sSpotXY = (seat, peg, p) => p < 0 ? sHomeXY(seat, peg) : p < S_RING ? sRingXY((seat * S_GAP + p) % S_RING) : sLaneXY(seat, p - S_RING);

function starSVG() {
  const rnd = rng(20241121), p = [];
  const off = () => 0;                                          // clean, straight printing: no wobble
  p.push(`<defs></defs>`);
  p.push(`<rect x="-14" y="-14" width="${SIZE + 28}" height="${SIZE + 28}" rx="10" fill="#8b6a45"/>`);
  p.push(`<rect x="-9" y="-9" width="${SIZE + 18}" height="${SIZE + 18}" rx="7" fill="#EFE3C4"/>`);
  p.push(`<rect x="-9" y="-9" width="${SIZE + 18}" height="${SIZE + 18}" rx="7" fill="none" stroke="${INK}" stroke-width="2.5"/>`);
  p.push(`<g>`);
  const pt = (v) => `${v[0].toFixed(1)},${v[1].toFixed(1)}`;
  for (let sd = 0; sd < 5; sd++) { const [tx, ty] = sVert(sd * 2), [lx, ly] = sLaneXY(sd, 3); p.push(`<line x1="${tx}" y1="${ty}" x2="${lx}" y2="${ly}" stroke="${INK}" stroke-width="66" stroke-linecap="round"/>`); }
  p.push(`<polygon points="${Array.from({ length: 10 }, (_, i) => pt(sVert(i))).join(" ")}" fill="none" stroke="${INK}" stroke-width="66" stroke-linejoin="round"/>`);
  for (let sd = 0; sd < 5; sd++) {                                  // each player's colour is printed over their own point of the star
    const c = STAR_SEATS[sd], [tx, ty] = sVert(sd * 2), [lx, ly] = sLaneXY(sd, 3);
    p.push(`<line x1="${tx + off()}" y1="${ty + off()}" x2="${lx + off()}" y2="${ly + off()}" stroke="${c.c}" stroke-width="58" stroke-linecap="round"/>`);
  }
  p.push(blendedRibbon(starXY, -S_EDGE, S_PERIM, STAR_SEATS.map(c => c.c), 58));    // the five colours melt into one another round the star
  p.push(`<circle cx="${CX}" cy="${CY}" r="112" fill="#D9CDAA" stroke="${INK}" stroke-width="4"/>`);   // the middle piece the dome sits in
  const hole = (x, y, r) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#F7EFD8" stroke="${INK}" stroke-width="2.6"/>`;
  for (let j = 0; j < S_RING; j++) {
    const [x, y] = sRingXY(j), start = j % S_GAP === 0;
    if (start) p.push(`<circle cx="${x}" cy="${y}" r="33" fill="none" stroke="${INK}" stroke-width="2.6"/>`);
    p.push(hole(x, y, start ? 24 : 22));
  }
  for (let sd = 0; sd < 5; sd++) {
    for (let k = 0; k < 4; k++) { const [x, y] = sLaneXY(sd, k); p.push(hole(x, y, 22)); }
    { const [fx, fy] = sLaneXY(sd, 3); p.push(fish(fx, fy + 1, .78)); }
    for (let k = 0; k < 4; k++) { const [x, y] = sHomeXY(sd, k); p.push(`<circle cx="${x}" cy="${y}" r="26" fill="${STAR_SEATS[sd].c}" stroke="${INK}" stroke-width="2.6"/><circle cx="${x}" cy="${y}" r="16" fill="#F7EFD8" stroke="${INK}" stroke-width="2.2"/>`); }
  }
  p.push(`<text x="${CX}" y="${SIZE - 40}" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-weight="700" font-style="italic" font-size="44" fill="${INK}" opacity=".85" letter-spacing="3">Benson Star</text>`);
  p.push(`</g>`);
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", `-14 -14 ${SIZE + 28} ${SIZE + 28}`);
  svg.setAttribute("class", "tr-svg");
  svg.setAttribute("shape-rendering", "geometricPrecision");
  svg.setAttribute("text-rendering", "geometricPrecision");
  svg.innerHTML = p.join("");
  return svg;
}

/** One board map: everything the page needs to draw it and to move cats on it. */
const CLASSIC = { id: "trouble", name: "Benson", players: 4, ring: 28, seats: SEATS, svg: () => boardSVG(), homeXY, posAt, spotXY };
const STAR = { id: "trouble-star", name: "Benson Star", players: 5, ring: S_RING, seats: STAR_SEATS, svg: starSVG, homeXY: sHomeXY, posAt: sPosAt, spotXY: sSpotXY };

export default {
  id: "trouble",
  name: "Benson",
  theme: "theme-trouble",
  artClass: "art-trouble",
  blurb: "",
  art: () => ["tabby", "tuxedo", "siamese", "calico"].map((k, i) => catPiece(k, 64, SEATS[i].c)),
  picker: catPicker,
  lobbyIcon: (choice) => catPiece(choice, 30),
  /** The create-room screen offers these board maps; the one picked decides which table is made. */
  maps: [
    { id: "trouble", name: "Classic", note: "Square board · 4 players" },
    { id: "trouble-star", name: "Star", note: "Star board · 5 players" }
  ],
  create: (area, api) => create(area, api, CLASSIC)
};

/** The star map's own game entry (it isn't a card on the home page: you pick it when you make a Benson room). */
export const troubleStar = {
  id: "trouble-star",
  name: "Benson Star",
  theme: "theme-trouble",
  artClass: "art-trouble",
  blurb: "",
  art: () => ["tabby", "tuxedo", "siamese", "calico", "gray"].map((k, i) => catPiece(k, 64, STAR_SEATS[i].c)),
  picker: catPicker,
  lobbyIcon: (choice) => catPiece(choice, 30),
  create: (area, api) => create(area, api, STAR)
};

/** Waiting room: tap a cat to take it. If another player has it, you swap. */
export function catPicker(room, choose) {
  const mine = room.seats[room.you] && room.seats[room.you].choice;
  return h("div.panel",
    h("div.label", { style: { marginBottom: "10px" } }, "Pick a cat"),
    h("div.cat-picker", CAT_IDS.map(id => {
      const owner = room.seats.find(s => s.choice === id);
      const taken = owner && owner.seat !== room.you;
      return h("button.cat-card", {
        type: "button", class: (id === mine ? "picked " : "") + (taken ? "taken" : ""), "aria-pressed": id === mine ? "true" : "false",
        onclick: () => { if (id !== mine) choose(id); }
      }, catPiece(id, 76), h("strong", catName(id)),
        h("span.muted", taken ? `Swap with ${owner.name}` : id === mine ? "You" : ""));
    })));
}

// small printed pictures for the board
const paw = (x, y, k, fill, op = 1) => `<g transform="translate(${x} ${y}) scale(${k})" fill="${fill}" opacity="${op}"><ellipse cx="0" cy="6" rx="11" ry="9"/><ellipse cx="-13" cy="-8" rx="4.6" ry="6" transform="rotate(-22 -13 -8)"/><ellipse cx="-4.6" cy="-15" rx="4.6" ry="6.2"/><ellipse cx="4.6" cy="-15" rx="4.6" ry="6.2"/><ellipse cx="13" cy="-8" rx="4.6" ry="6" transform="rotate(22 13 -8)"/></g>`;
const fish = (x, y, k) => `<g transform="translate(${x} ${y}) scale(${k})" stroke="#2a1f18" stroke-width="2.2" stroke-linejoin="round"><path d="M-14 0 C-8 -10 6 -10 12 0 C6 10 -8 10 -14 0 Z" fill="#8FB4D0"/><path d="M11 0 L21 -8 L21 8 Z" fill="#6E9AB9"/><circle cx="-7" cy="-2" r="1.8" fill="#2a1f18" stroke="none"/></g>`;

/**
 * The coloured ribbon round the track. Each seat's colour melts smoothly into the next seat's (no hard edge),
 * drawn as many tiny overlapping round-capped pieces so every curve and corner stays perfectly smooth.
 * xy(d) gives the point d units along the track; the ribbon runs `total` units from `start`, split evenly between the seats.
 */
function blendedRibbon(xy, start, total, colors, width) {
  const n = colors.length, seg = total / n, fade = 70, step = 3.5, half = fade / 2, out = [];
  const rgb = (c) => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
  const smooth = (t) => t * t * (3 - 2 * t);
  const own = colors.map(rgb);
  for (let d = seg / 2; d < total + seg / 2; d += step) {     // begin in the middle of a seat's stretch, so the loop closes on a flat colour
    const mid = d + step / 2, k = Math.floor(mid / seg) % n, f = mid / seg - Math.floor(mid / seg);
    const fromStart = f * seg, toEnd = (1 - f) * seg;
    let c = own[k];
    if (fromStart < half) { const w = 0.5 * (1 - smooth(fromStart / half)), o = own[(k + n - 1) % n]; c = c.map((v, i) => v + (o[i] - v) * w); }
    else if (toEnd < half) { const w = 0.5 * (1 - smooth(toEnd / half)), o = own[(k + 1) % n]; c = c.map((v, i) => v + (o[i] - v) * w); }
    const [x0, y0] = xy(start + d), [x1, y1] = xy(start + d + step + 1.5);
    out.push(`<line x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke="rgb(${c.map(Math.round).join(",")})" stroke-width="${width}" stroke-linecap="round"/>`);
  }
  return out.join("");
}

// a tiny repeatable random, so the "printing" is the same every time
function rng(seed) { let x = seed >>> 0; return () => (x = (x * 1664525 + 1013904223) >>> 0) / 4294967296; }

function boardSVG() {
  const rnd = rng(20241026), p = [];
  const off = () => 0;                                          // clean, straight printing: no wobble
  const poly = (d0, d1) => { const pts = []; for (let d = d0; d <= d1 + 0.01; d += 7) { const [x, y] = pathXY(d); pts.push(`${x.toFixed(1)},${y.toFixed(1)}`); } return pts.join(" "); };
  // everything printed on the board gets a faint hand-inked wobble, and the cardboard a little grain
  p.push(`<defs></defs>`);
  // the cardboard: edge, face, ink outline
  p.push(`<rect x="-14" y="-14" width="${SIZE + 28}" height="${SIZE + 28}" rx="10" fill="#8b6a45"/>`);
  p.push(`<rect x="-9" y="-9" width="${SIZE + 18}" height="${SIZE + 18}" rx="7" fill="#EFE3C4"/>`);
  p.push(`<rect x="-9" y="-9" width="${SIZE + 18}" height="${SIZE + 18}" rx="7" fill="none" stroke="${INK}" stroke-width="2.5"/>`);
  p.push(`<g>`);
  // finish lanes and the track: an inked ribbon, then each player's colour printed over their stretch of it
  for (let sd = 0; sd < 4; sd++) { const [cx, cy] = cornerXY(sd), [lx, ly] = laneXY(sd, 3); p.push(`<line x1="${cx}" y1="${cy}" x2="${lx}" y2="${ly}" stroke="${INK}" stroke-width="66" stroke-linecap="round"/>`); }
  p.push(`<polyline points="${poly(0, PERIM)}" fill="none" stroke="${INK}" stroke-width="66" stroke-linejoin="round"/>`);
  for (let sd = 0; sd < 4; sd++) {
    const c = SEATS[sd], [cx, cy] = cornerXY(sd), [lx, ly] = laneXY(sd, 3);
    p.push(`<line x1="${cx + off()}" y1="${cy + off()}" x2="${lx + off()}" y2="${ly + off()}" stroke="${c.c}" stroke-width="58" stroke-linecap="round"/>`);
  }
  p.push(blendedRibbon(pathXY, -3 * SP, PERIM, SEATS.map(c => c.c), 58));          // the four colours melt into one another round the track
  // the middle piece the dome sits in
  const D = 150;
  p.push(`<path d="M${CX} ${CY - D} L${CX + D} ${CY} L${CX} ${CY + D} L${CX - D} ${CY} Z" fill="#D9CDAA" stroke="${INK}" stroke-width="4" stroke-linejoin="round"/>`);
  // holes
  const hole = (x, y, r) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#F7EFD8" stroke="${INK}" stroke-width="2.6"/>`;
  for (let j = 0; j < 28; j++) {
    const [x, y] = ringXY(j);
    if (j % 7 === 0) p.push(`<circle cx="${x}" cy="${y}" r="33" fill="none" stroke="${INK}" stroke-width="2.6"/>`);
    p.push(hole(x, y, j % 7 === 0 ? 24 : 22));
  }
  for (let sd = 0; sd < 4; sd++) {
    for (let k = 0; k < 4; k++) { const [x, y] = laneXY(sd, k); p.push(hole(x, y, 22)); }
    { const [fx, fy] = laneXY(sd, 3); p.push(fish(fx, fy + 1, .78)); }                         // a fish waits at the end of every lane
    for (let k = 0; k < 4; k++) { const [x, y] = homeXY(sd, k); p.push(`<circle cx="${x}" cy="${y}" r="26" fill="${SEATS[sd].c}" stroke="${INK}" stroke-width="2.6"/><circle cx="${x}" cy="${y}" r="16" fill="#F7EFD8" stroke="${INK}" stroke-width="2.2"/>`); }
    const [ux, uy] = dirOut(sd), [sx, sy] = ringXY(sd * 7);                       // a printed label beside each start space
    p.push(`<text x="${(sx + ux * 62).toFixed(1)}" y="${(sy + uy * 62 + 5).toFixed(1)}" text-anchor="middle" font-family="Georgia, serif" font-size="15" font-weight="700" fill="${INK}" opacity=".7" letter-spacing="3">START</text>`);
  }
  p.push(`<text x="${CX}" y="${SIZE - 54}" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-weight="700" font-style="italic" font-size="46" fill="${INK}" opacity=".85" letter-spacing="3">Benson</text>`);
  p.push(`${paw(CX - 215, SIZE - 66, .7, INK, .75)}${paw(CX + 215, SIZE - 66, .7, INK, .75)}`);
  p.push(`</g>`);
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", `-14 -14 ${SIZE + 28} ${SIZE + 28}`);
  svg.setAttribute("class", "tr-svg");
  svg.setAttribute("shape-rendering", "geometricPrecision");
  svg.setAttribute("text-rendering", "geometricPrecision");
  svg.innerHTML = p.join("");
  return svg;
}

function create(area, api, B) {
  let room = null, view = null, lastActions = -1, lastMatch = null, destroyed = false;
  let busy = false, waiting = false, dieText = "";
  const queue = [];
  const shown = Array(B.players * 4).fill(-1);
  const SEATS_ = B.seats, PLAYERS = B.players, RING = B.ring;

  // ----- the board and pegs -----
  const pegEls = [];
  for (let seat = 0; seat < PLAYERS; seat++) for (let peg = 0; peg < 4; peg++) {
    const el = h("div.tr-peg", { class: "snap" });
    el.addEventListener("click", () => pickPeg(seat, peg));
    pegEls.push(el);
  }
  const boardBox = h("div.tr-board");
  boardBox.appendChild(B.svg());
  pegEls.forEach(e => boardBox.appendChild(e));

  // ----- the dome: a real cube die that tumbles inside it -----
  const die = makeDie();
  const dome = h("button.tr-dome", { type: "button", "aria-label": "Roll die", onclick: () => doRoll() }, die.root);
  boardBox.appendChild(dome);
  const setFace = (n) => die.set(n);
  const startSpin = () => { dome.classList.add("pop"); die.spin(); };
  const stopSpin = (n) => { dome.classList.remove("pop"); die.set(n); };
  const wait = (ms) => new Promise(r => setTimeout(r, ms));
  async function dieRoll(n) {
    dome.classList.add("pop");
    die.land(n, 1500);
    await wait(1600);
    dome.classList.remove("pop");
  }

  // ----- the page -----
  const dieLine = h("div.tr-dieline");
  const rollBtn = h("button.btn.primary.tr-roll", { type: "button", onclick: () => doRoll() }, "Roll die");
  const strip = h("div.tr-players");
  const panel = h("div.tr-panel", dieLine, rollBtn);
  strip.style.gridTemplateColumns = `repeat(${PLAYERS}, 1fr)`;
  area.replaceChildren(h("div.tr-wrap" + (PLAYERS > 4 ? ".star" : ""), h("div.tr-boardwrap", boardBox), panel, strip));

  // ----- the cats: each player's four pieces are the cat they picked, standing on their team colour -----
  const choiceOf = (seat) => (room && room.seats[seat] && room.seats[seat].choice) || CAT_IDS[seat % CAT_IDS.length];
  function dressCats() {
    pegEls.forEach((el, i) => {
      const seat = i >> 2, kind = choiceOf(seat);
      if (el.dataset.kind === kind) return;
      el.dataset.kind = kind;
      const wrap = catPiece(kind, 100, SEATS_[seat].c);
      wrap.style.width = "100%"; wrap.style.height = "100%"; wrap.style.display = "block";
      el.replaceChildren(wrap);
    });
  }

  // ----- pegs -----
  function setPeg(seat, peg, p, how) {
    const i = seat * 4 + peg, el = pegEls[i];
    shown[i] = p;
    const [x, y] = B.spotXY(seat, peg, p);
    el.classList.toggle("snap", how === "snap");
    el.classList.toggle("slow", how === "slow");
    place(el, x, y);
  }
  function snapAll(pegs) { for (let i = 0; i < PLAYERS * 4; i++) setPeg(i >> 2, i & 3, pegs[i], "snap"); }
  const place = (el, x, y, up = 0) => {
    el.style.left = ((x + 14) / (SIZE + 28) * 100).toFixed(3) + "%";
    el.style.top = ((y - up + 14) / (SIZE + 28) * 100).toFixed(3) + "%";
    el.style.zIndex = String(Math.round(y) + 5 + (up > 0 ? 40 : 0));
  };
  /** Runs fn(u) every frame for `ms`, u from 0 to 1; fn returns [x, y, lift]. */
  const tween = (el, ms, fn) => new Promise(done => {
    el.classList.add("snap"); el.classList.remove("slow");
    const t0 = performance.now();
    const step = (now) => {
      const u = Math.min(1, (now - t0) / ms), [x, y, up] = fn(u);
      place(el, x, y, up);
      if (u < 1 && !destroyed) requestAnimationFrame(step); else done();
    };
    requestAnimationFrame(step);
  });
  async function hop(ev) {
    const { seat, peg } = ev, el = pegEls[seat * 4 + peg];
    setPeg(seat, peg, ev.from, "snap");                                  // start from where it is standing
    if (ev.from < 0) await tween(el, 600, (u) => { const e = u * u * (3 - 2 * u), [x, y] = B.posAt(seat, peg, -1 + e); return [x, y, 44 * Math.sin(Math.PI * u)]; });
    else {
      const n = ev.to - ev.from;
      await tween(el, n * 210 + 80, (u) => {                      // an even glide, with a small hop on each square
        const e = u < .5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2, f = ev.from + n * (0.15 * u + 0.85 * e), [x, y] = B.posAt(seat, peg, f);
        return [x, y, 15 * Math.sin(Math.PI * (((f - ev.from) % 1 + 1) % 1))];
      });
    }
    setPeg(seat, peg, ev.to, "snap");
    await wait(140);
    if (ev.capSeat >= 0) {
      const ci = ev.capSeat * 4 + ev.capPeg, cel = pegEls[ci];
      cel.classList.add("shake");
      await wait(420);
      cel.classList.remove("shake");
      const [x0, y0] = B.posAt(ev.capSeat, ev.capPeg, ev.capFrom), [x1, y1] = B.homeXY(ev.capSeat, ev.capPeg);
      await tween(cel, 750, (u) => { const e = u * u * (3 - 2 * u); return [x0 + (x1 - x0) * e, y0 + (y1 - y0) * e, 34 * Math.sin(Math.PI * u)]; });
      setPeg(ev.capSeat, ev.capPeg, -1, "snap");
      await wait(120);
    }
  }
  const nameOf = (s) => api.seatName(s) || SEATS_[s].name;
  async function play(ev) {
    if (ev.kind === "sync") { snapAll(ev.pegs); stopSpin(ev.die); return; }      // we missed something: jump to where everyone is, once the earlier moves have finished
    if (ev.kind === "roll" || ev.kind === "rollmove") await dieRoll(ev.die);
    else { setFace(ev.die); await wait(120); }
    if (ev.kind === "move" || ev.kind === "rollmove") await hop(ev);
    const who = ev.seat === api.you ? "You" : nameOf(ev.seat);
    const rolled = ev.seat === api.you ? "rolled" : "rolled";
    if (ev.kind === "roll" && !(view && view.pending > 0 && view.currentSeat === ev.seat))
      dieText = `${who} ${rolled} a ${ev.die}. No move.`;
    else if (ev.kind === "roll") dieText = "";
    else dieText = `${who} ${rolled} a ${ev.die}` + (ev.capSeat >= 0 ? ` and sent ${ev.capSeat === api.you ? "your" : nameOf(ev.capSeat) + "'s"} cat home!` : ".");
  }
  function next() {
    if (busy || destroyed) return;
    if (!queue.length) { paintStatus(); if (api.refresh) api.refresh(); return; }
    busy = true;
    paintStatus();
    play(queue.shift()).then(() => { busy = false; next(); });
  }

  // ----- what you can do -----
  const mine = () => !!view && !!room && room.status === "playing" && view.winner < 0 && view.currentSeat === api.you;
  const canRoll = () => mine() && view.pending === 0 && !busy && !waiting && queue.length === 0;
  const canPick = (seat, peg) => mine() && seat === api.you && view.pending > 0 && !busy && queue.length === 0 && (view.legal || []).includes(peg);
  function doRoll() {
    if (!canRoll()) return;
    waiting = true;
    startSpin();
    if (!api.sendQuiet({ kind: "roll" })) { waiting = false; stopSpin(view.last ? view.last.die : 1); api.toast("Reconnecting... try again in a moment."); }
    paintStatus();
  }
  function pickPeg(seat, peg) {
    if (!canPick(seat, peg)) return;
    waiting = true;
    if (!api.sendQuiet({ kind: "move", peg })) { waiting = false; api.toast("Reconnecting... try again in a moment."); }
    paintStatus();
  }

  function paintStatus() {
    dressCats();
    const pick = mine() && view.pending > 0 && !busy && !waiting && queue.length === 0;
    const roll = canRoll();
    dome.disabled = !roll;
    dome.classList.toggle("ready", roll);
    rollBtn.disabled = !roll;
    rollBtn.textContent = waiting ? "Rolling..." : roll ? "Roll die" : (view && view.winner >= 0) ? "Game over" : pick ? "Pick a cat" : "Waiting...";
    for (let i = 0; i < PLAYERS * 4; i++) {
      const seat = i >> 2, peg = i & 3, can = pick && seat === api.you && (view.legal || []).includes(peg);
      pegEls[i].classList.toggle("can", can);
      pegEls[i].classList.toggle("mine", seat === api.you);
    }
    dieLine.textContent = (view && view.winner < 0 && view.currentSeat >= 0 ? (view.currentSeat === api.you ? "Your turn!" : `${nameOf(view.currentSeat)}'s turn`) : "");
    strip.replaceChildren(...Array.from({ length: PLAYERS }, (_, seat) => {
      let home = 0, done = 0;
      if (view) for (let k = 0; k < 4; k++) { const p = view.pegs[seat * 4 + k]; if (p < 0) home++; else if (p >= RING) done++; }
      const turn = !!view && view.currentSeat === seat && view.winner < 0;
      return h("div.tr-player", { class: (turn ? "turn " : "") + (seat === api.you ? "you" : "") },
        catPiece(choiceOf(seat), 40, SEATS_[seat].c), h("strong", nameOf(seat)), h("span.muted", `Home ${home} · Done ${done}`));
    }));
  }

  return {
    update(r) {
      room = r;
      const v = r.view;
      if (!v) return;
      view = v;
      const fresh = r.match !== lastMatch || lastActions < 0 || v.actions < lastActions;
      if (fresh) {
        lastMatch = r.match; queue.length = 0; busy = false; waiting = false; dieText = "";
        lastActions = v.actions;
        stopSpin(v.last ? v.last.die : 1);
        snapAll(v.pegs);
        paintStatus();
        return;
      }
      if (v.actions > lastActions) {
        const ev = v.last, missed = v.actions - lastActions > 1;
        lastActions = v.actions;
        waiting = false;
        // Never move cats ahead of the animation: each update only adds to the queue, and the queue plays in order.
        if (missed || !ev) queue.push({ kind: "sync", pegs: v.pegs.slice(), die: v.last ? v.last.die : 1 });
        else queue.push(ev);
        next();
      } else if (!busy) {
        paintStatus();
      }
    },
    seatInfo(seat) { return catName(choiceOf(seat)); },
    seatIcon(seat) { return catPiece(choiceOf(seat), 30, SEATS_[seat].c); },
    banner(r) {
      const v = r.view;
      if (!v) return ["", false];
      if (v.winner >= 0) return [busy ? "" : `${nameOf(v.winner)} wins!`, false];
      const bot = r.seats[v.currentSeat] && r.seats[v.currentSeat].isBot;
      if (v.currentSeat === api.you) {
        if (busy || waiting) return ["", false];
        if (v.pending > 0) return ["Pick a cat to move.", true];
        const allHome = [0, 1, 2, 3].every(k => v.pegs[api.you * 4 + k] < 0);
        if (allHome && v.tries < 3) return [`No 1 or 6 yet. Try again (${v.tries} left).`, true];
        if (v.last && v.last.seat === api.you && (v.last.die === 6 || v.last.die === 1)) return [`You rolled a ${v.last.die}! Go again.`, true];
        return ["Your turn! Roll the die.", true];
      }
      return [busy ? "" : `${nameOf(v.currentSeat)}${bot ? " (bot)" : ""} is ${v.pending > 0 ? "choosing a cat" : "rolling"}...`, false];
    },
    ranking(r) {
      const v = r.view;
      if (!v) return [];
      return Array.from({ length: PLAYERS }, (_, seat) => {
        let done = 0, total = 0;
        for (let k = 0; k < 4; k++) { const p = v.pegs[seat * 4 + k]; if (p >= RING) done++; total += Math.max(p, 0); }
        return { seat, done, total };
      }).sort((a, b) => b.done - a.done || b.total - a.total)
        .map(x => ({ seat: x.seat, text: x.done === 4 ? "Got all four cats home!" : `${x.done} of 4 cats home` }));
    },
    destroy() { destroyed = true; }
  };
}
