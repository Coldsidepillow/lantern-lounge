// Cats and Ladders online: a 100-square board with ladders up and chutes down, four cat pieces, and a die you can watch roll.
// The server rolls the die (so nobody can cheat). This page plays back each roll: the die tumbles, the cat hops
// square by square, and then climbs a ladder or slides down a chute.
import { h } from "../ui.js";
import { CAT_IDS, CATS, catName, catPiece } from "./catpieces.js";

const SIZE = 1000;                    // the board is 10 x 10 squares of 100 units
const PAD_BOTTOM = 90;                // a strip under the board where cats wait before square 1
// A printed-board palette: a handful of flat inks, not a rainbow of pastels
const PALETTE = ["#E2B33D", "#C8553D", "#5B9A6B", "#4A82AE", "#D9803C"];
const INK = "#3a2a1f";
const CHUTE_COLORS = [["#C8553D", "#8F3524"], ["#4A82AE", "#2E5B80"], ["#5B9A6B", "#38694A"], ["#E2B33D", "#A97E16"], ["#8C5E9B", "#5E3A6E"]];
const REACTIONS = [["smile", "😊", "Smile"], ["sad", "😢", "Sad"], ["angry", "😠", "Angry"], ["kiss", "😘", "Blow a kiss"], ["peace", "✌️", "Peace"]];
const SLOTS = [[-20, -14], [20, -14], [-20, 20], [20, 20]];   // where up to four cats stand inside one square

export default {
  id: "cats-and-ladders",
  name: "Cats and Ladders",
  theme: "theme-cats",
  artClass: "art-cats",
  blurb: "",
  art: () => ["tabby", "tuxedo", "siamese", "calico"].map(k => catPiece(k, 64)),
  picker: catPicker,
  lobbyIcon: (choice) => catPiece(choice, 30),
  create
};

/** Waiting room: tap a cat to take it. If another player has it, you swap. */
export function catPicker(room, choose) {
  const mine = room.seats[room.you] && room.seats[room.you].choice;
  return h("div.panel",
    h("div.label", { style: { marginBottom: "10px" } }, "Pick your cat"),
    h("div.cat-picker", CAT_IDS.map(id => {
      const owner = room.seats.find(s => s.choice === id);
      const taken = owner && owner.seat !== room.you;
      return h("button.cat-card", {
        type: "button", class: (id === mine ? "picked " : "") + (taken ? "taken" : ""), "aria-pressed": id === mine ? "true" : "false",
        onclick: () => { if (id !== mine) choose(id); }
      }, catPiece(id, 76), h("strong", catName(id)),
        h("span.muted", taken ? `Swap with ${owner.name}` : id === mine ? "You" : ""));
    })));
}

// ----- board geometry -----
const cellXY = (n) => {                // centre of square n (1..100), zig-zagging up the board
  const r = Math.floor((n - 1) / 10), c = r % 2 === 0 ? (n - 1) % 10 : 9 - ((n - 1) % 10);
  return [c * 100 + 50, (9 - r) * 100 + 50];
};
const spotXY = (n, slot) => {          // where a cat stands: in a square, or waiting under the board before square 1
  if (n <= 0) return [90 + slot * 78, SIZE + 52];
  const [x, y] = cellXY(n);
  return [x + SLOTS[slot][0] * 0.62, y + SLOTS[slot][1] * 0.62 + 6];
};

function rng(seed) { let t = seed >>> 0; return () => { t += 0x6D2B79F5; let r = Math.imul(t ^ (t >>> 15), 1 | t); r ^= r + Math.imul(r ^ (r >>> 7), 61 | r); return ((r ^ (r >>> 14)) >>> 0) / 4294967296; }; }

function boardSVG(view) {
  const NS = "http://www.w3.org/2000/svg";
  const R = rng(20241026);
  const parts = [];
  const H = SIZE + PAD_BOTTOM;
  // the cardboard: edge, face, a little wear
  parts.push(`<rect x="-14" y="-14" width="${SIZE + 28}" height="${H + 28}" rx="10" fill="#8b6a45"/>`);
  parts.push(`<rect x="-9" y="-9" width="${SIZE + 18}" height="${H + 18}" rx="7" fill="#EFE3C4"/>`);
  parts.push(`<rect x="-9" y="-9" width="${SIZE + 18}" height="${H + 18}" rx="7" fill="none" stroke="${INK}" stroke-width="2.5"/>`);
  // squares, printed slightly off-register like a real board
  for (let n = 1; n <= 100; n++) {
    const [cx, cy] = cellXY(n), x = cx - 50, y = cy - 50;
    const color = PALETTE[(Math.floor((n - 1) / 10) * 2 + (n - 1)) % PALETTE.length];
    const ox = (R() - 0.5) * 3.2, oy = (R() - 0.5) * 3.2;
    parts.push(`<rect x="${x + 2 + ox}" y="${y + 2 + oy}" width="96" height="96" fill="${color}" opacity="${(0.9 + R() * 0.1).toFixed(2)}"/>`);
    parts.push(`<rect x="${x + 2}" y="${y + 2}" width="96" height="96" fill="none" stroke="${INK}" stroke-width="2.2" opacity=".8"/>`);
  }
  // the last square: a bowl of fish
  const [fx, fy] = cellXY(100);
  parts.push(`<rect x="${fx - 48}" y="${fy - 48}" width="96" height="96" fill="#F4DE8E"/><rect x="${fx - 48}" y="${fy - 48}" width="96" height="96" fill="none" stroke="${INK}" stroke-width="2.2"/>
    <path d="M${fx - 30} ${fy + 2} Q${fx - 30} ${fy + 34} ${fx} ${fy + 34} Q${fx + 30} ${fy + 34} ${fx + 30} ${fy + 2} Z" fill="#C8553D" stroke="${INK}" stroke-width="2.5" stroke-linejoin="round"/>
    <ellipse cx="${fx}" cy="${fy + 2}" rx="30" ry="8" fill="#7a3a28" stroke="${INK}" stroke-width="2.5"/>
    <path d="M${fx - 17} ${fy - 2} q9 -16 24 -6 l9 -6 l-2 14 l2 14 l-9 -6 q-15 8 -24 -6 z" fill="#8FB4D0" stroke="${INK}" stroke-width="2.2" stroke-linejoin="round" transform="translate(-4 -9) scale(.95)"/><circle cx="${fx - 9}" cy="${fy - 12}" r="1.8" fill="${INK}"/>`);
  // the title band under the board
  parts.push(`<text x="${SIZE - 270}" y="${SIZE + 60}" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-weight="700" font-style="italic" font-size="46" fill="${INK}" opacity=".85" letter-spacing="1">Cats &amp; Ladders</text>`);
  parts.push(`<text x="362" y="${SIZE + 36}" font-family="Georgia, serif" font-size="17" font-weight="700" fill="${INK}" opacity=".7" letter-spacing="3">← START</text>`);
  parts.push(``);

  // chutes: flat painted slides with an ink outline, drawn a little loosely
  (view.chutes || []).forEach(([top, bottom], i) => {
    const [x1, y1] = cellXY(top), [x2, y2] = cellXY(bottom), [c1, c2] = CHUTE_COLORS[i % CHUTE_COLORS.length];
    const mx = (x1 + x2) / 2, my = (y1 + y2) / 2, dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy) || 1;
    const bow = (i % 2 ? 1 : -1) * Math.min(110, len * 0.26) * (0.8 + R() * 0.4);
    const qx = mx - (dy / len) * bow, qy = my + (dx / len) * bow;
    const d = `M${x1} ${y1} Q${qx} ${qy} ${x2} ${y2}`;
    parts.push(`<g class="chute"><path d="${d}" stroke="rgba(40,25,10,.28)" stroke-width="38" fill="none" stroke-linecap="round" transform="translate(4 6)"/>
      <path d="${d}" stroke="${INK}" stroke-width="38" fill="none" stroke-linecap="round"/>
      <path d="${d}" stroke="${c1}" stroke-width="31" fill="none" stroke-linecap="round"/>
      <path d="${d}" stroke="${c2}" stroke-width="3" fill="none" stroke-linecap="round" stroke-dasharray="2 14" transform="translate(0 2)"/>
      <circle cx="${x1}" cy="${y1}" r="22" fill="${INK}"/><circle cx="${x1}" cy="${y1}" r="17" fill="${c2}"/>
      <circle cx="${x2}" cy="${y2}" r="17" fill="${INK}"/><circle cx="${x2}" cy="${y2}" r="12" fill="${c2}"/></g>`);
  });
  // ladders: plain wood, uneven, with nails and grain
  (view.ladders || []).forEach(([bottom, top]) => {
    const [x1, y1] = cellXY(bottom), [x2, y2] = cellXY(top);
    const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len, px = -uy, py = ux, w = 17;
    const rungs = Math.max(3, Math.round(len / 44));
    let g = `<g class="ladder">`;
    for (const side of [1, -1]) {
      const sx = x1 + px * w * side, sy = y1 + py * w * side, ex = x2 + px * w * side + (R() - 0.5) * 6, ey = y2 + py * w * side + (R() - 0.5) * 6;
      g += `<line x1="${sx + 3}" y1="${sy + 5}" x2="${ex + 3}" y2="${ey + 5}" stroke="rgba(40,25,10,.3)" stroke-width="12" stroke-linecap="butt"/>`;
      g += `<line x1="${sx}" y1="${sy}" x2="${ex}" y2="${ey}" stroke="${INK}" stroke-width="12" stroke-linecap="butt"/><line x1="${sx}" y1="${sy}" x2="${ex}" y2="${ey}" stroke="#B98245" stroke-width="8" stroke-linecap="butt"/>`;
      g += `<line x1="${sx + px * 1.5}" y1="${sy + py * 1.5}" x2="${ex + px * 1.5}" y2="${ey + py * 1.5}" stroke="#8a5a2b" stroke-width="1.2" opacity=".7"/>`;
    }
    for (let k = 0; k <= rungs; k++) {
      const t = (k + 0.5) / (rungs + 1), rx = x1 + dx * t, ry = y1 + dy * t, j = (R() - 0.5) * 3;
      g += `<line x1="${rx + px * (w + 3) + ux * j}" y1="${ry + py * (w + 3) + uy * j}" x2="${rx - px * (w + 3) + ux * j}" y2="${ry - py * (w + 3) + uy * j}" stroke="${INK}" stroke-width="9" stroke-linecap="butt"/>`;
      g += `<line x1="${rx + px * (w + 2) + ux * j}" y1="${ry + py * (w + 2) + uy * j}" x2="${rx - px * (w + 2) + ux * j}" y2="${ry - py * (w + 2) + uy * j}" stroke="#D2A064" stroke-width="5.2" stroke-linecap="butt"/>`;
      g += `<circle cx="${rx + px * w}" cy="${ry + py * w}" r="1.6" fill="#5a3a1c"/><circle cx="${rx - px * w}" cy="${ry - py * w}" r="1.6" fill="#5a3a1c"/>`;
    }
    parts.push(g + "</g>");
  });
  for (let n = 1; n < 100; n++) {   // printed numbers, over the ladders and chutes so you can always read them
    const [cx, cy] = cellXY(n);
    parts.push(`<text x="${cx - 40}" y="${cy - 22}" font-family="Georgia, 'Times New Roman', serif" font-size="21" font-weight="700" fill="${INK}" stroke="rgba(255,248,230,.85)" stroke-width="3.2" paint-order="stroke" stroke-linejoin="round">${n}</text>`);
  }
  parts.push(`<text x="${fx - 41}" y="${fy - 23}" font-family="Georgia, serif" font-size="21" font-weight="700" fill="${INK}">100</text>`);
  // the board folds in half: a crease across the middle, and paper grain over everything
  parts.push(`<rect x="-9" y="${H / 2 - 6}" width="${SIZE + 18}" height="12" fill="url(#crease)"/>`);
  parts.push(`<rect x="-9" y="-9" width="${SIZE + 18}" height="${H + 18}" rx="7" filter="url(#grain)" opacity=".55" style="mix-blend-mode:multiply"/>`);
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", `-14 -14 ${SIZE + 28} ${H + 28}`);
  svg.setAttribute("class", "cl-svg");
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", "The Cats and Ladders board: squares 1 to 100 with ladders and chutes");
  svg.innerHTML = `<defs>
    <filter id="grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="7" result="n"/><feColorMatrix in="n" values="0 0 0 0 .35  0 0 0 0 .25  0 0 0 0 .12  0 0 0 .55 0"/></filter>
    <linearGradient id="crease" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset=".46" stop-color="#000" stop-opacity=".10"/><stop offset=".5" stop-color="#fff" stop-opacity=".22"/><stop offset=".54" stop-color="#000" stop-opacity=".12"/><stop offset="1" stop-color="#000" stop-opacity="0"/></linearGradient>
  </defs>` + parts.join("");
  return svg;
}

// ----- the die: a real cube, turned with CSS 3D -----
const PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };
const FACE_FOR = { 1: [0, 0], 2: [0, -90], 3: [-90, 0], 4: [90, 0], 5: [0, 90], 6: [0, 180] };   // rotateX, rotateY that bring face n to the front
function makeDie() {
  const faces = [[1, "translateZ(var(--h))"], [2, "rotateY(90deg) translateZ(var(--h))"], [3, "rotateX(90deg) translateZ(var(--h))"],
    [4, "rotateX(-90deg) translateZ(var(--h))"], [5, "rotateY(-90deg) translateZ(var(--h))"], [6, "rotateY(180deg) translateZ(var(--h))"]]
    .map(([n, t]) => h("div.cl-face", { style: { transform: t } }, Array.from({ length: 9 }, (_, i) => h("i", { class: PIPS[n].includes(i) ? "pip" : "" }))));
  const cube = h("div.cl-cube", faces);
  const hopper = h("div.cl-hopper", cube);
  const shadow = h("div.cl-die-shadow");
  const root = h("div.cl-die", { "aria-hidden": "true" }, shadow, hopper);
  const setFace = (n) => { const [x, y] = FACE_FOR[n]; cube.style.animation = "none"; cube.style.transform = `rotateX(${x}deg) rotateY(${y}deg)`; };
  setFace(1);
  return {
    root,
    spin() { hopper.style.animation = "none"; cube.style.transform = ""; cube.style.animation = "cl-spin .55s linear infinite"; },
    /** Tumble across the table and land showing `n`. */
    land(n, ms = 1250) {
      const [x, y] = FACE_FOR[n];
      cube.style.animation = "none"; hopper.style.animation = "none"; shadow.style.animation = "none";
      void cube.offsetWidth;                                   // restart the animations
      cube.style.setProperty("--x0", `${(Math.random() < 0.5 ? -1 : 1) * 720}deg`);
      cube.style.setProperty("--y0", `${(Math.random() < 0.5 ? -1 : 1) * 1080}deg`);
      cube.style.setProperty("--xf", `${x}deg`); cube.style.setProperty("--yf", `${y}deg`);
      cube.style.animation = `cl-tumble ${ms}ms cubic-bezier(.17,.67,.35,1) forwards`;
      hopper.style.animation = `cl-toss ${ms}ms ease-out forwards`;
      shadow.style.animation = `cl-toss-shadow ${ms}ms ease-out forwards`;
      cube.style.transform = `rotateX(${x}deg) rotateY(${y}deg)`;
    },
    set: setFace
  };
}

function create(area, api) {
  let room = null, view = null;
  let lastMatch = -1, lastRolls = -1;
  let waiting = false;                      // my roll was sent; the die spins until the server answers
  let busy = false;                         // an animation is playing
  let destroyed = false;
  const queue = [];                         // rolls still to play back
  const shown = [0, 0, 0, 0];               // the square each cat is drawn on right now
  const pos = [[0, 0], [0, 0], [0, 0], [0, 0]];   // where each cat is drawn, in board units (x, y, hop height)
  const hop = [0, 0, 0, 0];
  let dieText = "";
  let rollerSeat = -1;

  const die = makeDie();
  const rollBtn = h("button.btn.primary.cl-roll", { type: "button", onclick: () => doRoll() }, "Roll the die");
  const dieLine = h("div.cl-dieline");
  // little reactions: sent after your own turn is over, so they never hold up the game
  let lastReact = 0;
  const reactBtns = REACTIONS.map(([id, emoji, name]) => h("button.cl-react", { type: "button", title: name, "aria-label": name, onclick: () => react(id) }, emoji));
  const reactRow = h("div.cl-reactrow", h("span.muted", "React:"), ...reactBtns);
  const dicePanel = h("div.cl-dicepanel", die.root, h("div.cl-dicecol", dieLine, rollBtn, reactRow));
  const boardBox = h("div.cl-board");
  const tokens = [0, 1, 2, 3].map(() => h("div.cl-token"));
  const strip = h("div.cl-players");
  const boardWrap = h("div.cl-boardwrap", boardBox);
  area.appendChild(h("div.cl-wrap", boardWrap, dicePanel, strip));

  let boardBuilt = false;
  function buildBoard() {
    if (boardBuilt || !view) return;
    boardBuilt = true;
    boardBox.replaceChildren(boardSVG(view), ...tokens);
  }

  const choiceOf = (seat) => (room && room.seats[seat] && room.seats[seat].choice) || CAT_IDS[seat % CAT_IDS.length];
  function dressTokens() {
    tokens.forEach((t, seat) => {
      const kind = choiceOf(seat);
      if (t.dataset.kind !== kind) { t.dataset.kind = kind; t.replaceChildren(catPiece(kind, 100)); t.querySelector(".cat-wrap").style.height = "100%"; t.querySelector(".cat-wrap").style.width = "100%"; }
    });
  }
  const unit = (v, total) => (v / total * 100).toFixed(3) + "%";
  const W = SIZE + 28, Ht = SIZE + PAD_BOTTOM + 28;
  function placeTokens() {
    // cats on the same square stand in their own corner
    tokens.forEach((t, seat) => {
      const [x, y] = pos[seat];
      t.style.left = unit(x + 14, W);
      t.style.top = unit(y + 14 - 36 - hop[seat], Ht);
      t.style.zIndex = String(Math.round(y) + 5);
      t.classList.toggle("turn", !!view && view.currentSeat === seat && !busy && view.winner < 0);
    });
  }
  function snap(seat, sq) { shown[seat] = sq; const [x, y] = spotXY(sq, seat); pos[seat] = [x, y]; hop[seat] = 0; }
  function snapAll(squares) { for (let s = 0; s < 4; s++) snap(s, squares[s]); placeTokens(); }

  // ----- playing back a roll -----
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const ease = (t) => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  function tween(ms, fn) {
    return new Promise(resolve => {
      const t0 = performance.now();
      const f = (now) => {
        if (destroyed) return resolve();
        const t = Math.min(1, (now - t0) / ms);
        fn(t);
        placeTokens();
        if (t < 1) requestAnimationFrame(f); else resolve();
      };
      requestAnimationFrame(f);
    });
  }
  const snd = (name) => { try { if (api.sound && api.sound[name]) api.sound[name](); } catch (e) { /* sound is a bonus */ } };

  async function play(ev) {
    busy = true;
    rollerSeat = ev.seat;
    dieText = "";
    paintStatus();
    die.land(ev.die);
    snd("tap");
    await sleep(1350);
    if (destroyed) return;
    dieText = `${api.seatName(ev.seat)} rolled a ${ev.die}`;
    paintStatus();
    // hop along the squares
    if (ev.kind === "stuck") {
      await tween(420, (t) => { hop[ev.seat] = Math.sin(t * Math.PI * 3) * 10 * (1 - t); });
      hop[ev.seat] = 0;
      dieText += ": too high, stay put!";
    } else {
      const steps = ev.landed - ev.from;
      let at = ev.from;
      for (let i = 1; i <= steps; i++) {
        const [x0, y0] = spotXY(at, ev.seat), next = ev.from + i, [x1, y1] = spotXY(next, ev.seat);
        await tween(200, (t) => { pos[ev.seat] = [x0 + (x1 - x0) * ease(t), y0 + (y1 - y0) * ease(t)]; hop[ev.seat] = Math.sin(t * Math.PI) * 34; });
        at = next; shown[ev.seat] = next; hop[ev.seat] = 0;
        snd("tap");
      }
      if (ev.to !== ev.landed) {
        const up = ev.kind === "ladder";
        dieText += up ? ": a ladder, up you go!" : ": a chute, wheee!";
        paintStatus();
        await sleep(350);
        const [x0, y0] = spotXY(ev.landed, ev.seat), [x1, y1] = spotXY(ev.to, ev.seat);
        snd(up ? "win" : "oops");
        await tween(up ? 1100 : 900, (t) => { const e = ease(t); pos[ev.seat] = [x0 + (x1 - x0) * e, y0 + (y1 - y0) * e]; hop[ev.seat] = Math.sin(t * Math.PI) * (up ? 14 : 24); });
        hop[ev.seat] = 0; shown[ev.seat] = ev.to;
      }
    }
    if (view && view.winner === ev.seat && ev.to === 100) { dieText = `${api.seatName(ev.seat)} reached the fish bowl!`; snd("win"); }
    paintStatus();
    busy = false;
    next();
  }
  function next() {
    if (busy || destroyed) return;
    const ev = queue.shift();
    if (ev) { play(ev); return; }
    snapAll(view ? view.positions : [0, 0, 0, 0]);
    paintStatus();
  }

  // ----- sending my roll -----
  function doRoll() {
    if (!canRoll()) return;
    waiting = true;
    die.spin();
    if (!api.sendQuiet({ kind: "roll" })) { waiting = false; die.set(1); api.toast("Reconnecting... try again in a moment."); }
    paintStatus();
  }
  const canReact = () => !!view && !!room && room.status === "playing" && view.winner < 0 && view.currentSeat !== api.you && api.you >= 0 && !(busy && rollerSeat === api.you);
  function react(id) {
    const now = performance.now();
    if (!canReact() || now - lastReact < 1500) return;
    lastReact = now;
    if (api.sendQuiet({ kind: "react", emoji: id })) { skipEcho = true; showBubble(api.you, id); }
    else api.toast("Reconnecting... try again in a moment.");
  }
  const bubbles = [null, null, null, null], lastMoodNo = [0, 0, 0, 0];
  let skipEcho = false;                     // my own reaction is already on screen; don't pop it a second time when the server answers
  function showBubble(seat, id) {
    const entry = REACTIONS.find(r => r[0] === id);
    if (!entry) return;
    const t = tokens[seat];
    if (bubbles[seat]) bubbles[seat].remove();
    const b = h("div.cl-bubble", entry[1]);
    t.appendChild(b); bubbles[seat] = b;
    setTimeout(() => { if (bubbles[seat] === b) { b.remove(); bubbles[seat] = null; } }, 3200);
  }
  function takeReactions(fresh) {
    if (!view || !view.moodNos) return;
    for (let s = 0; s < 4; s++) {
      const n = view.moodNos[s] || 0;
      if (!fresh && n > lastMoodNo[s] && view.moods && view.moods[s]) {
        if (s === api.you && skipEcho) skipEcho = false; else showBubble(s, view.moods[s]);
      }
      lastMoodNo[s] = n;
    }
  }
  const canRoll = () => !!view && !!room && room.status === "playing" && view.winner < 0 && view.currentSeat === api.you && !busy && !waiting && queue.length === 0;

  // ----- page text -----
  function paintStatus() {
    dressTokens();
    dieLine.textContent = (view && view.currentSeat >= 0 ? (view.currentSeat === api.you ? "Your turn!" : `${api.seatName(view.currentSeat)}'s turn`) : "");
    const mine = canRoll();
    rollBtn.disabled = !mine;
    rollBtn.classList.toggle("ready", mine);
    const rc = canReact();
    reactBtns.forEach(b => { b.disabled = !rc; });
    reactRow.classList.toggle("off", !rc);
    rollBtn.textContent = waiting ? "Rolling..." : mine ? "Roll the die" : (view && view.winner >= 0) ? "Game over" : "Waiting...";
    strip.replaceChildren(...[0, 1, 2, 3].map(seat => {
      const turn = !!view && view.currentSeat === seat && view.winner < 0;
      return h("div.cl-player", { class: (turn ? "turn " : "") + (seat === api.you ? "you" : "") },
        catPiece(choiceOf(seat), 46), h("strong", api.seatName(seat) || `Seat ${seat + 1}`),
        h("span.muted", shown[seat] <= 0 ? "Start" : `Square ${shown[seat]}`));
    }));
    placeTokens();
  }

  return {
    update(r) {
      room = r;
      const next_ = r.view;
      if (!next_) return;
      const fresh = r.match !== lastMatch || lastRolls < 0 || next_.rolls < lastRolls;
      view = next_;
      buildBoard();
      takeReactions(r.match !== lastMatch || lastRolls < 0);
      if (fresh) {
        lastMatch = r.match; queue.length = 0; busy = false; waiting = false; rollerSeat = -1; dieText = "";
        lastRolls = view.rolls;
        snapAll(view.positions);
        die.set(view.last ? view.last.die : 1);
        paintStatus();
        return;
      }
      if (view.rolls > lastRolls) {
        const ev = view.last;
        if (view.rolls - lastRolls > 1 || !ev) {   // missed some rolls: jump everyone to where they are, then show the last one
          for (let s = 0; s < 4; s++) if (!ev || s !== ev.seat) snap(s, view.positions[s]);
        }
        if (ev) { snap(ev.seat, ev.from); queue.push(ev); }
        lastRolls = view.rolls;
        if (ev && ev.seat === api.you) waiting = false;
        next();
      } else if (!busy) {
        paintStatus();
      }
    },
    seatInfo(seat) { return catName(choiceOf(seat)); },
    seatIcon(seat) { return catPiece(choiceOf(seat), 30); },
    banner(r) {
      const v = r.view;
      if (!v) return ["", false];
      if (v.winner >= 0) return [busy ? "" : `${api.seatName(v.winner)} wins!`, false];
      if (v.currentSeat === api.you) return [busy || waiting ? "" : "Your turn! Roll the die.", !busy && !waiting];
      const bot = r.seats[v.currentSeat] && r.seats[v.currentSeat].isBot;
      return [busy ? "" : `${api.seatName(v.currentSeat)}${bot ? " (bot)" : ""} is rolling...`, false];
    },
    ranking(r) {
      const v = r.view;
      if (!v) return [];
      return [0, 1, 2, 3].map(seat => ({ seat, sq: v.positions[seat] })).sort((a, b) => b.sq - a.sq)
        .map(x => ({ seat: x.seat, text: x.sq >= 100 ? "Reached the fish bowl!" : `Square ${x.sq}` }));
    },
    destroy() { destroyed = true; }
  };
}
