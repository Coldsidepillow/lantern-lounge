// The Hide & Seek characters, drawn with plain canvas shapes (no image files needed).
// Each is a little round critter seen from a bit above, looking the way it walks.

export const CHARACTERS = [
  { id: "red-panda", name: "Red Panda", blurb: "Rusty fur, ringed tail, white cheeks." },
  { id: "siamese-cat", name: "Siamese Cat", blurb: "Cream coat, dark paws, bright blue eyes." },
  { id: "honey-badger", name: "Honey Badger", blurb: "Fearless, with a silver stripe down the back." },
  { id: "brown-cat", name: "Brown Cat", blurb: "A fluffy brown cat with a pink bow." },
  { id: "bobcat", name: "Bobcat", blurb: "Spotted tawny coat, tufted ears, a short bobbed tail." },
  { id: "grim-reaper", name: "Grim Reaper", blurb: "Hooded black robe, glowing eyes and a silver scythe." },
  { id: "monica", name: "Monica", blurb: "Orange cat in big black glasses and a nurse cap." },
  { id: "coleycanoli", name: "Coleycanoli", blurb: "Small blonde cat with hazel eyes and a fan of game cards." }
];

const byId = Object.fromEntries(CHARACTERS.map(c => [c.id, c]));
export const characterName = (id) => (byId[id] ? byId[id].name : "Critter");

function disc(ctx, x, y, r, fill, stroke, lw) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
}

function oval(ctx, x, y, rx, ry, rot, fill, stroke, lw) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
}

/**
 * Draws a character centred on (x, y), about `size` pixels wide.
 * (fx, fy) is the way it is facing; `t` is a time in seconds, for a little bobbing; `alpha` fades it (hiding).
 */
export function drawChar(ctx, id, x, y, size, fx = 0, fy = 1, t = 0, alpha = 1) {
  const len = Math.hypot(fx, fy) || 1;
  fx /= len; fy /= len;
  const u = size / 2;                       // one "unit": the body radius
  const px = -fy, py = fx;                  // sideways direction
  const bob = Math.sin(t * 9) * u * 0.04;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y + bob);
  // soft ground shadow
  oval(ctx, 0, u * 0.62, u * 0.85, u * 0.28, 0, "rgba(0,0,0,.28)");
  // everything below is drawn relative to the facing direction
  const at = (f, s) => [fx * f * u + px * s * u, fy * f * u + py * s * u];

  if (id === "red-panda") {
    const [tx, ty] = at(-1.15, 0);
    // ringed tail trailing behind
    oval(ctx, tx * 0.8, ty * 0.8, u * 0.55, u * 0.4, Math.atan2(fy, fx), "#c8582b", "#8b3a18", u * 0.06);
    for (let i = 0; i < 3; i++) {
      const [rx, ry] = at(-0.95 - i * 0.22, 0);
      oval(ctx, rx, ry, u * 0.09, u * 0.36, Math.atan2(fy, fx), "#5b2a14");
    }
    disc(ctx, 0, u * 0.1, u * 0.78, "#c8582b", "#8b3a18", u * 0.06);                  // body
    const [e1x, e1y] = at(0.25, -0.62), [e2x, e2y] = at(0.25, 0.62);
    disc(ctx, e1x, e1y - u * 0.15, u * 0.3, "#8b3a18"); disc(ctx, e2x, e2y - u * 0.15, u * 0.3, "#8b3a18");
    disc(ctx, e1x, e1y - u * 0.15, u * 0.17, "#f4e6d0"); disc(ctx, e2x, e2y - u * 0.15, u * 0.17, "#f4e6d0");
    const [hx, hy] = at(0.32, 0);
    disc(ctx, hx, hy - u * 0.1, u * 0.62, "#d96a33", "#8b3a18", u * 0.06);           // head
    const [c1x, c1y] = at(0.35, -0.38), [c2x, c2y] = at(0.35, 0.38);
    oval(ctx, c1x, c1y - u * 0.05, u * 0.26, u * 0.2, 0, "#fff6e8"); oval(ctx, c2x, c2y - u * 0.05, u * 0.26, u * 0.2, 0, "#fff6e8");
    face(ctx, at, u, fx, fy, "#2a1a14", "#2a1a14", -0.1);
  } else if (id === "siamese-cat") {
    const [tx, ty] = at(-1.1, 0.25);
    ctx.strokeStyle = "#4b3326"; ctx.lineWidth = u * 0.26; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(...at(-0.6, 0)); ctx.quadraticCurveTo(...at(-1.1, -0.35), tx, ty); ctx.stroke();
    disc(ctx, 0, u * 0.1, u * 0.76, "#f1e3c6", "#b79b72", u * 0.05);                  // body
    const [e1x, e1y] = at(0.2, -0.6), [e2x, e2y] = at(0.2, 0.6);
    for (const [ex, ey] of [[e1x, e1y], [e2x, e2y]]) {
      ctx.beginPath();
      ctx.moveTo(ex - u * 0.28, ey - u * 0.05); ctx.lineTo(ex, ey - u * 0.62); ctx.lineTo(ex + u * 0.28, ey - u * 0.05); ctx.closePath();
      ctx.fillStyle = "#4b3326"; ctx.fill();
    }
    const [hx, hy] = at(0.3, 0);
    disc(ctx, hx, hy - u * 0.1, u * 0.6, "#f6ead2", "#b79b72", u * 0.05);            // head
    oval(ctx, hx + fx * u * 0.12, hy - u * 0.08 + fy * u * 0.12, u * 0.38, u * 0.34, 0, "rgba(75,51,38,.9)"); // dark mask
    const [p1x, p1y] = at(0.55, -0.45), [p2x, p2y] = at(0.55, 0.45);
    disc(ctx, p1x, p1y + u * 0.35, u * 0.17, "#4b3326"); disc(ctx, p2x, p2y + u * 0.35, u * 0.17, "#4b3326"); // paws
    face(ctx, at, u, fx, fy, "#4aa3e8", "#e9a6a6", -0.1, true);
  } else if (id === "honey-badger") {
    disc(ctx, 0, u * 0.1, u * 0.82, "#23232b", "#0f0f14", u * 0.06);                  // body
    // silver stripe along the back, from the head to the tail
    const [a1x, a1y] = at(0.55, -0.62), [a2x, a2y] = at(0.55, 0.62), [b1x, b1y] = at(-0.7, -0.42), [b2x, b2y] = at(-0.7, 0.42);
    ctx.beginPath();
    ctx.moveTo(a1x, a1y + u * 0.1); ctx.lineTo(a2x, a2y + u * 0.1); ctx.lineTo(b2x, b2y + u * 0.1); ctx.lineTo(b1x, b1y + u * 0.1); ctx.closePath();
    ctx.fillStyle = "#cfd4dc"; ctx.fill();
    const [e1x, e1y] = at(0.15, -0.7), [e2x, e2y] = at(0.15, 0.7);
    disc(ctx, e1x, e1y - u * 0.1, u * 0.2, "#23232b"); disc(ctx, e2x, e2y - u * 0.1, u * 0.2, "#23232b");
    const [hx, hy] = at(0.42, 0);
    disc(ctx, hx, hy - u * 0.1, u * 0.52, "#2d2d37", "#0f0f14", u * 0.05);            // head
    const [sx, sy] = at(0.9, 0);
    oval(ctx, sx, sy - u * 0.06, u * 0.3, u * 0.24, Math.atan2(fy, fx), "#e8e1d6");   // pale snout
    face(ctx, at, u, fx, fy, "#f2d34a", "#111", -0.1);
  } else if (id === "bobcat") {
    const coat = "#b98a56", dark = "#5a3b1e", light = "#e6cfa6";
    // short bobbed tail with a black tip
    const [t1x, t1y] = at(-1.0, 0.1);
    oval(ctx, t1x, t1y, u * 0.2, u * 0.26, Math.atan2(fy, fx), coat, dark, u * 0.04);
    const [t2x, t2y] = at(-1.16, 0.1);
    oval(ctx, t2x, t2y, u * 0.12, u * 0.2, Math.atan2(fy, fx), "#2a1a0e");
    disc(ctx, 0, u * 0.1, u * 0.78, coat, dark, u * 0.05);                            // body
    for (const [f, sd, r] of [[-0.35, -0.4, 0.1], [-0.2, 0.3, 0.12], [0.05, -0.55, 0.09], [-0.5, 0.1, 0.1], [0.1, 0.5, 0.1], [-0.05, -0.1, 0.08]]) {
      const [sx, sy] = at(f, sd); disc(ctx, sx, sy + u * 0.1, u * r, "rgba(70,42,20,.75)");   // spots
    }
    const [e1x, e1y] = at(0.2, -0.62), [e2x, e2y] = at(0.2, 0.62);
    for (const [ex, ey] of [[e1x, e1y], [e2x, e2y]]) {
      ctx.beginPath();
      ctx.moveTo(ex - u * 0.28, ey - u * 0.02); ctx.lineTo(ex, ey - u * 0.64); ctx.lineTo(ex + u * 0.28, ey - u * 0.02); ctx.closePath();
      ctx.fillStyle = coat; ctx.fill(); ctx.strokeStyle = dark; ctx.lineWidth = u * 0.04; ctx.stroke();
      ctx.beginPath();                                                                // black ear tip and a tuft
      ctx.moveTo(ex - u * 0.1, ey - u * 0.42); ctx.lineTo(ex, ey - u * 0.64); ctx.lineTo(ex + u * 0.1, ey - u * 0.42); ctx.closePath();
      ctx.fillStyle = "#231710"; ctx.fill();
      ctx.beginPath(); ctx.moveTo(ex, ey - u * 0.64); ctx.lineTo(ex + u * 0.02, ey - u * 0.84); ctx.strokeStyle = "#231710"; ctx.lineWidth = u * 0.05; ctx.stroke();
    }
    const [hx, hy] = at(0.32, 0);
    disc(ctx, hx - px * u * 0.5, hy - py * u * 0.5 - u * 0.05, u * 0.24, light);       // cheek ruff
    disc(ctx, hx + px * u * 0.5, hy + py * u * 0.5 - u * 0.05, u * 0.24, light);
    disc(ctx, hx, hy - u * 0.1, u * 0.6, coat, dark, u * 0.05);                       // head
    ctx.strokeStyle = "rgba(60,36,16,.7)"; ctx.lineWidth = u * 0.05; ctx.lineCap = "round";
    for (const s2 of [-1, 1]) { const [a1x, a1y] = at(0.4, s2 * 0.45), [a2x, a2y] = at(0.7, s2 * 0.3); ctx.beginPath(); ctx.moveTo(a1x, a1y - u * 0.1); ctx.lineTo(a2x, a2y - u * 0.1); ctx.stroke(); }
    const [mx, my] = at(0.66, 0);
    oval(ctx, mx, my - u * 0.1, u * 0.28, u * 0.22, 0, light);                        // pale muzzle
    face(ctx, at, u, fx, fy, "#e0b53c", "#3a2018", -0.1, true);
  } else if (id === "grim-reaper") {
    // a silver scythe held out to one side
    const [h1x, h1y] = at(-0.5, 0.95), [h2x, h2y] = at(0.8, 1.0);
    ctx.strokeStyle = "#5a3d24"; ctx.lineWidth = u * 0.1; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(h1x, h1y); ctx.lineTo(h2x, h2y); ctx.stroke();
    const [b1x, b1y] = at(0.8, 1.0), [bcx, bcy] = at(1.25, 0.85), [b2x, b2y] = at(1.1, 0.35);
    ctx.beginPath(); ctx.moveTo(b1x, b1y); ctx.quadraticCurveTo(bcx, bcy, b2x, b2y); ctx.quadraticCurveTo(...at(1.0, 0.75), b1x, b1y);
    ctx.fillStyle = "#cfd6e2"; ctx.fill(); ctx.strokeStyle = "#7a8496"; ctx.lineWidth = u * 0.04; ctx.stroke();
    // flowing robe, wider at the back
    const [r1x, r1y] = at(-0.55, 0);
    oval(ctx, r1x, r1y + u * 0.1, u * 0.62, u * 0.9, Math.atan2(fy, fx) + Math.PI / 2, "#14141c");
    disc(ctx, 0, u * 0.1, u * 0.82, "#1c1c26", "#07070b", u * 0.06);                  // shoulders and robe
    ctx.strokeStyle = "rgba(120,120,150,.25)"; ctx.lineWidth = u * 0.04;
    for (const s2 of [-0.35, 0, 0.35]) { ctx.beginPath(); ctx.moveTo(...at(0.1, s2)); ctx.lineTo(...at(-0.75, s2 * 1.3)); ctx.stroke(); }
    const [hx, hy] = at(0.3, 0);
    disc(ctx, hx, hy - u * 0.1, u * 0.62, "#262633", "#07070b", u * 0.05);            // the hood
    // straight blonde hair, drawn the way a person would: uneven strands with a slight bend, a side part, flyaways
    const gold = "#e9c872", goldMid = "#f2d98a", goldDark = "#b98f3c", goldLight = "#fbeeb4";
    let hs = 7;                                           // fixed seed so the hair never changes between frames
    const rnd = () => ((hs = (hs * 16807) % 2147483647) / 2147483647);
    const strand = (an, r0, r1, w, col, bend) => {
      const ca = Math.cos(an), sa = Math.sin(an), pa = an + Math.PI / 2;
      const rm = (r0 + r1) / 2;
      const [x0, y0] = at(0.3 + ca * r0, sa * r0), [x1, y1] = at(0.3 + ca * r1, sa * r1);
      const [cx, cy] = at(0.3 + ca * rm + Math.cos(pa) * bend, sa * rm + Math.sin(pa) * bend);
      ctx.strokeStyle = col; ctx.lineWidth = u * w; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(x0, y0 - u * 0.1); ctx.quadraticCurveTo(cx, cy - u * 0.1, x1, y1 - u * 0.1); ctx.stroke();
    };
    const part = 118 * Math.PI / 180;                     // hair is parted off-centre and falls to both sides
    const N = 46;
    const strands = [];
    for (let i = 0; i < N; i++) {
      const t = i / (N - 1), an = (84 + t * 192) * Math.PI / 180 + (rnd() - 0.5) * 0.09;
      const side = an < part ? 1 : 0.88;                  // the shorter side of the part sits a little tighter
      const round = 0.62 + 0.38 * Math.pow(Math.sin(t * Math.PI), 0.6);   // shorter by the ears, longest at the back, so the edge is rounded
      strands.push({ an, r1: (0.66 + rnd() * 0.2) * side * round, w: 0.045 + rnd() * 0.05, bend: (rnd() - 0.5) * 0.09, tone: rnd() });
    }
    ctx.beginPath(); {                                    // solid base so no hood shows between strands
      const [bx, by] = at(0.3, 0); ctx.moveTo(bx, by - u * 0.1);
      for (const q of strands) { const [px2, py2] = at(0.3 + Math.cos(q.an) * q.r1 * 0.9, Math.sin(q.an) * q.r1 * 0.9); ctx.lineTo(px2, py2 - u * 0.1); }
      ctx.closePath(); ctx.fillStyle = goldMid; ctx.fill();
    }
    for (const q of strands) strand(q.an, 0.04, q.r1 + 0.02, q.w + 0.025, goldDark, q.bend);            // shadow underneath each strand
    for (const q of strands) strand(q.an, 0.05, q.r1, q.w, q.tone < 0.35 ? gold : goldMid, q.bend);    // body color, two slightly different blondes
    for (const q of strands) if (q.tone > 0.6) strand(q.an + 0.015, 0.14, q.r1 * (0.7 + q.tone * 0.2), 0.02, goldLight, q.bend);  // a few shiny strands
    for (let i = 0; i < 9; i++) {                         // loose flyaway hairs poking past the edge
      const an = (95 + rnd() * 170) * Math.PI / 180, r0 = 0.62 + rnd() * 0.1;
      strand(an, r0, r0 + 0.1 + rnd() * 0.1, 0.014, goldDark, (rnd() - 0.5) * 0.12);
    }
    strand(part, 0.04, 0.5, 0.018, "rgba(70,45,10,.55)", 0.01);                                        // the parting line
    const [fcx, fcy] = at(0.52, 0);
    oval(ctx, fcx, fcy - u * 0.1, u * 0.34, u * 0.27, 0, "#06060a");                   // dark face under the fringe
    for (const s2 of [-1, 1]) {                                                       // glowing blue eyes
      const [ex, ey] = at(0.6, s2 * 0.16);
      disc(ctx, ex, ey - u * 0.12, u * 0.15, "rgba(90,170,255,.4)");
      disc(ctx, ex, ey - u * 0.12, u * 0.09, "#7cc4ff");
      disc(ctx, ex, ey - u * 0.14, u * 0.035, "#e6f4ff");
    }
    const [jx, jy] = at(0.82, 0);
    oval(ctx, jx, jy - u * 0.1, u * 0.14, u * 0.07, 0, "#e8e8ee");                    // hint of a bony grin
  } else if (id === "monica" || id === "coleycanoli") {
    // Monica: orange, big black glasses, nurse cap. Coleycanoli: smaller, blonde, hazel eyes, game cards in his paws.
    const mon = id === "monica";
    const fur = mon ? "#f6a24b" : "#f3dc8c", dark = mon ? "#c9701f" : "#c9a441", light = mon ? "#ffe6c4" : "#fff3c9";
    const earIn = mon ? "#f0a5b4" : "#1d1d27";
    if (!mon) ctx.scale(0.84, 0.84);
    const [t1x, t1y] = at(-1.0, 0.35);
    ctx.strokeStyle = dark; ctx.lineWidth = u * 0.4; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(...at(-0.5, 0)); ctx.quadraticCurveTo(...at(-1.15, -0.5), t1x, t1y); ctx.stroke();
    ctx.strokeStyle = fur; ctx.lineWidth = u * 0.28;
    ctx.beginPath(); ctx.moveTo(...at(-0.5, 0)); ctx.quadraticCurveTo(...at(-1.15, -0.5), t1x, t1y); ctx.stroke();
    disc(ctx, 0, u * 0.1, u * 0.78, fur, dark, u * 0.05);                             // body
    oval(ctx, 0, u * 0.2, u * 0.38, u * 0.48, 0, light);                              // tummy
    const [e1x, e1y] = at(0.2, -0.62), [e2x, e2y] = at(0.2, 0.62);
    for (const [ex, ey] of [[e1x, e1y], [e2x, e2y]]) {
      ctx.beginPath(); ctx.moveTo(ex - u * 0.3, ey - u * 0.02); ctx.lineTo(ex, ey - u * 0.66); ctx.lineTo(ex + u * 0.3, ey - u * 0.02); ctx.closePath();
      ctx.fillStyle = fur; ctx.fill(); ctx.strokeStyle = dark; ctx.lineWidth = u * 0.04; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(ex - u * 0.15, ey - u * 0.05); ctx.lineTo(ex, ey - u * 0.42); ctx.lineTo(ex + u * 0.15, ey - u * 0.05); ctx.closePath();
      ctx.fillStyle = earIn; ctx.fill();
    }
    const [hx, hy] = at(0.32, 0);
    disc(ctx, hx, hy - u * 0.1, u * 0.6, fur, dark, u * 0.05);                        // head
    const [mx, my] = at(0.62, 0);
    oval(ctx, mx, my - u * 0.1, u * 0.28, u * 0.22, 0, light);                        // muzzle
    if (mon) {
      face(ctx, at, u, fx, fy, "#111", "#e58a9b", -0.1, true);
      ctx.strokeStyle = "#111"; ctx.lineWidth = u * 0.06;                             // big round black glasses
      for (const s2 of [-1, 1]) { const [gx, gy] = at(0.62, s2 * 0.26); ctx.beginPath(); ctx.arc(gx, gy - u * 0.1, u * 0.22, 0, Math.PI * 2); ctx.stroke(); }
      ctx.beginPath(); ctx.moveTo(...at(0.62, -0.04)); ctx.lineTo(...at(0.62, 0.04)); ctx.stroke();
      const cy0 = hy - u * 0.1;                                                       // nurse cap
      ctx.beginPath(); ctx.moveTo(hx - u * 0.36, cy0 - u * 0.36); ctx.lineTo(hx - u * 0.27, cy0 - u * 0.74); ctx.lineTo(hx + u * 0.27, cy0 - u * 0.74); ctx.lineTo(hx + u * 0.36, cy0 - u * 0.36); ctx.closePath();
      ctx.fillStyle = "#fff"; ctx.fill(); ctx.strokeStyle = "#9aa3b2"; ctx.lineWidth = u * 0.04; ctx.stroke();
      ctx.fillStyle = "#d9363e"; ctx.fillRect(hx - u * 0.04, cy0 - u * 0.66, u * 0.08, u * 0.24); ctx.fillRect(hx - u * 0.12, cy0 - u * 0.58, u * 0.24, u * 0.08);
    } else {
      face(ctx, at, u, fx, fy, "#fff", "#111", -0.1, true);
      for (const s2 of [-1, 1]) {                                                     // white outside, hazel in the middle
        const [ex, ey] = at(0.62, s2 * 0.24);
        disc(ctx, ex, ey - u * 0.1, u * 0.11, "#9aae4a"); disc(ctx, ex, ey - u * 0.1, u * 0.055, "#111");
      }
      const cardAt = at(0.72, 0);                                                     // game cards in his paws
      [[-0.32, "#6ec1ff", -0.3], [0.32, "#8bd17c", 0.3], [0, "#ff8a6b", 0]].forEach(([dx, art, rot]) => {
        ctx.save(); ctx.translate(cardAt[0], cardAt[1] + u * 0.3); ctx.rotate(rot);
        ctx.fillStyle = "#ffe27a"; ctx.strokeStyle = "#2a1f18"; ctx.lineWidth = u * 0.04;
        ctx.fillRect(-u * 0.14, -u * 0.36, u * 0.28, u * 0.4); ctx.strokeRect(-u * 0.14, -u * 0.36, u * 0.28, u * 0.4);
        ctx.fillStyle = art; ctx.fillRect(-u * 0.1, -u * 0.32, u * 0.2, u * 0.17);
        ctx.restore();
      });
      const [p1x, p1y] = at(0.6, -0.3), [p2x, p2y] = at(0.6, 0.3);
      disc(ctx, p1x, p1y + u * 0.3, u * 0.13, fur, dark, u * 0.03); disc(ctx, p2x, p2y + u * 0.3, u * 0.13, fur, dark, u * 0.03);
    }
  } else {
    // Brown Cat: a fluffy brown cat with a pink bow. Fur is a ring of little tufts around a round body.
    const fur = "#9a6a43", dark = "#6e4527", light = "#e0bd93";
    const tuft = (cx, cy, r, n, color) => {
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        disc(ctx, cx + Math.cos(a) * r, cy + Math.sin(a) * r, r * 0.28, color);
      }
    };
    // big fluffy tail curling up behind
    const [t1x, t1y] = at(-1.0, 0.35);
    ctx.strokeStyle = dark; ctx.lineWidth = u * 0.52; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(...at(-0.5, 0)); ctx.quadraticCurveTo(...at(-1.15, -0.5), t1x, t1y); ctx.stroke();
    ctx.strokeStyle = fur; ctx.lineWidth = u * 0.4;
    ctx.beginPath(); ctx.moveTo(...at(-0.5, 0)); ctx.quadraticCurveTo(...at(-1.15, -0.5), t1x, t1y); ctx.stroke();
    tuft(0, u * 0.1, u * 0.78, 14, dark);
    disc(ctx, 0, u * 0.1, u * 0.8, fur);                                              // fluffy body
    tuft(0, u * 0.1, u * 0.72, 12, fur);
    oval(ctx, 0, u * 0.2, u * 0.4, u * 0.5, 0, "rgba(224,189,147,.55)");              // lighter tummy
    const [e1x, e1y] = at(0.2, -0.62), [e2x, e2y] = at(0.2, 0.62);
    for (const [ex, ey] of [[e1x, e1y], [e2x, e2y]]) {
      ctx.beginPath();
      ctx.moveTo(ex - u * 0.3, ey - u * 0.02); ctx.lineTo(ex, ey - u * 0.66); ctx.lineTo(ex + u * 0.3, ey - u * 0.02); ctx.closePath();
      ctx.fillStyle = dark; ctx.fill();
      ctx.beginPath();
      ctx.moveTo(ex - u * 0.15, ey - u * 0.05); ctx.lineTo(ex, ey - u * 0.42); ctx.lineTo(ex + u * 0.15, ey - u * 0.05); ctx.closePath();
      ctx.fillStyle = "#f0a5b4"; ctx.fill();
    }
    const [hx, hy] = at(0.32, 0);
    tuft(hx, hy - u * 0.1, u * 0.56, 12, fur);                                        // fluffy cheeks
    disc(ctx, hx, hy - u * 0.1, u * 0.6, fur, dark, u * 0.04);                        // head
    const [mx, my] = at(0.62, 0);
    oval(ctx, mx, my - u * 0.1, u * 0.3, u * 0.24, 0, light);                         // muzzle
    const [p1x, p1y] = at(0.55, -0.5), [p2x, p2y] = at(0.55, 0.5);
    disc(ctx, p1x, p1y + u * 0.35, u * 0.17, light); disc(ctx, p2x, p2y + u * 0.35, u * 0.17, light); // paws
    // pink bow on one ear
    const [bx, by] = at(0.4, 0.42);
    for (const s2 of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(bx, by - u * 0.55);
      ctx.lineTo(bx + s2 * u * 0.3, by - u * 0.72); ctx.lineTo(bx + s2 * u * 0.3, by - u * 0.38); ctx.closePath();
      ctx.fillStyle = "#ff7fa8"; ctx.fill();
    }
    disc(ctx, bx, by - u * 0.55, u * 0.09, "#e0527f");
    face(ctx, at, u, fx, fy, "#2a1a14", "#e58a9b", -0.1, true);
  }
  ctx.restore();
}

/** Two eyes and (optionally) a nose, pushed toward the way the critter is facing. */
function face(ctx, at, u, fx, fy, eyeColor, noseColor, lift, bigEyes, noNose) {
  const ey = u * (lift || 0);
  for (const s of [-1, 1]) {
    const [x, y] = at(0.62, s * 0.24);
    disc(ctx, x, y + ey, u * (bigEyes ? 0.14 : 0.1), eyeColor);
    disc(ctx, x + u * 0.03, y + ey - u * 0.03, u * 0.035, "rgba(255,255,255,.85)");
  }
  if (!noNose) {
    const [nx, ny] = at(0.88, 0);
    disc(ctx, nx, ny + ey, u * 0.09, noseColor);
  }
}

/** A small canvas element showing one character, for the picker and the player chips. */
export function charCanvas(id, px = 56, lookX = 0.3, lookY = 1) {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const c = document.createElement("canvas");
  c.width = c.height = Math.round(px * dpr);
  c.style.width = c.style.height = px + "px";
  c.className = "char-art";
  c.setAttribute("role", "img");
  c.setAttribute("aria-label", characterName(id));
  const ctx = c.getContext("2d");
  ctx.scale(dpr, dpr);
  drawChar(ctx, id, px / 2, px / 2 - px * 0.04, px * 0.72, lookX, lookY, 0, 1);
  return c;
}
