// Mini Golf online: a course seen from a tilted camera, stone walls, sand, water, bumpers, boost pads and portals.
// Players take turns hitting their own ball (drag back to aim, let go to hit). The server rolls the ball and sends
// the whole path, and this page plays it back, so everybody sees every shot.
import { h } from "../ui.js";
import { BALL_COLORS, HATS, DEFAULT_CHOICE, parseChoice, drawBall, shade, ballCanvas } from "./golfparts.js";

const K = 0.78;                  // how squashed the tilted camera makes the course (1 = straight down)
const BALL_R = 0.28;
const VIEW_TILES = 11;           // how many tiles wide the camera shows
const MAX_DRAG = 150;            // pixels of pull-back for full power
const MIN_POWER = 0.05;
const SAMPLE_RATE = 30;          // the server sends 30 path points a second

export default {
  id: "mini-golf",
  name: "Mini Golf",
  theme: "theme-golf",
  artClass: "art-golf",
  hideSeats: true,
  blurb: "",
  art: () => [["red", "party"], ["sky", "crown"], ["lime", "propeller"], ["pink", "wizard"]].map(([c, hat]) =>
    ballCanvas(BALL_COLORS.find(b => b.id === c).hex, hat, 56)),
  picker: golfPicker,
  lobbyIcon: (choice, seat) => { const c = parseChoice(choice, seat); return ballCanvas(c.color.hex, c.hat, 30); },
  create
};

/** Lobby panel: choose your ball color and hat. `choose(value)` sends "color:hat" to the server. */
export function golfPicker(room, choose) {
  const me = room.seats[room.you];
  const mine = parseChoice(me && me.choice, room.you);
  const set = (color, hat) => choose(`${color}:${hat}`);
  return h("div.panel.golf-picker",
    h("div.label", { style: { marginBottom: "10px" } }, "Your ball"),
    h("div.golf-preview", ballCanvas(mine.color.hex, mine.hat, 96),
      h("div", h("strong", (me && me.name) || "You"), h("div.muted", `${mine.color.name} ball · ${HATS.find(x => x.id === mine.hat).name}`))),
    h("div.label", { style: { margin: "12px 0 8px" } }, "Color"),
    h("div.golf-colors", BALL_COLORS.map(c => h("button.golf-swatch", {
      type: "button", title: c.name, "aria-label": c.name, "aria-pressed": c.id === mine.color.id ? "true" : "false",
      class: c.id === mine.color.id ? "picked" : "", style: { background: c.hex },
      onclick: () => set(c.id, mine.hat)
    }))),
    h("div.label", { style: { margin: "12px 0 8px" } }, "Hat"),
    h("div.golf-hats", HATS.map(hat => h("button.golf-hat", {
      type: "button", "aria-pressed": hat.id === mine.hat ? "true" : "false", class: hat.id === mine.hat ? "picked" : "",
      onclick: () => set(mine.color.id, hat.id)
    }, ballCanvas(mine.color.hex, hat.id, 52), h("span", hat.name)))));
}


const isWall = (map, x, y) => x < 0 || y < 0 || y >= map.length || x >= map[0].length || map[y][x] === "#";
const WALL_H = 0.62, NEAR = 0.25;
const angDiff = (a, b) => { let d = a - b; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; };
const vnoise = (x, y) => { const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
  const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1); return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy; };
const hex2rgb = (hex) => { const n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const THEMES = [
  { wall: { a: "#A8693C", b: "#C58352", c: "#8E5530", top: "#E7B27C", line: "rgba(70,35,15,.55)" }, ring: ["#4C9A47", "#3F873C"], grass: ["#5FA64F", "#559B47"], deco: "tree" },
  { wall: { a: "#E8D9BE", b: "#F5EAD2", c: "#D2C1A3", top: "#FFF7E6", line: "rgba(120,95,60,.5)" }, ring: ["#E4D3A2", "#D8C592"], grass: ["#62A956", "#579F4C"], deco: "palm" },
  { wall: { a: "#2C8A48", b: "#3AA55A", c: "#237A3E", top: "#5ED07E", line: "rgba(10,60,25,.55)" }, ring: ["#468F46", "#3A7E3C"], grass: ["#5CA253", "#519749"], deco: "flower" },
  { wall: { a: "#B4543A", b: "#CC6A4B", c: "#9C4530", top: "#E58B68", line: "rgba(80,25,10,.55)" }, ring: ["#C9A271", "#B98F5F"], grass: ["#69A053", "#5E954A"], deco: "rock" }
];
const GRASS_A = hex2rgb("#4DB551"), GRASS_B = hex2rgb("#42A647"), SAND_A = hex2rgb("#F3D77E"), SAND_B = hex2rgb("#EBCB6C");
const ICE_A = hex2rgb("#C9EFFF"), ICE_B = hex2rgb("#B6E4F8"), POOL = hex2rgb("#3A86B8"), FOG = hex2rgb("#A9DDF7");
function hash(x, y) { let n = (x * 374761393 + y * 668265263) | 0; n = (n ^ (n >>> 13)) * 1274126177; return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }

function create(area, api) {
  let room = null, view = null;
  let raf = 0, last = 0, tSec = 0, destroyed = false, lastDt = 0.016;
  let cssW = 360, cssH = 440, dpr = 1, FOCAL = 340, CY = 200;
  const cam = { x: 0, y: 0, z: 3, yaw: 0, pitch: 0.4, ready: false };
  const balls = new Map();          // seat -> { x, y }  (where each ball rests)
  const anims = new Map();          // seat -> a shot being played back
  const particles = [];
  let lastSig = "", lastHoleKey = "", lastTick = -1, shotSeq = Math.floor(Date.now() / 1000) % 100000000 * 10;
  let drag = null;                  // { sx, sy, lx, ly }
  const aim = { angle: 0, power: 0 };
  let waiting = false, hidden = false, overview = false;
  let F = [1, 0, 0], R = [0, 1, 0], U = [0, 0, 1];

  const canvas = h("canvas.golf-canvas", { "aria-label": "The mini golf course from behind your ball." });
  const ctx = canvas.getContext("2d");
  const hud = h("div.golf-hud");
  const turn = h("div.golf-turn");
  const overlay = h("div.golf-overlay");
  const zoomBtn = h("button.golf-zoom", { type: "button", title: "Bird's-eye view of the whole hole", "aria-label": "Bird's-eye view", onclick: () => { overview = !overview; zoomBtn.classList.toggle("on", overview); } }, "🗺");
  const wrap = h("div.golf-wrap", hud, canvas, turn, zoomBtn, overlay);
  const board = h("div.golf-board");
  area.appendChild(wrap);
  area.appendChild(board);

  const seatInfo = (seat) => {
    const s = room && room.seats && room.seats[seat];
    return { name: api.seatName(seat), ...parseChoice(s && s.choice, seat) };
  };
  const B = (seat) => (view && view.balls && view.balls[seat]) || { state: "rest", strokes: 0, x: 0, y: 0 };
  const isOut = (seat) => B(seat).state === "sunk" || B(seat).state === "out";
  const myTurn = () => view && room && room.status === "playing" && view.phase === "play" && B(api.you).state === "rest" && !waiting && !anims.has(api.you);

  // ---------- sizing ----------
  let dprCap = 1.75, slowMs = 0;   // if the device can't keep up, the picture gets a little less sharp so the motion stays smooth
  function resize() {
    const w = Math.max(280, Math.floor(wrap.clientWidth || area.clientWidth || 360));
    dpr = Math.min(dprCap, window.devicePixelRatio || 1);
    cssW = w;
    cssH = Math.round(Math.max(340, Math.min(w * 1.12, (window.innerHeight || 800) * 0.58, 600)));
    canvas.width = Math.round(cssW * dpr); canvas.height = Math.round(cssH * dpr);
    canvas.style.width = cssW + "px"; canvas.style.height = cssH + "px";
    FOCAL = cssW * 0.8;
    CY = cssH * 0.42;
  }
  window.addEventListener("resize", resize);

  // ---------- 3D camera ----------
  function setBasis() {
    const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch), ca = Math.cos(cam.yaw), sa = Math.sin(cam.yaw);
    F = [ca * cp, sa * cp, -sp];
    R = [-sa, ca, 0];
    U = [sp * ca, sp * sa, cp];
  }
  /** World (x east, y south, z up) to camera space [right, up, forward]. */
  function toCam(X, Y, Z) {
    const dx = X - cam.x, dy = Y - cam.y, dz = Z - cam.z;
    return [dx * R[0] + dy * R[1], dx * U[0] + dy * U[1] + dz * U[2], dx * F[0] + dy * F[1] + dz * F[2]];
  }
  function proj(X, Y, Z) {
    const c = toCam(X, Y, Z);
    if (c[2] < NEAR) return null;
    return [cssW / 2 + FOCAL * c[0] / c[2], CY - FOCAL * c[1] / c[2], c[2]];
  }
  /** Projects a polygon given in world space, clipping what is behind the camera. Returns screen points or null. */
  function projPoly(pts) {
    const cs = pts.map(p => toCam(p[0], p[1], p[2]));
    const out = [];
    for (let i = 0; i < cs.length; i++) {
      const a = cs[i], b = cs[(i + 1) % cs.length];
      const ain = a[2] >= NEAR, bin = b[2] >= NEAR;
      if (ain) out.push(a);
      if (ain !== bin) { const t = (NEAR - a[2]) / (b[2] - a[2]); out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, NEAR]); }
    }
    if (out.length < 3) return null;
    return out.map(c => [cssW / 2 + FOCAL * c[0] / c[2], CY - FOCAL * c[1] / c[2], c[2]]);
  }
  function fillPoly(pts, fill, stroke, lw) {
    const sp = projPoly(pts);
    if (!sp) return null;
    ctx.beginPath(); ctx.moveTo(sp[0][0], sp[0][1]);
    for (let i = 1; i < sp.length; i++) ctx.lineTo(sp[i][0], sp[i][1]);
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
    return sp;
  }
  const mix = (c, f) => `rgb(${Math.round(c[0] + (FOG[0] - c[0]) * f)},${Math.round(c[1] + (FOG[1] - c[1]) * f)},${Math.round(c[2] + (FOG[2] - c[2]) * f)})`;
  const scaleAt = (z) => FOCAL / z;

  /** The camera follows your ball; once you're in the hole it looks around the cup, to watch the others. */
  function camFocus() {
    if (isOut(api.you) && view && view.phase === "play") return { x: view.cup[0], y: view.cup[1] };
    return ballPos(api.you);
  }
  function ballPos(seat) {
    const a = anims.get(seat);
    if (a) return a.pos;
    return balls.get(seat) || { x: 0, y: 0 };
  }

  function updateCamera() {
    if (!view) return;
    const W = view.map[0].length, H = view.map.length;
    let tx, ty, tz, tyaw, tpitch;
    const rolling = anims.get(api.you);
    const mineAiming = view.phase === "play" && B(api.you).state === "rest" && !rolling;
    if (overview) {
      const dir = Math.atan2(view.cup[1] - view.tee[1], view.cup[0] - view.tee[0]);
      const c = [W / 2, H / 2], fx = Math.cos(dir), fy = Math.sin(dir), rx = -fy, ry = fx;
      let hw = 1, hh = 1;
      for (const [px, py] of [[0, 0], [W, 0], [0, H], [W, H]]) { hw = Math.max(hw, Math.abs((px - c[0]) * rx + (py - c[1]) * ry)); hh = Math.max(hh, Math.abs((px - c[0]) * fx + (py - c[1]) * fy)); }
      const dist = Math.max(FOCAL * hw / (cssW / 2 - 8), FOCAL * hh / (cssH * 0.46 - 8)) * 1.04;
      tpitch = 1.5; tyaw = dir;
      tz = dist; tx = c[0] - Math.cos(dir) * 0.0; ty = c[1];
      tx = c[0] + Math.cos(dir) * dist * Math.tan(Math.PI / 2 - tpitch) * -1; ty = c[1] + Math.sin(dir) * dist * Math.tan(Math.PI / 2 - tpitch) * -1;
    } else {
      const focus = camFocus();
      if (mineAiming) tyaw = aim.angle;
      else if (rolling) tyaw = rolling.yaw !== undefined ? rolling.yaw : cam.yaw;
      else if (isOut(api.you) && view.phase === "play") tyaw = cam.yaw + 0.6;     // you're in: slowly look around the hole
      else tyaw = Math.atan2(view.cup[1] - focus.y, view.cup[0] - focus.x);
      tpitch = 0.44;
      const D = 5.2;
      const yy = cam.ready ? cam.yaw : tyaw;
      tx = focus.x - Math.cos(yy) * D; ty = focus.y - Math.sin(yy) * D; tz = 3.5;
    }
    if (!cam.ready) { cam.x = tx; cam.y = ty; cam.z = tz; cam.yaw = tyaw; cam.pitch = tpitch; cam.ready = true; }
    const k = 1 - Math.pow(0.004, lastDt), ky = mineAiming && !overview ? 1 - Math.pow(0.00002, lastDt) : 1 - Math.pow(0.03, lastDt);
    cam.yaw += angDiff(tyaw, cam.yaw) * ky;
    cam.pitch += (tpitch - cam.pitch) * k;
    cam.z += (tz - cam.z) * k;
    // the camera sits behind its focus along the *current* yaw, so it swings around the ball smoothly
    if (!overview) {
      const focus = camFocus();
      tx = focus.x - Math.cos(cam.yaw) * 5.2; ty = focus.y - Math.sin(cam.yaw) * 5.2;
    }
    cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k;
    setBasis();
  }

  // ---------- input ----------
  canvas.style.touchAction = "none";
  canvas.addEventListener("pointerdown", (e) => {
    if (!myTurn() || overview) return;
    const r = canvas.getBoundingClientRect();
    drag = { sx: e.clientX - r.left, sy: e.clientY - r.top, lx: e.clientX - r.left };
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    e.preventDefault();
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const r = canvas.getBoundingClientRect();
    const x = e.clientX - r.left, y = e.clientY - r.top;
    aim.angle += (x - drag.lx) * 0.0055;               // swipe right to turn right
    drag.lx = x;
    const pull = y - drag.sy;                          // pull down for power
    aim.power = pull < 12 ? 0 : Math.min(1, (pull - 12) / MAX_DRAG);
  });
  const release = () => {
    if (!drag) return;
    const power = aim.power;
    drag = null;
    if (power >= MIN_POWER && myTurn()) hit(aim.angle, power);
    else aim.power = 0;
  };
  canvas.addEventListener("pointerup", release);
  canvas.addEventListener("pointercancel", () => { drag = null; aim.power = 0; });
  function hit(angle, power) {
    if (!myTurn()) return;
    waiting = true;
    aim.power = 0;
    api.sound.drop();
    if (!api.sendQuiet({ kind: "shoot", seq: ++shotSeq, angle: Math.round(angle * 10000) / 10000, power: Math.round(power * 1000) / 1000 })) {
      waiting = false; api.toast("Reconnecting... try again in a moment.");
    }
  }
  const keyDown = (e) => {
    if (!myTurn() || ["INPUT", "TEXTAREA"].includes((e.target && e.target.tagName) || "")) return;
    if (e.key === "ArrowLeft" || e.key === "a") { aim.angle -= 0.04; e.preventDefault(); }
    else if (e.key === "ArrowRight" || e.key === "d") { aim.angle += 0.04; e.preventDefault(); }
    else if (e.key === "ArrowUp" || e.key === "w") { aim.power = Math.min(1, (aim.power || 0.3) + 0.05); e.preventDefault(); }
    else if (e.key === "ArrowDown" || e.key === "s") { aim.power = Math.max(0.05, (aim.power || 0.3) - 0.05); e.preventDefault(); }
    else if (e.key === " " || e.key === "Enter") { if (aim.power >= MIN_POWER) { hit(aim.angle, aim.power); e.preventDefault(); } }
  };
  window.addEventListener("keydown", keyDown);

  // ---------- playback: the server sends where each moving ball has been since the last tick ----------
  function pushTrail(seat, trail) {
    if (!trail || !trail.length) return;
    const b = balls.get(seat) || { x: trail[0], y: trail[1] };
    let a = anims.get(seat);
    if (!a) { a = { queue: [], from: { x: b.x, y: b.y }, to: { x: b.x, y: b.y }, pos: { x: b.x, y: b.y }, acc: 1, yaw: undefined, wait: true }; anims.set(seat, a); }
    for (let i = 0; i < trail.length; i += 2) a.queue.push(trail[i], trail[i + 1]);
    if (a.queue.length > 30) a.queue.splice(0, a.queue.length - 30);   // fell far behind: skip ahead
  }
  /**
   * Plays the path back at 30 points a second, but a little behind the server: it waits for about a tick of points
   * before it starts, speeds up a touch if it gets behind, and holds still (instead of snapping) if a tick arrives late.
   */
  function stepAnims() {
    for (const [seat, a] of [...anims.entries()]) {
      const pts = a.queue.length / 2;
      const rolling = !!view && !!view.balls[seat] && view.balls[seat].state === "roll";
      if (a.wait) {
        if (pts >= 3 || !rolling) a.wait = false;
        else { a.pos.x = a.to.x; a.pos.y = a.to.y; continue; }
      }
      const speed = pts > 14 ? 1.5 : pts > 8 ? 1.25 : 1;
      a.acc += lastDt * SAMPLE_RATE * speed;
      let done = false, held = false;
      while (a.acc >= 1) {
        if (!a.queue.length) {
          if (rolling) { held = true; a.acc = 0; a.wait = true; } else done = true;
          break;
        }
        a.acc -= 1;
        a.from = a.to; a.to = { x: a.queue[0], y: a.queue[1] }; a.queue.splice(0, 2);
        const dx = a.to.x - a.from.x, dy = a.to.y - a.from.y, d = Math.hypot(dx, dy);
        if (d > 0.02 && d < 1.5) a.yaw = Math.atan2(dy, dx);
      }
      if (done) { anims.delete(seat); continue; }
      if (held) { a.pos.x = a.to.x; a.pos.y = a.to.y; continue; }
      const dx = a.to.x - a.from.x, dy = a.to.y - a.from.y, jump = Math.hypot(dx, dy) > 1.5;   // a portal hop: jump, don't slide
      const u = jump ? 1 : a.acc;
      a.pos.x = a.from.x + dx * u; a.pos.y = a.from.y + dy * u;
    }
  }
  function burst(x, y, color, n, speed, life) {
    for (let i = 0; i < n; i++) particles.push({ x, y, z: 0.2, vx: (Math.random() - 0.5) * speed, vy: (Math.random() - 0.5) * speed, vz: 2 + Math.random() * 3, life, color: Array.isArray(color) ? color[i % color.length] : color, size: 3.5 });
  }
  function handleEvents(events) {
    for (const e of events || []) {
      if (e.k === "hit") api.sound.tap();
      else if (e.k === "wall") { if (e.seat === api.you) api.sound.tap(); }
      else if (e.k === "bump") {
        api.sound.card();
        burst(e.x, e.y, ["#FFE08A", "#fff"], 8, 2.4, 0.5);
      } else if (e.k === "splash") {
        api.sound.oops();
        burst(e.x, e.y, "#D5F0FF", 22, 2.4, 0.9);
      } else if (e.k === "sunk") {
        api.sound.win();
        const info = seatInfo(e.seat);
        burst(view.cup[0], view.cup[1], ["#FFC93C", "#FF6FB5", "#4CC9F0", info.color.hex, "#9BE03A"], 30, 3.2, 1.3);
      }
    }
  }

  // ---------- drawing the world ----------
  function drawSky() {
    const hy = CY - FOCAL * Math.tan(cam.pitch);
    const sky = ctx.createLinearGradient(0, 0, 0, Math.max(40, hy));
    sky.addColorStop(0, "#6FA9D8"); sky.addColorStop(1, "#D6E6EE");
    ctx.fillStyle = sky; ctx.fillRect(0, 0, cssW, cssH);
    // a warm sun that slides across the sky as you turn, a hazy glow, and far-off hills
    const sx = cssW * (0.5 + angDiff(-0.9, cam.yaw) * 0.8), sy = Math.max(30, hy * 0.42);
    const glow = ctx.createRadialGradient(sx, sy, 4, sx, sy, cssW * 0.5);
    glow.addColorStop(0, "rgba(255,244,190,.95)"); glow.addColorStop(0.12, "rgba(255,236,160,.55)"); glow.addColorStop(1, "rgba(255,236,160,0)");
    ctx.fillStyle = glow; ctx.fillRect(0, 0, cssW, cssH);
    ctx.fillStyle = "#FFF6C8"; ctx.beginPath(); ctx.arc(sx, sy, 15, 0, 7); ctx.fill();
    for (const [amp, f0, ph, col] of [[22, 0.011, 1.3, "rgba(96,170,200,.42)"], [14, 0.019, 4.1, "rgba(70,150,150,.5)"]]) {
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, hy + 2);
      for (let x = 0; x <= cssW; x += 8) ctx.lineTo(x, hy - amp * (0.5 + 0.5 * Math.sin((x + cam.yaw * 300) * f0 + ph)) * (0.6 + 0.4 * Math.sin((x + cam.yaw * 300) * f0 * 2.7)));
      ctx.lineTo(cssW, hy + 2); ctx.closePath(); ctx.fill();
    }
    // soft clouds that slide as you turn
    ctx.fillStyle = "rgba(255,255,255,.5)";
    for (let i = 0; i < 6; i++) {
      const cx0 = ((i * 211 - cam.yaw * 260 + tSec * 6) % (cssW + 240) + (cssW + 240)) % (cssW + 240) - 120;
      const cy0 = hy - 30 - (i % 3) * 26;
      if (cy0 < -20) continue;
      for (const [ox, oy, r] of [[0, 0, 22], [24, 6, 17], [-24, 8, 16], [8, -10, 15]]) { ctx.beginPath(); ctx.arc(cx0 + ox, cy0 + oy, r, 0, 7); ctx.fill(); }
    }
    // water out to the horizon
    const wy = Math.max(0, Math.min(cssH, hy));
    const water = ctx.createLinearGradient(0, wy, 0, cssH);
    water.addColorStop(0, "#8EBBD0"); water.addColorStop(0.3, "#3F88B0"); water.addColorStop(1, "#235E86");
    ctx.fillStyle = water; ctx.fillRect(0, wy, cssW, cssH - wy);
  }

  const overviewOn = () => overview;
  const theme = () => THEMES[(view && view.course) | 0] || THEMES[0];
  function drawFloorTile(map, x, y, t, depth, ringD) {
    const fog = Math.max(0, Math.min(0.85, (depth - 12) / 26));
    const par = x % 2;                       // mowing stripes
    const th = theme();
    let col;
    if (t === "r") col = hex2rgb(ringD <= 1.5 ? th.ring[0] : th.ring[1]);
    else if (t === "s") col = par ? SAND_A : SAND_B;
    else if (t === "i") col = par ? ICE_A : ICE_B;
    else if (t === "w") col = POOL;
    else col = hex2rgb(th.grass[par]);
    const quad = [[x, y, 0], [x + 1, y, 0], [x + 1, y + 1, 0], [x, y + 1, 0]];
    if (t === "." || t === "T" || t === "H") { const v = 1 + (vnoise(x * 0.22, y * 0.22) - 0.5) * 0.16 + (hash(x, y) - 0.5) * 0.025; col = col.map(c => Math.max(0, Math.min(255, c * v))); }
    const style = mix(col, fog);
    const sp = fillPoly(quad, style, style, 1.2);
    if (!sp) return;
    if (t === "r") return;
    if (t === "T") fillPoly([[x + 0.08, y + 0.08, 0.004], [x + 0.92, y + 0.08, 0.004], [x + 0.92, y + 0.92, 0.004], [x + 0.08, y + 0.92, 0.004]], mix(hex2rgb("#2F8F3E"), fog), "rgba(255,255,255,.75)", 2);
    // edge shading where the floor meets a wall
    if (isWall(map, x, y - 1) || isWall(map, x - 1, y) || isWall(map, x + 1, y) || isWall(map, x, y + 1)) {
      ctx.fillStyle = "rgba(0,40,10,.14)";
      ctx.beginPath(); ctx.moveTo(sp[0][0], sp[0][1]); for (let i = 1; i < sp.length; i++) ctx.lineTo(sp[i][0], sp[i][1]); ctx.closePath(); ctx.fill();
    }
    if (fog > 0.7) return;
    if ((t === "." || t === "T" || t === "H") && depth < 15 && !overviewOn()) {
      const n = Math.round(16 * (1 - depth / 15));
      for (let i = 0; i < n; i++) {
        const bx = x + hash(x * 13 + i, y * 7), by = y + hash(y * 11 + i, x * 5 + 3);
        const a = proj(bx, by, 0), b = proj(bx + (hash(i, x + y) - 0.5) * 0.05, by, 0.075 + hash(x + i, y) * 0.05);
        if (!a || !b) continue;
        ctx.strokeStyle = hash(i * 3 + x, y) < 0.5 ? "rgba(30,80,30,.35)" : "rgba(170,215,120,.28)";
        ctx.lineWidth = Math.max(0.7, scaleAt(a[2]) * 0.012);
        ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
      }
    }
    if (t === "w") {
    } else if (">v<^".includes(t)) drawBoost(x, y, t, depth);
    else if ("abcd".includes(t)) drawPortal(x + 0.5, y + 0.5, t);
    else if (t === "s") {
      ctx.fillStyle = "rgba(160,110,30,.28)";
      for (let i = 0; i < 4; i++) { const p = proj(x + hash(x * 7 + i, y), y + hash(y * 5 + i, x), 0.01); if (p) ctx.fillRect(p[0], p[1], Math.max(1, scaleAt(p[2]) * 0.03), Math.max(1, scaleAt(p[2]) * 0.02)); }
    }
  }

  function drawBoost(x, y, t, depth) {
    const dir = { ">": [1, 0], "<": [-1, 0], "^": [0, -1], "v": [0, 1] }[t];
    fillPoly([[x, y, 0.005], [x + 1, y, 0.005], [x + 1, y + 1, 0.005], [x, y + 1, 0.005]], "rgba(255,110,40,.42)");
    const flow = (tSec * 1.3) % 1;
    for (let i = -1; i < 2; i++) {
      const o = (i + flow - 0.5) * 0.55;
      const cx0 = x + 0.5 + dir[0] * o, cy0 = y + 0.5 + dir[1] * o;
      const px = -dir[1], py = dir[0];
      const tip = [cx0 + dir[0] * 0.2, cy0 + dir[1] * 0.2, 0.01];
      const l = [cx0 - dir[0] * 0.15 + px * 0.34, cy0 - dir[1] * 0.15 + py * 0.34, 0.01], r = [cx0 - dir[0] * 0.15 - px * 0.34, cy0 - dir[1] * 0.15 - py * 0.34, 0.01];
      const l2 = [l[0] + dir[0] * 0.0 - dir[0] * 0.12, l[1] - dir[1] * 0.12, 0.01], r2 = [r[0] - dir[0] * 0.12, r[1] - dir[1] * 0.12, 0.01];
      fillPoly([tip, l, l2, [cx0 - dir[0] * 0.02, cy0 - dir[1] * 0.02, 0.01], r2, r], "#FFE08A");
    }
  }

  function drawPortal(cx0, cy0, t) {
    const hue = "ab".includes(t) ? "#B07CFF" : "#35D6C3";
    const ring = (rad, fill, rot) => {
      const pts = []; for (let i = 0; i < 20; i++) { const a = i / 20 * Math.PI * 2 + rot; pts.push([cx0 + Math.cos(a) * rad, cy0 + Math.sin(a) * rad, 0.012]); }
      fillPoly(pts, fill);
    };
    ring(0.46, hue, 0); ring(0.34, "#2a1650", 0); ring(0.22, "#0b0618", 0);
    ctx.strokeStyle = "#fff";
    for (let k = 0; k < 3; k++) {
      const a0 = tSec * 2.4 + k * 2.1; const pts = [];
      for (let i = 0; i <= 8; i++) { const a = a0 + i * 0.2, rad = 0.2 + k * 0.08; const p = proj(cx0 + Math.cos(a) * rad, cy0 + Math.sin(a) * rad, 0.02); if (p) pts.push(p); }
      if (pts.length > 2) { ctx.lineWidth = Math.max(1.5, scaleAt(pts[0][2]) * 0.03); ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); pts.slice(1).forEach(p => ctx.lineTo(p[0], p[1])); ctx.stroke(); }
    }
  }

  function drawCupGround() {
    const [cx0, cy0] = view.cup;
    const ring = (rad, fill) => { const pts = []; for (let i = 0; i < 20; i++) { const a = i / 20 * Math.PI * 2; pts.push([cx0 + Math.cos(a) * rad, cy0 + Math.sin(a) * rad, 0.015]); } fillPoly(pts, fill); };
    ring(0.56, "rgba(0,0,0,.25)"); ring(0.46, "#e8e8f0"); ring(0.41, "#0c0a12");
  }
  function drawFlag() {
    const base = proj(view.cup[0], view.cup[1], 0), top = proj(view.cup[0], view.cup[1], 1.7);
    if (!base || !top) return;
    const sc = scaleAt(base[2]);
    ctx.strokeStyle = "#f4f4f8"; ctx.lineWidth = Math.max(1.5, sc * 0.03); ctx.beginPath(); ctx.moveTo(base[0], base[1]); ctx.lineTo(top[0], top[1]); ctx.stroke();
    const w = sc * 0.5, hgt = sc * 0.34, wave = Math.sin(tSec * 4) * sc * 0.05;
    ctx.fillStyle = "#E5484D"; ctx.beginPath(); ctx.moveTo(top[0], top[1]); ctx.quadraticCurveTo(top[0] + w * 0.5, top[1] + wave - hgt * 0.15, top[0] + w, top[1] + hgt * 0.3 + wave); ctx.quadraticCurveTo(top[0] + w * 0.5, top[1] + hgt * 0.7 + wave, top[0], top[1] + hgt); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "rgba(60,0,10,.5)"; ctx.lineWidth = 1; ctx.stroke();
  }

  function drawDeco(dc) {
    const kind = theme().deco, cx0 = dc.x + 0.5 + (dc.q * 7 % 1 - 0.5) * 0.5, cy0 = dc.y + 0.5 + (dc.q * 13 % 1 - 0.5) * 0.5;
    const g = proj(cx0, cy0, 0);
    if (!g || g[2] < 2.2) return;     // behind or right beside the camera: skip
    const sc = scaleAt(g[2]), at = (z, ox = 0, oy = 0) => proj(cx0 + ox, cy0 + oy, z);
    const blob = (p, r, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(p[0], p[1], Math.max(1, r), 0, 7); ctx.fill(); };
    ctx.fillStyle = "rgba(0,0,0,.2)"; ctx.beginPath(); ctx.ellipse(g[0] + sc * 0.1, g[1], sc * (dc.kind === "big" ? 0.7 : 0.4), sc * 0.14, 0, 0, 7); ctx.fill();
    if (dc.kind === "big" && (kind === "tree" || kind === "flower")) {
      const top = at(1.1);
      ctx.strokeStyle = "#7A4A25"; ctx.lineWidth = Math.max(2, sc * 0.16); ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(g[0], g[1]); ctx.lineTo(top[0], top[1]); ctx.stroke();
      const cc = at(1.8);
      blob([cc[0] + sc * 0.08, cc[1] + sc * 0.1], sc * 0.85, "#2E8B3F"); blob(cc, sc * 0.8, "#3FAE52"); blob([cc[0] - sc * 0.22, cc[1] - sc * 0.22], sc * 0.4, "#6AD07A");
      if (kind === "flower") for (let i = 0; i < 5; i++) blob([cc[0] + Math.cos(i * 1.9 + dc.q * 9) * sc * 0.5, cc[1] + Math.sin(i * 2.3 + dc.q * 5) * sc * 0.45], sc * 0.09, ["#FF7AA8", "#FFD84A", "#fff"][i % 3]);
    } else if (dc.kind === "big" && kind === "palm") {
      const top = at(2.1, 0.25, 0);
      ctx.strokeStyle = "#9C6B3E"; ctx.lineWidth = Math.max(2, sc * 0.14); ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(g[0], g[1]); ctx.quadraticCurveTo(g[0] - sc * 0.1, (g[1] + top[1]) / 2, top[0], top[1]); ctx.stroke();
      ctx.strokeStyle = "#2FA64A"; ctx.lineWidth = Math.max(2, sc * 0.12);
      for (let i = 0; i < 7; i++) { const a = i / 7 * Math.PI * 2 + dc.q * 6; ctx.beginPath(); ctx.moveTo(top[0], top[1]); ctx.quadraticCurveTo(top[0] + Math.cos(a) * sc * 0.55, top[1] - sc * 0.35, top[0] + Math.cos(a) * sc * 0.95, top[1] + Math.sin(a) * sc * 0.25 + sc * 0.3); ctx.stroke(); }
      blob([top[0], top[1] + sc * 0.08], sc * 0.1, "#6B4423");
    } else if (dc.kind === "big") {   // cactus
      const top = at(1.5), w = Math.max(3, sc * 0.2);
      ctx.strokeStyle = "#3C9E4A"; ctx.lineWidth = w; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(g[0], g[1]); ctx.lineTo(top[0], top[1]); ctx.stroke();
      const m = at(0.8, 0.0, 0.0);
      ctx.lineWidth = w * 0.7; ctx.beginPath(); ctx.moveTo(m[0], m[1]); ctx.lineTo(m[0] + sc * 0.3, m[1]); ctx.lineTo(m[0] + sc * 0.3, m[1] - sc * 0.35); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(m[0], m[1] + sc * 0.1); ctx.lineTo(m[0] - sc * 0.28, m[1] + sc * 0.1); ctx.lineTo(m[0] - sc * 0.28, m[1] - sc * 0.15); ctx.stroke();
    } else if (kind === "rock") {
      const c = at(0.2);
      ctx.fillStyle = "#A8896B"; ctx.beginPath(); ctx.ellipse(c[0], c[1], sc * 0.36, sc * 0.26, 0, 0, 7); ctx.fill();
      ctx.fillStyle = "#C9AE92"; ctx.beginPath(); ctx.ellipse(c[0] - sc * 0.08, c[1] - sc * 0.08, sc * 0.2, sc * 0.12, 0, 0, 7); ctx.fill();
    } else {   // bush with flowers
      const c = at(0.35);
      blob(c, sc * 0.38, "#2F9A47"); blob([c[0] - sc * 0.1, c[1] - sc * 0.1], sc * 0.24, "#58C46C");
      for (let i = 0; i < 4; i++) blob([c[0] + Math.cos(i * 1.7 + dc.q * 8) * sc * 0.26, c[1] + Math.sin(i * 2.1 + dc.q * 4) * sc * 0.2], sc * 0.06, ["#FF7AA8", "#FFD84A", "#fff", "#FF9A4A"][i]);
    }
  }

  function drawWall(map, x, y) {
    const H = WALL_H, P = theme().wall;
    const faces = [
      { n: [0, 1], ok: !isWall(map, x, y + 1), pts: [[x, y + 1, 0], [x + 1, y + 1, 0], [x + 1, y + 1, H], [x, y + 1, H]], shade: P.a, c: [x + 0.5, y + 1] },
      { n: [0, -1], ok: !isWall(map, x, y - 1), pts: [[x + 1, y, 0], [x, y, 0], [x, y, H], [x + 1, y, H]], shade: P.a, c: [x + 0.5, y] },
      { n: [1, 0], ok: !isWall(map, x + 1, y), pts: [[x + 1, y + 1, 0], [x + 1, y, 0], [x + 1, y, H], [x + 1, y + 1, H]], shade: P.b, c: [x + 1, y + 0.5] },
      { n: [-1, 0], ok: !isWall(map, x - 1, y), pts: [[x, y, 0], [x, y + 1, 0], [x, y + 1, H], [x, y, H]], shade: P.c, c: [x, y + 0.5] }
    ];
    for (const f of faces) {
      if (!f.ok) continue;
      if ((cam.x - f.c[0]) * f.n[0] + (cam.y - f.c[1]) * f.n[1] <= 0) continue;
      const sp = fillPoly(f.pts, f.shade, P.line, 1);
      if (!overview) {   // soft shadow where the wall meets the grass
        const o = 0.32, p0 = f.pts[0], p1 = f.pts[1];
        const strip = projPoly([[p0[0], p0[1], 0.003], [p1[0], p1[1], 0.003], [p1[0] + f.n[0] * o, p1[1] + f.n[1] * o, 0.003], [p0[0] + f.n[0] * o, p0[1] + f.n[1] * o, 0.003]]);
        if (strip && strip.length === 4) {
          const mx = (strip[0][0] + strip[1][0]) / 2, my = (strip[0][1] + strip[1][1]) / 2, ex = (strip[2][0] + strip[3][0]) / 2, ey = (strip[2][1] + strip[3][1]) / 2;
          const g = ctx.createLinearGradient(mx, my, ex, ey); g.addColorStop(0, "rgba(10,30,10,.38)"); g.addColorStop(1, "rgba(10,30,10,0)");
          ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(strip[0][0], strip[0][1]); for (let i = 1; i < 4; i++) ctx.lineTo(strip[i][0], strip[i][1]); ctx.closePath(); ctx.fill();
        }
      }
      if (sp && sp.length === 4 && Math.hypot(sp[1][0] - sp[0][0], sp[1][1] - sp[0][1]) > 9) {
        const sd = Math.floor(x * 31 + y * 17 + faces.indexOf(f) * 5), th = (view && view.course) | 0;
        ctx.save();
        ctx.transform(sp[1][0] - sp[0][0], sp[1][1] - sp[0][1], sp[3][0] - sp[0][0], sp[3][1] - sp[0][1], sp[0][0], sp[0][1]);
        ctx.scale(0.01, -0.01);
        ctx.beginPath(); ctx.rect(0, -100, 100, 100); ctx.clip();
        const dark = ctx.createLinearGradient(0, 0, 0, -100); dark.addColorStop(0, "rgba(0,0,0,.22)"); dark.addColorStop(0.45, "rgba(0,0,0,0)");
        ctx.fillStyle = dark; ctx.fillRect(0, -100, 100, 100);
        ctx.lineCap = "round";
        if (th === 0) {          // wooden boards: grain and the odd knot
          ctx.strokeStyle = "rgba(70,35,12,.28)"; ctx.lineWidth = 1.6;
          for (const v of [26, 52, 76]) { ctx.beginPath(); ctx.moveTo(0, -v); ctx.bezierCurveTo(30, -v - 2 - hash(sd, v) * 3, 60, -v + 3, 100, -v - hash(sd + 1, v) * 3); ctx.stroke(); }
          if (hash(sd, 3) < 0.4) { ctx.strokeStyle = "rgba(60,28,10,.4)"; ctx.beginPath(); ctx.ellipse(20 + hash(sd, 4) * 60, -(30 + hash(sd, 5) * 40), 5, 3, 0, 0, 7); ctx.stroke(); }
          ctx.strokeStyle = "rgba(50,25,8,.35)"; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -100); ctx.stroke();
        } else if (th === 1) {   // laid stone blocks
          ctx.strokeStyle = "rgba(120,100,70,.4)"; ctx.lineWidth = 1.4;
          ctx.beginPath(); ctx.moveTo(0, -50); ctx.lineTo(100, -50); ctx.moveTo(50, 0); ctx.lineTo(50, -50); ctx.moveTo(15, -50); ctx.lineTo(15, -100); ctx.moveTo(78, -50); ctx.lineTo(78, -100); ctx.stroke();
        } else if (th === 2) {   // clipped hedge: leafy specks
          for (let i = 0; i < 26; i++) { ctx.fillStyle = i % 3 ? "rgba(10,60,20,.32)" : "rgba(150,225,130,.22)"; ctx.beginPath(); ctx.arc(hash(sd, i) * 100, -hash(sd + 9, i) * 100, 3 + hash(i, sd) * 5, 0, 7); ctx.fill(); }
        } else {                 // layered canyon rock
          ctx.strokeStyle = "rgba(70,25,10,.3)"; ctx.lineWidth = 1.6;
          for (const v of [22, 48, 74]) { ctx.beginPath(); ctx.moveTo(0, -v); ctx.bezierCurveTo(25, -v + 4 * hash(sd, v), 55, -v - 5, 100, -v + 3 * hash(sd, v + 1)); ctx.stroke(); }
          for (let i = 0; i < 10; i++) { ctx.fillStyle = "rgba(60,25,10,.18)"; ctx.fillRect(hash(sd, i + 20) * 100, -hash(sd + 3, i) * 100, 3, 2); }
        }
        ctx.restore();
      }
      const fi = faces.indexOf(f);
      const horiz = fi < 2, rev = fi === 1 || fi === 2;
      const along = horiz ? x : y, other = horiz ? y : x;
      const k = ((along % 3) + 3) % 3, start = along - k;
      const wallAt = (q) => horiz ? isWall(map, q, y) && !isWall(map, q, y + (fi === 0 ? 1 : -1)) : isWall(map, x, q) && !isWall(map, x + (fi === 2 ? 1 : -1), q);
      if (sp && sp.length === 4 && hash(start * 5 + fi * 17, other * 3 + 7) < 0.16 && wallAt(start) && wallAt(start + 1) && wallAt(start + 2)) {
        const wpx = Math.hypot(sp[1][0] - sp[0][0], sp[1][1] - sp[0][1]);
        if (wpx > 14) {   // painted lettering, bent to sit on the wall face and run across three tiles
          const idx = rev ? 2 - k : k;
          ctx.save();
          ctx.transform(sp[1][0] - sp[0][0], sp[1][1] - sp[0][1], sp[3][0] - sp[0][0], sp[3][1] - sp[0][1], sp[0][0], sp[0][1]);
          ctx.scale(0.01, -0.01);
          ctx.beginPath(); ctx.rect(0, -100, 100, 100); ctx.clip();
          ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.lineJoin = "round";
          ctx.font = "900 30px Nunito, Arial, sans-serif";
          ctx.lineWidth = 4; ctx.strokeStyle = "rgba(40,20,10,.5)"; ctx.fillStyle = "#FFF4D6";
          ctx.strokeText("CSPillow Designs", (1.5 - idx) * 100, -48); ctx.fillText("CSPillow Designs", (1.5 - idx) * 100, -48);
          ctx.restore();
        }
      }
    }
    const top = [[x, y, H], [x + 1, y, H], [x + 1, y + 1, H], [x, y + 1, H]];
    const sp = fillPoly(top, P.top, P.line, 1.2);
  }

  function drawBumper(x, y) {
    const cx0 = x + 0.5, cy0 = y + 0.5, r = 0.45, H = 0.5, N = 18;
    const bot = [], top = [];
    for (let i = 0; i < N; i++) { const a = i / N * Math.PI * 2; bot.push([cx0 + Math.cos(a) * r, cy0 + Math.sin(a) * r, 0]); top.push([cx0 + Math.cos(a) * r, cy0 + Math.sin(a) * r, H]); }
    for (let i = 0; i < N; i++) {
      const a = (i + 0.5) / N * Math.PI * 2;
      if ((cam.x - cx0) * Math.cos(a) + (cam.y - cy0) * Math.sin(a) <= 0) continue;
      const j = (i + 1) % N, shade = 0.5 + 0.5 * Math.cos(a - cam.yaw + 2.4);
      fillPoly([bot[i], bot[j], top[j], top[i]], `rgb(${Math.round(150 + 80 * shade)},${Math.round(30 + 40 * shade)},${Math.round(60 + 40 * shade)})`, "rgba(60,10,25,.4)", 1);
    }
    fillPoly(top, "#FFC93C", "rgba(60,10,25,.6)", 1.5);
    fillPoly(top.map(p => [cx0 + (p[0] - cx0) * 0.6, cy0 + (p[1] - cy0) * 0.6, H + 0.005]), "#FF6B8B");
    // the shadow on the floor
    fillPoly(bot.map(p => [cx0 + (p[0] - cx0) * 1.18 + 0.08, cy0 + (p[1] - cy0) * 1.18 + 0.08, 0.004]), "rgba(0,0,0,.22)");
  }

  function drawPlayer(seat, p) {
    if (isOut(seat)) return null;
    const info = seatInfo(seat);
    const g = proj(p.x, p.y, 0), c = proj(p.x, p.y, 0.34);
    if (!g || !c) return null;
    const vr = scaleAt(c[2]) * 0.36;
    ctx.fillStyle = "rgba(0,0,0,.3)"; ctx.beginPath(); ctx.ellipse(g[0] + vr * 0.1, g[1], vr * 0.95, Math.max(2, vr * 0.4), 0, 0, 7); ctx.fill();
    drawBall(ctx, c[0], c[1], vr, info.color.hex, info.hat, tSec, { shadow: false });
    return { seat, x: c[0], y: c[1] - vr * (info.hat === "none" ? 1.4 : 3.0), vr };
  }

  const tagRects = [];
  function drawTag(t) {
    const info = seatInfo(t.seat);
    const label = (info.name || "").slice(0, 12);
    const fs = Math.max(11, Math.min(15, t.vr * 0.62));
    ctx.font = `800 ${fs}px Nunito, sans-serif`;
    const w = ctx.measureText(label).width + 12, hh = fs + 6;
    let top = t.y;
    for (let tries = 0; tries < 6; tries++) {
      if (!tagRects.some(r => Math.abs(r.x - t.x) < (r.w + w) / 2 && Math.abs(r.y - top) < hh + 1)) break;
      top -= hh + 2;
    }
    tagRects.push({ x: t.x, y: top, w });
    const active = t.seat === api.you;
    ctx.fillStyle = active ? "rgba(255,181,71,.95)" : "rgba(15,12,25,.62)";
    ctx.beginPath(); ctx.roundRect(t.x - w / 2, top - hh / 2, w, hh, hh / 2); ctx.fill();
    ctx.fillStyle = active ? "#241a05" : "#fff";
    ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(label, t.x, top + 1);
  }

  function drawParticles() {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life -= lastDt; if (p.life <= 0) { particles.splice(i, 1); continue; }
      p.x += p.vx * lastDt; p.y += p.vy * lastDt; p.z += p.vz * lastDt; p.vz -= 9 * lastDt; if (p.z < 0) { p.z = 0; p.vz *= -0.4; }
      const s = proj(p.x, p.y, p.z);
      if (!s) continue;
      const sz = Math.max(2, scaleAt(s[2]) * 0.035 * p.size / 3);
      ctx.globalAlpha = Math.min(1, p.life * 2); ctx.fillStyle = p.color;
      ctx.fillRect(s[0] - sz / 2, s[1] - sz / 2, sz, sz);
      ctx.globalAlpha = 1;
    }
  }

  function drawAim() {
    if (!myTurn() || overview) return;
    const p = ballPos(api.you);
    const power = aim.power;
    const showing = power >= MIN_POWER || drag;
    const len = showing ? 1.1 + power * 8.5 : 2.6;
    const col = !showing ? "#ffffff" : power < 0.5 ? "#8FE3A6" : power < 0.8 ? "#FFE066" : "#FF8A80";
    ctx.save();
    if (!showing) ctx.globalAlpha = 0.55 + 0.3 * Math.sin(tSec * 4);
    const dx = Math.cos(aim.angle), dy = Math.sin(aim.angle);
    // dashes along the ground
    for (let d = 0.55; d < len; d += 0.55) {
      const a = proj(p.x + dx * d, p.y + dy * d, 0.03), b = proj(p.x + dx * (d + 0.3), p.y + dy * (d + 0.3), 0.03);
      if (!a || !b) continue;
      ctx.strokeStyle = col; ctx.lineCap = "round"; ctx.lineWidth = Math.max(2, scaleAt(a[2]) * 0.1);
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
    }
    // arrow head
    const tip = [p.x + dx * (len + 0.5), p.y + dy * (len + 0.5), 0.03], l = [p.x + dx * len - dy * 0.3, p.y + dy * len + dx * 0.3, 0.03], r = [p.x + dx * len + dy * 0.3, p.y + dy * len - dx * 0.3, 0.03];
    fillPoly([tip, l, r], col, "rgba(0,0,0,.35)", 1.5);
    ctx.restore();
    if (showing) {
      // power gauge on the side
      const gx = 14, gy = cssH * 0.3, gh = cssH * 0.42;
      ctx.fillStyle = "rgba(10,8,20,.6)"; ctx.beginPath(); ctx.roundRect(gx, gy, 16, gh, 8); ctx.fill();
      ctx.fillStyle = col; ctx.beginPath(); ctx.roundRect(gx + 2, gy + gh - 2 - (gh - 4) * power, 12, Math.max(2, (gh - 4) * power), 6); ctx.fill();
      ctx.font = "800 14px Nunito, sans-serif"; ctx.textAlign = "left"; ctx.fillStyle = "#fff"; ctx.strokeStyle = "rgba(0,0,0,.6)"; ctx.lineWidth = 3;
      const txt = `${Math.round(power * 100)}%`; ctx.strokeText(txt, gx + 22, gy + gh - (gh - 4) * power); ctx.fillText(txt, gx + 22, gy + gh - (gh - 4) * power);
    }
  }

  function drawHoleArrow() {
    // when the hole is off to the side, an arrow on that edge points to it, with the distance
    const from = ballPos(api.you);
    const dx = view.cup[0] - from.x, dy = view.cup[1] - from.y, d = Math.hypot(dx, dy);
    const rel = angDiff(Math.atan2(dy, dx), cam.yaw);
    const s = proj(view.cup[0], view.cup[1], 0.6);
    const m = 30;
    if (s && s[0] > m && s[0] < cssW - m && s[1] > m && s[1] < cssH - m) {
      // visible: just a distance label floating over the flag
      const sc = scaleAt(s[2]);
      ctx.font = "800 13px Nunito, sans-serif"; ctx.textAlign = "center"; ctx.fillStyle = "#fff"; ctx.strokeStyle = "rgba(0,0,0,.6)"; ctx.lineWidth = 3;
      const top = proj(view.cup[0], view.cup[1], 2.0);
      if (top) { ctx.strokeText(`${Math.round(d)}m`, top[0], top[1] - 6); ctx.fillText(`${Math.round(d)}m`, top[0], top[1] - 6); }
      void sc;
      return;
    }
    const right = rel > 0;
    const ex = right ? cssW - m : m, ey = Math.max(CY - 10, Math.min(cssH - 80, s ? s[1] : CY));
    ctx.save(); ctx.translate(ex, ey);
    if (Math.abs(rel) > 2.4) ctx.translate(0, 0);
    ctx.fillStyle = "#FFD84A"; ctx.strokeStyle = "rgba(0,0,0,.5)"; ctx.lineWidth = 2;
    ctx.scale(right ? 1 : -1, 1);
    ctx.beginPath(); ctx.moveTo(16, 0); ctx.lineTo(-8, -12); ctx.lineTo(-2, 0); ctx.lineTo(-8, 12); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
    ctx.font = "800 13px Nunito, sans-serif"; ctx.textAlign = "center"; ctx.fillStyle = "#fff"; ctx.strokeStyle = "rgba(0,0,0,.6)"; ctx.lineWidth = 3;
    ctx.strokeText(`${Math.round(d)}m`, ex + (right ? -26 : 26), ey - 16); ctx.fillText(`${Math.round(d)}m`, ex + (right ? -26 : 26), ey - 16);
  }

  function drawMini() {
    const map = view.map, W = map[0].length, H = map.length;
    const mw = Math.min(104, cssW * 0.28), t = mw / W, mh = H * t;
    const x0 = cssW - mw - 11, y0 = 54;
    ctx.globalAlpha = 0.92; ctx.fillStyle = "rgba(10,8,20,.55)"; ctx.fillRect(x0 - 3, y0 - 3, mw + 6, mh + 6);
    const colors = { "#": "#9aa2b2", w: "#2D9BEA", s: "#F0D275", i: "#BCE8FB", o: "#FF6B8B" };
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { ctx.fillStyle = colors[map[y][x]] || "#46A84A"; ctx.fillRect(x0 + x * t, y0 + y * t, Math.ceil(t), Math.ceil(t)); }
    ctx.fillStyle = "#000"; ctx.beginPath(); ctx.arc(x0 + view.cup[0] * t, y0 + view.cup[1] * t, Math.max(2, t * 0.7), 0, 7); ctx.fill();
    for (const seat of balls.keys()) {
      if (isOut(seat)) continue;
      const p = ballPos(seat);
      ctx.fillStyle = seatInfo(seat).color.hex; ctx.strokeStyle = "#000"; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(x0 + p.x * t, y0 + p.y * t, Math.max(2.5, t * 0.8), 0, 7); ctx.fill(); ctx.stroke();
    }
    // which way the camera faces
    const f = ballPos(api.you);
    ctx.strokeStyle = "#fff"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x0 + f.x * t, y0 + f.y * t); ctx.lineTo(x0 + (f.x + Math.cos(cam.yaw) * 3) * t, y0 + (f.y + Math.sin(cam.yaw) * 3) * t); ctx.stroke();
    ctx.globalAlpha = 1;
  }

  function draw() {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    updateCamera();
    const LY = (n) => !window.__layers || window.__layers.includes(n);   // (design export: draw only some layers)
    if (LY("sky")) drawSky(); else ctx.clearRect(0, 0, cssW, cssH);
    if (!view) return;
    const map = view.map, W = map[0].length, H = map.length;

    // which tiles are worth drawing: in front of the camera and not too far away
    const fx = F[0], fy = F[1], hl = Math.hypot(fx, fy) || 1;
    const dirx = fx / hl, diry = fy / hl;
    const span = overview ? 80 : 30;
    const x0 = Math.max(0, Math.floor(cam.x - span)), x1 = Math.min(W - 1, Math.ceil(cam.x + span));
    const y0 = Math.max(0, Math.floor(cam.y - span)), y1 = Math.min(H - 1, Math.ceil(cam.y + span));
    const tiles = [];
    const halfTan = cssW / 2 / FOCAL;
    const seen = (x, y) => {   // is this tile in front of the camera, not too far, and not far off to the side?
      const c = toCam(x + 0.5, y + 0.5, 0);
      return c[2] > -2.5 && c[2] < 32 && Math.abs(c[0]) < Math.max(c[2], 0) * halfTan + 3;
    };
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const depth = (x + 0.5 - cam.x) * dirx + (y + 0.5 - cam.y) * diry;
      if (!overview && !seen(x, y)) continue;
      tiles.push({ x, y, depth, t: map[y][x] });
    }
    // the ground around the course, with trees, bushes or rocks on it
    const decos = [];
    if (!overview) {
      for (let y = -5; y < H + 5; y++) for (let x = -5; x < W + 5; x++) {
        if (x >= 0 && y >= 0 && x < W && y < H) continue;
        const depth = (x + 0.5 - cam.x) * dirx + (y + 0.5 - cam.y) * diry;
        if (!seen(x, y)) continue;
        const d = Math.max(0, -x, x - (W - 1), -y, y - (H - 1));
        tiles.push({ x, y, depth, t: "r", d });
        // (no trees, cacti or rocks around the outside: just plain ground)
      }
    }
    tiles.sort((a, b) => b.depth - a.depth);
    if (LY("ground")) for (const tl of tiles) if (tl.t !== "#") drawFloorTile(map, tl.x, tl.y, tl.t, Math.max(0.5, tl.depth + (overview ? cam.z : 0)), tl.d);
    if (LY("cup")) drawCupGround();

    // everything that stands up, far to near
    const things = [];
    for (const tl of tiles) {
      if (tl.t === "#") { if (LY("walls")) things.push({ depth: tl.depth, draw: () => drawWall(map, tl.x, tl.y) }); }
      else if (tl.t === "o") { if (LY("bumpers")) things.push({ depth: tl.depth, draw: () => drawBumper(tl.x, tl.y) }); }
    }
    if (LY("scenery")) for (const dc of decos) things.push({ depth: dc.depth, draw: () => drawDeco(dc) });
    if (LY("cup")) things.push({ depth: (view.cup[0] - cam.x) * dirx + (view.cup[1] - cam.y) * diry, draw: drawFlag });
    const tags = [];
    for (const seat of balls.keys()) {
      const p = ballPos(seat);
      if (LY("balls")) things.push({ depth: (p.x - cam.x) * dirx + (p.y - cam.y) * diry + 0.15, draw: () => { const t = drawPlayer(seat, p); if (t) tags.push(t); } });
    }
    things.sort((a, b) => b.depth - a.depth);
    for (const th of things) th.draw();

    if (LY("aim")) { drawParticles(); drawAim(); }
    tagRects.length = 0;
    tags.sort((a, b) => a.y - b.y);
    if (LY("tags")) for (const t of tags) drawTag(t);
    if (LY("hud")) { drawHoleArrow(); drawMini(); }
    if (!LY("vignette")) return;
    const vg = ctx.createRadialGradient(cssW / 2, cssH * 0.5, cssW * 0.35, cssW / 2, cssH * 0.5, cssW * 0.85);
    vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(10,20,10,.3)");
    ctx.fillStyle = vg; ctx.fillRect(0, 0, cssW, cssH);
  }

  // ---------- page text: HUD, turn banner, hole summary and scorecard ----------
  const verdict = (strokes, par, gaveUp) => {
    if (gaveUp) return "Picked up";
    if (strokes === 1) return "Hole in one!";
    const d = strokes - par;
    return d <= -3 ? "Albatross!" : d === -2 ? "Eagle!" : d === -1 ? "Birdie" : d === 0 ? "Par" : d === 1 ? "Bogey" : d === 2 ? "Double bogey" : `+${d}`;
  };

  function paintHud() {
    if (!view) return;
    hud.replaceChildren(
      h("span.golf-chip", `Hole ${view.hole + 1}/${view.holeCount}`),
      h("span.golf-chip.par", `Par ${view.par}`),
      h("span.golf-chip.you", `Strokes ${B(api.you).strokes || 0}`),
      h("span.golf-name", view.holeName));
    const out = [];
    if (room && room.status === "playing" && view.phase === "play") {
      const st = B(api.you).state;
      out.push(h("strong", st === "sunk" ? "In the hole! Watching the others..." : st === "out" ? "Picked up. Watching the others..."
        : st === "roll" || waiting ? "Rolling..." : ""));
    }
    turn.replaceChildren(...out);
  }

  function paintOverlay() {
    overlay.replaceChildren();
    if (!view || view.phase !== "holeover") { overlay.classList.remove("show"); return; }
    overlay.classList.add("show");
    const last = view.scores[view.scores.length - 1] || [];
    const rows = last.map((strokes, seat) => ({ seat, strokes })).sort((a, b) => a.strokes - b.strokes);
    const final = view.hole + 1 >= view.holeCount;
    overlay.appendChild(h("div.golf-card",
      h("h3", `Hole ${view.hole + 1} complete`),
      h("div.muted", `${view.holeName} · Par ${view.par}`),
      h("div.golf-results", rows.map(r => {
        const i = seatInfo(r.seat);
        return h("div.golf-result", ballCanvas(i.color.hex, i.hat, 34), h("span.nm", i.name), h("span.vd", verdict(r.strokes, view.par, B(r.seat).gaveUp)), h("strong", String(r.strokes)));
      })),
      h("button.btn.primary", { type: "button", onclick: () => api.sendQuiet({ kind: "next", seq: ++shotSeq }) }, final ? "See final scores" : "Next hole")));
  }

  function paintBoard() {
    if (!view) return;
    const head = h("tr", h("th.who", ""), ...Array.from({ length: view.holeCount }, (_, i) => h("th", { class: i === view.hole && view.phase !== "over" ? "now" : "" }, String(i + 1))), h("th.tot", "Total"));
    const parRow = h("tr.par", h("th.who", "Par"), ...view.pars.map(p => h("td", String(p))), h("td.tot", String(view.pars.reduce((a, b) => a + b, 0))));
    const rows = [];
    for (let seat = 0; seat < view.playerCount; seat++) {
      const i = seatInfo(seat);
      const cells = view.pars.map((par, hole) => {
        const done = view.scores[hole];
        if (done) { const s = done[seat], d = s - par; return h("td", { class: d < 0 ? "under" : d > 0 ? "over" : "" }, String(s)); }
        if (hole === view.hole && view.phase === "play") return h("td.live", B(seat).strokes ? String(B(seat).strokes) : "·");
        return h("td", "");
      });
      rows.push(h("tr", { class: seat === api.you ? "me" : "" },
        h("th.who", ballCanvas(i.color.hex, i.hat, 26), h("span", i.name)), ...cells, h("td.tot", String(view.totals[seat]))));
    }
    board.replaceChildren(h("div.golf-board-scroll", h("table.golf-table", h("thead", head), h("tbody", parRow, ...rows))));
  }

  // ---------- frame loop ----------
  function frame(ts) {
    if (destroyed) return;
    raf = requestAnimationFrame(frame);
    if (!last) last = ts;
    lastDt = Math.min(0.05, (ts - last) / 1000); last = ts; tSec += lastDt;
    if (hidden) return;
    stepAnims();
    const t0 = performance.now();
    draw();
    const cost = performance.now() - t0;
    slowMs = cost > 14 ? slowMs + lastDt * 1000 : Math.max(0, slowMs - lastDt * 500);
    if (slowMs > 1200 && dprCap > 1) { dprCap = Math.max(1, dprCap - 0.25); slowMs = 0; resize(); }
  }

  function applyView(next, r) {
    const key = `${r.match}:${next.course}:${next.hole}`;
    const newHole = key !== lastHoleKey;
    const prev = view;
    view = next;
    if (newHole) {
      lastHoleKey = key;
      anims.clear(); particles.length = 0;
      cam.ready = false; waiting = false; aim.power = 0; drag = null; lastTick = -1;
      aim.angle = 0;   // no hints: the camera doesn't start out pointing at the hole
    }
    for (let s = 0; s < view.playerCount; s++) {
      const b = view.balls[s];
      balls.set(s, { x: b.x, y: b.y });
    }
    for (const s of [...balls.keys()]) if (s >= view.playerCount) balls.delete(s);
    // a new tick: queue up where the moving balls went, and react to what happened
    if (view.tick !== lastTick) {
      const fresh = lastTick >= 0;
      lastTick = view.tick;
      view.balls.forEach((b, s) => pushTrail(s, b.trail));
      if (fresh) handleEvents(view.events);
      const was = prev ? prev.balls[api.you] : null, now = B(api.you);
      if (now.state !== "rest" || (was && now.strokes > was.strokes)) waiting = false;
    }
  }

  resize();
  raf = requestAnimationFrame(frame);
  const vis = () => { hidden = document.hidden; };
  document.addEventListener("visibilitychange", vis);

  return {
    update(r) {
      room = r;
      if (!r.view) return;
      const first = !view;
      applyView(r.view, r);
      if (first) resize();
      const sig = JSON.stringify([view.phase, view.hole, view.balls.map(b => [b.state, b.strokes]), view.scores, view.totals, r.status]);
      if (sig !== lastSig) { lastSig = sig; paintHud(); paintOverlay(); paintBoard(); }
    },
    onError(request) { if (request === "move") { waiting = false; paintHud(); } },
    destroy() {
      destroyed = true;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("keydown", keyDown);
      document.removeEventListener("visibilitychange", vis);
    },
    seatInfo(seat) { return view ? `${view.totals[seat]} total` : ""; },
    banner(r) {
      if (!view || r.status !== "playing") return ["", false];
      if (view.phase === "holeover") return [`Hole ${view.hole + 1} done`, false];
      const st = B(api.you).state;
      if (st === "sunk" || st === "out") return ["Finished the hole", false];
      return [st === "rest" && !waiting ? "" : "Rolling...", false];
    },
    ranking(r) {
      if (!view) return [];
      const par = view.pars.reduce((a, b) => a + b, 0);
      return view.totals.map((n, seat) => ({ seat, n })).sort((a, b) => a.n - b.n)
        .map(x => ({ seat: x.seat, text: `${x.n} strokes (${x.n - par >= 0 ? "+" : ""}${x.n - par})` }));
    },
    resultTitle(r) {
      if (!view || !r.result) return null;
      const w = r.result.winningSeats || [];
      if (w.length === 1) return w[0] === api.you ? "You won the round!" : `${api.seatName(w[0])} won the round!`;
      return w.length ? "A tie at the top!" : null;
    }
  };
}
