// The cat playing pieces: little glossy plastic cat figures, drawn as SVG (no image files).
export const CATS = {
  tabby:   { name: "Hank", fur: "#F2993A", furDark: "#C9701F", belly: "#FFE0B5", eye: "#5BBF5B", base: "#F2993A", style: "tabby" },
  tuxedo:  { name: "Oreo",         fur: "#3A3A48", furDark: "#16161d", belly: "#FFFFFF", eye: "#E6C84A", base: "#3C3C4C", style: "tuxedo" },
  siamese: { name: "Benson",      fur: "#F1E2C6", furDark: "#5B3E33", belly: "#FFF6E4", eye: "#4EA8F0", base: "#D9C29B", style: "siamese" },
  calico:  { name: "Theo",      fur: "#FFFFFF", furDark: "#E58A2B", belly: "#FFFFFF", eye: "#D9A441", base: "#F5F1EA", style: "calico" },
  gray:    { name: "Smokey",       fur: "#8E96A6", furDark: "#626B7C", belly: "#D5D9E2", eye: "#E0B93C", base: "#8E96A6", style: "tabby" },
  fluffy:  { name: "Winnie", fur: "#9A6A43", furDark: "#6E4527", belly: "#E0BD93", eye: "#E0A93C", base: "#9A6A43", style: "fluffy" },
  black:   { name: "Shadow",       fur: "#3E3E4C", furDark: "#101015", belly: "#33333E", eye: "#F0D23C", base: "#34343F", style: "plain" },
  witch:   { name: "Penelope", fur: "#FBF8F0", furDark: "#E58A2B", belly: "#FFFFFF", eye: "#7CC47C", base: "#F3EEE4", style: "witch" },
  reaper:  { name: "Amandaaaaaaa", fur: "#3E3E4C", furDark: "#101015", belly: "#33333E", eye: "#4EA8F0", base: "#34343F", style: "reaper" }
};
export const CAT_IDS = Object.keys(CATS);
export const catName = (id) => (CATS[id] ? CATS[id].name : "Cat");

let uid = 0;
/** One cat piece as an SVG element string. Taller than wide (60 x 80). */
export function catSVGString(kind) {
  const c = CATS[kind] || CATS.tabby;
  const id = "cp" + (uid++);
  const dark = c.furDark;
  const siamese = c.style === "siamese", tux = c.style === "tuxedo", calico = c.style === "calico", tabby = c.style === "tabby";
  const earOuter = siamese ? dark : c.fur;
  const paw = siamese ? dark : tux ? "#FFFFFF" : c.fur;
  const tail = siamese ? dark : calico ? c.furDark : c.fur;
  const stripes = tabby ? `
    <path d="M30 15 L30 21 M25.5 16.5 L26.5 21 M34.5 16.5 L33.5 21" stroke="${dark}" stroke-width="2" stroke-linecap="round" fill="none"/>
    <path d="M19 52 Q23 50 25 54 M19 59 Q23 57 25 61 M41 52 Q37 50 35 54 M41 59 Q37 57 35 61" stroke="${dark}" stroke-width="2.2" stroke-linecap="round" fill="none"/>` : "";
  const patches = calico ? `
    <ellipse cx="22.5" cy="22" rx="6.5" ry="5.5" fill="${c.furDark}"/>
    <path d="M36 12 L41 8 L42 18 Z" fill="#2B2B33"/>
    <ellipse cx="38" cy="54" rx="6" ry="8" fill="#2B2B33"/>
    <ellipse cx="23" cy="60" rx="4.5" ry="5" fill="${c.furDark}"/>` : "";
  const fluffy = c.style === "fluffy";
  const tuft = (x, y, r, col) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${col}" stroke="#2a1f18" stroke-width="1.3"/>`;
  const fluffBody = fluffy ? [[16.5, 60, 4.6], [14.5, 52, 4.8], [16.5, 44, 4.4], [43.5, 60, 4.6], [45.5, 52, 4.8], [43.5, 44, 4.4], [20, 39.5, 4], [40, 39.5, 4]].map(([x, y, r]) => tuft(x, y, r, c.fur)).join("") : "";
  const fluffHead = fluffy ? Array.from({ length: 13 }, (_, i) => { const a = (Math.PI * (0.02 + i * 0.077)); const side = i % 2 ? 1 : -1; return null; }).join("") : "";
  const ruff = fluffy ? [[16.5, 30, 4.4], [15.5, 36, 4.2], [20, 40, 4.4], [25, 41.5, 4.2], [30, 42, 4.4], [35, 41.5, 4.2], [40, 40, 4.4], [44.5, 36, 4.2], [43.5, 30, 4.4]].map(([x, y, r]) => tuft(x, y, r, c.belly)).join("") : "";
  const chestFluff = fluffy ? `<ellipse cx="30" cy="52" rx="7.5" ry="11" fill="${c.belly}"/>${[[26, 47], [34, 48], [30, 53], [26, 58], [34, 59]].map(([x, y]) => `<path d="M${x - 2.4} ${y} Q${x} ${y + 3.4} ${x + 2.4} ${y}" stroke="${c.fur}" stroke-width="1.1" fill="none" stroke-linecap="round" opacity=".75"/>`).join("")}` : "";
  const tailFluff = fluffy ? [[55, 42, 4.2], [57.5, 48, 4.4], [56.5, 55, 4.2], [51, 60, 4.4], [49, 40, 3.8]].map(([x, y, r]) => tuft(x, y, r, c.fur)).join("") : "";
  const reaper = c.style === "reaper";
  // Grim Reaper: black hooded robe, a scythe behind her, and long straight blonde hair (a little irregular so it doesn't look drawn with a ruler)
  const ROBE = "#1d1d27", HAIR = ["#EBCB6A", "#F3DC8C", "#E3BE55", "#F7E6A6", "#DDB64D"];
  const jit = (n) => { const x = Math.sin(n * 91.7 + 3.1) * 43758.5453; return x - Math.floor(x); };
  const hairSide = (m) => {                    // one long straight curtain of hair; m = -1 left, +1 right
    const X = (dx) => (30 + m * dx).toFixed(2), j = (n) => jit(n + (m > 0 ? 7 : 0));
    const e1 = 54 + j(1) * 4, e2 = 58 + j(2) * 4, e3 = 55 + j(3) * 4, e4 = 59 + j(4) * 3;
    const body = `<path d="M${X(-12.5)} 15 C${X(-17)} 11.5 ${X(-21.5)} 18 ${X(-21.6)} 30 L${X(-21.2)} ${e1.toFixed(1)} L${X(-18.4)} ${e2.toFixed(1)} L${X(-16.2)} ${e3.toFixed(1)} L${X(-13.8)} ${e4.toFixed(1)} L${X(-12.2)} 50 Z" fill="${HAIR[0]}" stroke="#B8923A" stroke-width=".6" stroke-linejoin="round"/>`;
    const lines = [-19.6, -17.8, -16.0, -14.2].map((dx, i) =>
      `<path d="M${X(dx)} ${(23 + i * 1.5).toFixed(1)} L${X(dx + (m > 0 ? .1 : -.1))} ${(47 + j(i + 9) * 8).toFixed(1)}" stroke="${i % 2 ? "#F9EBB5" : "#CFA441"}" stroke-width=".8" stroke-linecap="round" opacity=".75"/>`).join("");
    return body + lines;
  };
  const bangs = `<path d="M30 9 C21 8.6 15.4 14 15.2 23 C17.2 19.6 20.6 18.6 23.6 19.6 C26 19 28.2 17.2 30 14.5 C31.8 17.2 34 19 36.4 19.6 C39.4 18.6 42.8 19.6 44.8 23 C44.6 14 39 8.6 30 9 Z" fill="${HAIR[1]}" stroke="#B8923A" stroke-width=".6" stroke-linejoin="round"/>` +
    [[-9, 12.5], [-6.5, 13.5], [-4, 14.2], [4, 14.2], [6.5, 13.5], [9, 12.5]].map(([dx, y0], i) => `<path d="M${30 + dx * 0.3} 10 Q${30 + dx * 0.8} ${y0} ${30 + dx} ${(19 - Math.abs(dx) * 0.15).toFixed(1)}" stroke="${i % 2 ? "#F9EBB5" : "#CFA441"}" stroke-width=".7" fill="none" stroke-linecap="round" opacity=".7"/>`).join("");
  const scythe = reaper ? `<path d="M52.5 73 L53.2 13" stroke="#6b4a2b" stroke-width="2.2" stroke-linecap="round"/><path d="M53.5 13.5 C49 5.5 41 6.5 36.5 11.5 C43 9.8 49 12 53.5 20 Z" fill="#CBD0D8" stroke="#555a66" stroke-width=".9" stroke-linejoin="round"/>` : "";
  const hood = reaper ? `<path d="M10.5 36 C7 17 19 5 30 3.2 C41 5 53 17 49.5 36 C47 45 13 45 10.5 36 Z" fill="${ROBE}" stroke="#0c0c12" stroke-width=".9"/>` : "";
  const hairSides = "";
  const bow = reaper ? `<path d="M39 12 L44.6 9.2 L44.2 15.4 Z M39 12 L34.2 9 L34.6 15 Z" fill="#E98FB0" stroke="#A5546F" stroke-width=".7" stroke-linejoin="round"/><circle cx="39" cy="12" r="1.6" fill="#F4B6CB" stroke="#A5546F" stroke-width=".7"/>` : "";
  const witch = c.style === "witch";
  // Dottie: white with orange polka dots, in a black witch hat with a tiny Benson (the Siamese) on it
  const bodyClip = `${id}bc`, headClip = `${id}hc`;
  const dot = (x, y, r) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#E58A2B"/>`;
  const witchClips = witch ? `<defs><clipPath id="${bodyClip}"><path d="M17 67 C14 50 21 37 30 37 C39 37 46 50 43 67 Z"/></clipPath><clipPath id="${headClip}"><circle cx="30" cy="27" r="14"/></clipPath></defs>` : "";
  const bodyDots = witch ? `<g clip-path="url(#${bodyClip})">${[[24, 44.5, 2.8], [35.5, 42.5, 2.3], [29.5, 51, 3], [21.5, 57, 2.4], [38.5, 56, 2.8], [29, 62.5, 2.5], [44, 47, 2.2]].map(d => dot(...d)).join("")}</g>` : "";
  const headDots = witch ? `<g clip-path="url(#${headClip})">${[[20.5, 23.5, 2.9], [39, 22, 2.5], [34.5, 33, 2], [22, 33, 1.9], [30, 17, 2]].map(d => dot(...d)).join("")}</g>` : "";
  const tailDots = witch ? [[56.4, 57.5, 1.7], [57.2, 50, 1.6], [53.8, 42.6, 1.5]].map(d => dot(...d)).join("") : "";
  const witchHat = witch ? `<ellipse cx="30" cy="16" rx="17.5" ry="4.4" transform="rotate(-4 30 16)" fill="#2e2638" stroke="#2a1f18" stroke-width="1.5"/>
    <path d="M21 15.5 C23 8 26 2 31 -3 C34 -6 37 -7.2 40.5 -6 C36.5 -4 36 0 36.6 4 C37.1 8 38 12 39 15.5 Z" fill="#2e2638" stroke="#2a1f18" stroke-width="1.5" stroke-linejoin="round"/>
    <path d="M21.9 11.6 C27 12.6 33 12.6 38.1 11.6 L38.7 15.2 C33 16.3 27 16.3 21.3 15.2 Z" fill="#E58A2B" stroke="#2a1f18" stroke-width="1"/>
    <path d="M26.7 3.8 L27.5 0.2 L30.2 2.3 M34.3 3.8 L33.5 0.2 L31 2.3" fill="#5B3E33" stroke="#2a1f18" stroke-width=".7" stroke-linejoin="round"/>
    <circle cx="30.5" cy="6.4" r="4.3" fill="#F1E2C6" stroke="#2a1f18" stroke-width=".8"/><ellipse cx="30.5" cy="7.7" rx="2.4" ry="2" fill="#5B3E33" opacity=".85"/><circle cx="29.2" cy="6.1" r=".65" fill="#4EA8F0"/><circle cx="31.8" cy="6.1" r=".65" fill="#4EA8F0"/>` : "";
  const mask = siamese ? `<ellipse cx="30" cy="31" rx="7.5" ry="6" fill="${dark}" opacity=".85"/>` : "";
  const chest = tux ? `<path d="M30 40 C25 46 25 58 30 64 C35 58 35 46 30 40 Z" fill="#FFFFFF"/>` : "";
  const muzzle = tux ? `<ellipse cx="30" cy="33" rx="5.5" ry="4.2" fill="#FFFFFF"/>` : "";
  return `<svg class="cat-piece" viewBox="0 0 60 80" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"${witch ? ' style="overflow:visible"' : ""}>
  ${witchClips}
  <ellipse cx="30" cy="74.5" rx="21" ry="3.6" fill="rgba(0,0,0,.22)"/>
  <ellipse cx="30" cy="69" rx="20" ry="6.5" fill="${c.base}" stroke="#2a1f18" stroke-width="1.6"/>
  <path d="M46 63 C60 62 60 44 51 40" stroke="#2a1f18" stroke-width="${fluffy ? 13 : 9.4}" stroke-linecap="round" fill="none"/><path d="M46 63 C60 62 60 44 51 40" stroke="${tail}" stroke-width="${fluffy ? 10.5 : 6.5}" stroke-linecap="round" fill="none"/>${tailFluff}${tailDots}
  ${fluffBody}
  ${scythe}
  <path d="${reaper ? "M14 68 C10 50 20 37 30 37 C40 37 50 50 46 68 Z" : "M17 67 C14 50 21 37 30 37 C39 37 46 50 43 67 Z"}" fill="${reaper ? ROBE : c.fur}" stroke="#2a1f18" stroke-width="1.6" stroke-linejoin="round"/>
  ${reaper ? `<path d="M30 42 L30 66 M22 48 L20 66 M38 48 L40 66" stroke="#0c0c12" stroke-width="1" opacity=".55" fill="none"/><path d="M14.5 66.5 Q30 70 45.5 66.5" stroke="#5a5a70" stroke-width="1.2" fill="none"/>` : ""}
  ${chest}${chestFluff}${patches}${stripes}${bodyDots}
  <ellipse cx="24" cy="66.5" rx="5" ry="3.2" fill="${paw}" stroke="#2a1f18" stroke-width="1.4"/><ellipse cx="36" cy="66.5" rx="5" ry="3.2" fill="${paw}" stroke="#2a1f18" stroke-width="1.4"/>
  ${hood}${hairSides}
  ${reaper ? "" : `<polygon points="17.5,22 18.5,5 30,14.5" fill="${earOuter}" stroke="#2a1f18" stroke-width="1.6" stroke-linejoin="round"/>`}${fluffy ? `<path d="M18.5 5 L17.5 1.5 M18.5 5 L21 2 M41.5 5 L42.5 1.5 M41.5 5 L39 2" stroke="${dark}" stroke-width="1.6" stroke-linecap="round"/>` : ""}${reaper ? "" : `<polygon points="42.5,22 41.5,5 30,14.5" fill="${earOuter}" stroke="#2a1f18" stroke-width="1.6" stroke-linejoin="round"/>
  <polygon points="21,19 21.5,9.5 27.5,15.5" fill="#F4A6B4"/><polygon points="39,19 38.5,9.5 32.5,15.5" fill="#F4A6B4"/>`}
  ${ruff}
  <circle cx="30" cy="27" r="${fluffy ? 15 : 14}" fill="${c.fur}" stroke="#2a1f18" stroke-width="1.6"/>
  ${calico ? `<ellipse cx="22.5" cy="22" rx="6.5" ry="5.5" fill="${c.furDark}"/>` : ""}
  ${headDots}${mask}${muzzle}${tabby ? `<path d="M30 15 L30 21 M25.5 16.5 L26.5 21 M34.5 16.5 L33.5 21" stroke="${dark}" stroke-width="2" stroke-linecap="round" fill="none"/>` : ""}

  <ellipse cx="24.5" cy="27" rx="2.6" ry="3" fill="${c.eye}"/><ellipse cx="35.5" cy="27" rx="2.6" ry="3" fill="${c.eye}"/>
  <ellipse cx="24.5" cy="27" rx="1.1" ry="2.4" fill="#111"/><ellipse cx="35.5" cy="27" rx="1.1" ry="2.4" fill="#111"/>
  <circle cx="25.2" cy="26" r=".8" fill="#fff"/><circle cx="36.2" cy="26" r=".8" fill="#fff"/>
  <path d="M28.2 31 L31.8 31 L30 33.2 Z" fill="#E98FA0"/>
  <path d="M30 33.2 Q28 36 25.8 34.6 M30 33.2 Q32 36 34.2 34.6" stroke="${tux || siamese ? "#444" : dark}" stroke-width=".9" fill="none" stroke-linecap="round"/>
  <path d="M20 31 L12 29.5 M20 33 L12 34 M40 31 L48 29.5 M40 33 L48 34" stroke="#2a1f18" stroke-opacity=".55" stroke-width=".7" stroke-linecap="round"/>
  ${witchHat}
</svg>`;
}

/** An element holding one cat piece, `px` pixels tall. */
export function catPiece(kind, px = 56) {
  const span = document.createElement("span");
  span.className = "cat-wrap";
  span.style.height = px + "px";
  span.style.width = Math.round(px * 0.75) + "px";
  span.innerHTML = catSVGString(kind);
  return span;
}
