// The cat playing pieces: little glossy plastic cat figures, drawn as SVG (no image files).
export const CATS = {
  tabby:   { name: "Hank", fur: "#F2993A", furDark: "#C9701F", belly: "#FFE0B5", eye: "#5BBF5B", base: "#F2993A", style: "tabby" },
  tuxedo:  { name: "Oreo",         fur: "#3A3A48", furDark: "#16161d", belly: "#FFFFFF", eye: "#E6C84A", base: "#3C3C4C", style: "tuxedo" },
  siamese: { name: "Benson",      fur: "#F1E2C6", furDark: "#5B3E33", belly: "#FFF6E4", eye: "#4EA8F0", base: "#D9C29B", style: "siamese" },
  calico:  { name: "Theo",      fur: "#FFFFFF", furDark: "#E58A2B", belly: "#FFFFFF", eye: "#D9A441", base: "#F5F1EA", style: "calico" },
  gray:    { name: "Smokey",       fur: "#8E96A6", furDark: "#626B7C", belly: "#D5D9E2", eye: "#E0B93C", base: "#8E96A6", style: "tabby" },
  fluffy:  { name: "Winnie", fur: "#9A6A43", furDark: "#6E4527", belly: "#E0BD93", eye: "#E0A93C", base: "#9A6A43", style: "fluffy" },
  black:   { name: "Shadow",       fur: "#3E3E4C", furDark: "#101015", belly: "#33333E", eye: "#F0D23C", base: "#34343F", style: "plain" },
  witch:   { name: "Penelope", fur: "#FBF8F0", furDark: "#E58A2B", belly: "#FFFFFF", eye: "#7CC47C", base: "#F3EEE4", style: "witch" },
  eagle:   { name: "Amanda", fur: "#FBF8F0", furDark: "#26262E", belly: "#FFFFFF", eye: "#4EA8F0", base: "#F3EEE4", style: "eagle" },
  reaper:  { name: "Amandaaaaaaa", fur: "#3E3E4C", furDark: "#101015", belly: "#33333E", eye: "#4EA8F0", base: "#34343F", style: "reaper" }
};
export const CAT_IDS = Object.keys(CATS);
/** Extra cats that only appear on playing cards (not in the piece pickers, so the server never needs to know them). */
export const CARD_CATS = {
  mochi:    { name: "Mochi",    fur: "#F3E3C3", furDark: "#C9A878", belly: "#FFF6E4", eye: "#7CC47C", base: "#F3E3C3", style: "tabby" },
  pepper:   { name: "Pepper",   fur: "#6B7080", furDark: "#2F3240", belly: "#FFFFFF", eye: "#E0B93C", base: "#6B7080", style: "tuxedo" },
  luna:     { name: "Luna",     fur: "#C8CCD6", furDark: "#8A90A0", belly: "#F1F3F8", eye: "#4EA8F0", base: "#C8CCD6", style: "fluffy" },
  biscuit:  { name: "Biscuit",  fur: "#C9A06A", furDark: "#8F6A3A", belly: "#F0DDBB", eye: "#6DB36D", base: "#C9A06A", style: "plain" },
  snowball: { name: "Snowball", fur: "#FFFFFF", furDark: "#CFCFD8", belly: "#FFFFFF", eye: "#4EA8F0", base: "#F5F5F8", style: "plain" },
  clover:   { name: "Clover",   fur: "#FFFFFF", furDark: "#7A8090", belly: "#FFFFFF", eye: "#D9A441", base: "#F5F1EA", style: "calico" },
  cocoa:    { name: "Cocoa",    fur: "#8A5A3C", furDark: "#5E3A22", belly: "#D9B890", eye: "#7CC47C", base: "#8A5A3C", style: "tabby" },
  ember:    { name: "Ember",    fur: "#D9622B", furDark: "#A8441A", belly: "#F6C7A0", eye: "#E6C84A", base: "#D9622B", style: "plain" },
  dusk:     { name: "Dusk",     fur: "#7A6A8C", furDark: "#3F3450", belly: "#FFFFFF", eye: "#E0B93C", base: "#7A6A8C", style: "tuxedo" },
  honey:    { name: "Honey",    fur: "#E8B84A", furDark: "#B98A22", belly: "#FFF0C8", eye: "#5BBF5B", base: "#E8B84A", style: "fluffy" }
};
export const catName = (id) => (PEOPLE_NAMES[id] || (CATS[id] ? CATS[id].name : CARD_CATS[id] ? CARD_CATS[id].name : "Cat"));

// Two chibi anime-style characters, drawn in the same flat ink style as the cats (viewBox 60 x 80).
const PINK_INK = "#2a1f18";
const pEye = (cx, iris) => `
  <ellipse cx="${cx}" cy="29.2" rx="3.5" ry="4.3" fill="#fff" stroke="${PINK_INK}" stroke-width="1"/>
  <ellipse cx="${cx}" cy="29.8" rx="2.9" ry="3.7" fill="${iris}"/>
  <ellipse cx="${cx}" cy="29.9" rx="1.5" ry="2.3" fill="#1b1620"/>
  <circle cx="${cx - 1.2}" cy="28" r="1.15" fill="#fff"/>
  <path d="M${cx - 3.9} 27.6 C${cx - 3} 24.8 ${cx + 2.4} 24.2 ${cx + 3.9} 27.2" stroke="${PINK_INK}" stroke-width="1.5" fill="none" stroke-linecap="round"/>`;
const pFace = (iris, brow) => `
  <ellipse cx="30" cy="28" rx="14.6" ry="13.8" fill="SKIN" stroke="${PINK_INK}" stroke-width="1.6"/>
  ${pEye(23.6, iris)}${pEye(36.4, iris)}
  <path d="M19.8 23.2 Q23 21.4 26.6 22.6 M33.4 22.6 Q37 21.4 40.2 23.2" stroke="${brow}" stroke-width="1" fill="none" stroke-linecap="round"/>
  <path d="M29.4 33 Q30 33.6 30.6 33" stroke="#B9806B" stroke-width=".8" fill="none" stroke-linecap="round"/>
  <path d="M25.2 35.4 Q30 41.6 34.8 35.4 Q30 36.6 25.2 35.4 Z" fill="#7C2A38" stroke="${PINK_INK}" stroke-width="1" stroke-linejoin="round"/>
  <path d="M26.4 36 Q30 38 33.6 36 L33.2 37 Q30 38.6 26.8 37 Z" fill="#fff"/>`;

// 1: younger girl. Long wavy light-brown hair with a centre part, white knit top, white shorts, pink sneakers.
const girl1 = () => {
  const SK = "#F7D3BA", H = "#C79B63", HD = "#9C7440";
  return `<svg class="cat-piece" viewBox="0 0 60 80" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <ellipse cx="30" cy="75.6" rx="17" ry="3" fill="rgba(0,0,0,.22)"/>
  <path d="M15 25 C9 34 12 41 11.5 47 C11 52 15 56 18.5 53 C17.5 56 22 57 23 51 L23 28 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M45 25 C51 34 48 41 48.5 47 C49 52 45 56 41.5 53 C42.5 56 38 57 37 51 L37 28 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <rect x="23.4" y="62" width="4.6" height="8" rx="2.2" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.4"/><rect x="32" y="62" width="4.6" height="8" rx="2.2" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.4"/>
  <rect x="23" y="68.2" width="5.4" height="3.8" rx="1.2" fill="#A3A3B0" stroke="${PINK_INK}" stroke-width="1.2"/><rect x="31.6" y="68.2" width="5.4" height="3.8" rx="1.2" fill="#A3A3B0" stroke="${PINK_INK}" stroke-width="1.2"/>
  <path d="M20.6 74.2 C20.4 71 23.4 70.8 26.4 71.2 C29 71.6 29.6 73 29.4 74.4 C26 75.4 22.6 75.4 20.6 74.2 Z" fill="#F06FA6" stroke="${PINK_INK}" stroke-width="1.3" stroke-linejoin="round"/>
  <path d="M39.4 74.2 C39.6 71 36.6 70.8 33.6 71.2 C31 71.6 30.4 73 30.6 74.4 C34 75.4 37.4 75.4 39.4 74.2 Z" fill="#F06FA6" stroke="${PINK_INK}" stroke-width="1.3" stroke-linejoin="round"/>
  <path d="M22.6 72.6 L25.4 73.4 M37.4 72.6 L34.6 73.4" stroke="#fff" stroke-width="1.1" stroke-linecap="round"/>
  <path d="M22 56.4 L38 56.4 L39.4 64.6 L31.6 64.6 L30 61.6 L28.4 64.6 L20.6 64.6 Z" fill="#fff" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M23.2 43.6 C26 42.4 34 42.4 36.8 43.6 L38.2 57.6 L21.8 57.6 Z" fill="#F7F1E4" stroke="${PINK_INK}" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M25 47 L28 50 M30 46 L33 49 M26 53 L29 56 M33 52 L36 55" stroke="#D9CFB8" stroke-width=".8" stroke-linecap="round"/>
  <path d="M22.6 44.6 C19.4 45 18.4 48.6 19.6 51 L23.4 50.6 Z" fill="#F7F1E4" stroke="${PINK_INK}" stroke-width="1.4" stroke-linejoin="round"/>
  <path d="M37.4 44.6 C40.6 45 41.6 48.6 40.4 51 L36.6 50.6 Z" fill="#F7F1E4" stroke="${PINK_INK}" stroke-width="1.4" stroke-linejoin="round"/>
  <path d="M19.6 50.6 C18 54 18.2 57.4 20 58.6 C21.6 57.6 22.4 54 23.4 50.6 Z" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.4" stroke-linejoin="round"/>
  <path d="M40.4 50.6 C42 54 41.8 57.4 40 58.6 C38.4 57.6 37.6 54 36.6 50.6 Z" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.4" stroke-linejoin="round"/>
  <rect x="27.8" y="40" width="4.4" height="4" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.2"/>
  ${pFace("#5E93DB", HD).replace("SKIN", SK)}
  <path d="M30 11.6 C21 11 14.4 17.6 15.4 29.4 C17 24.2 20 20.6 24 19 C27 18 29 16 30 12.6 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M30 11.6 C39 11 45.6 17.6 44.6 29.4 C43 24.2 40 20.6 36 19 C33 18 31 16 30 12.6 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
</svg>`;
};

// 2: older girl. Long straight layered brown hair with curtain bangs, brown zip hoodie slipping off the shoulders over an olive ribbed tank, .
const girl2 = () => {
  const SK = "#F4CDB2", H = "#8C6B49", HD = "#5E452E";
  return `<svg class="cat-piece" viewBox="0 0 60 80" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <ellipse cx="30" cy="75.6" rx="17" ry="3" fill="rgba(0,0,0,.22)"/>
  <path d="M14.6 24 C8.6 34 11 46 12 54 C12.6 58.6 17 58 19 54.6 C20 58 24 56 23.4 50 L23 28 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M45.4 24 C51.4 34 49 46 48 54 C47.4 58.6 43 58 41 54.6 C40 58 36 56 36.6 50 L37 28 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <rect x="24" y="62" width="4.4" height="8.6" rx="2.2" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.4"/><rect x="31.6" y="62" width="4.4" height="8.6" rx="2.2" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.4"/>
  <path d="M21.4 74.4 C21.2 71.4 24 71 26.8 71.4 C29 71.8 29.6 73 29.4 74.4 C26 75.4 23.4 75.4 21.4 74.4 Z" fill="#F4F1EA" stroke="${PINK_INK}" stroke-width="1.3" stroke-linejoin="round"/>
  <path d="M38.6 74.4 C38.8 71.4 36 71 33.2 71.4 C31 71.8 30.4 73 30.6 74.4 C34 75.4 36.6 75.4 38.6 74.4 Z" fill="#F4F1EA" stroke="${PINK_INK}" stroke-width="1.3" stroke-linejoin="round"/>
  <path d="M22.6 42.8 C26 41.6 34 41.6 37.4 42.8 L38.4 64 L21.6 64 Z" fill="#B7B58E" stroke="${PINK_INK}" stroke-width="1.6" stroke-linejoin="round"/>
  <path d="M24.4 47 L24.4 62 M27 46 L27 62.4 M30 46 L30 62.6 M33 46 L33 62.4 M35.6 47 L35.6 62" stroke="#9C9A74" stroke-width=".7" stroke-linecap="round" opacity=".7"/>
  <path d="M22.6 43.4 C18.6 44.2 17 49 17.4 56 L19.6 61.4 L23 61 L23.4 50 Z" fill="#5E4337" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M37.4 43.4 C41.4 44.2 43 49 42.6 56 L40.4 61.4 L37 61 L36.6 50 Z" fill="#5E4337" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M17.6 58 L23 59 M17.4 60.2 L22.6 61.2 M42.4 58 L37 59 M42.6 60.2 L37.4 61.2" stroke="#EFE3D2" stroke-width=".9" stroke-linecap="round"/>
  <circle cx="19.8" cy="61.6" r="2" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.2"/><circle cx="40.2" cy="61.6" r="2" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.2"/>
  <rect x="27.8" y="40" width="4.4" height="4" fill="${SK}" stroke="${PINK_INK}" stroke-width="1.2"/>
  ${pFace("#7699BD", HD).replace("SKIN", SK)}
  <path d="M30 11 C20.6 10.6 14 17.4 15.2 29.6 C16.4 25 18 21.4 21.6 19.4 C25 17.6 28.4 16 30 12.2 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M30 11 C39.4 10.6 46 17.4 44.8 29.6 C43.6 25 42 21.4 38.4 19.4 C35 17.6 31.6 16 30 12.2 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M30 12.6 C27.6 17.4 23.6 19.6 19.4 24.4 C18.4 26.4 17.6 28.6 17.4 31 C20 27.4 23.4 25.2 26.6 23.6 C28.6 20.8 29.6 17.2 30 12.6 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.3" stroke-linejoin="round"/>
  <path d="M30 12.6 C32.4 17.4 36.4 19.6 40.6 24.4 C41.6 26.4 42.4 28.6 42.6 31 C40 27.4 36.6 25.2 33.4 23.6 C31.4 20.8 30.4 17.2 30 12.6 Z" fill="${H}" stroke="${PINK_INK}" stroke-width="1.3" stroke-linejoin="round"/>
</svg>`;
};

const PEOPLE = { girlPenelope: girl1, girlKimberly: girl2 };
const PEOPLE_NAMES = { girlPenelope: "Penelope", girlKimberly: "Kimberly" };

let uid = 0;
/** One cat piece as an SVG element string. Taller than wide (60 x 80). */
export function catSVGString(kind) {
  if (PEOPLE[kind]) return PEOPLE[kind]();
  const c = CATS[kind] || CARD_CATS[kind] || CATS.tabby;
  const id = "cp" + (uid++);
  const dark = c.furDark;
  const siamese = c.style === "siamese", tux = c.style === "tuxedo", calico = c.style === "calico", tabby = c.style === "tabby";
  const earOuter = siamese ? dark : c.fur;
  const paw = siamese ? dark : tux ? "#FFFFFF" : c.fur;
  const tail = siamese ? dark : calico ? c.furDark : c.fur;
  const stripes = tabby ? `
    <path d="M30 15 L30 21 M25.5 16.5 L26.5 21 M34.5 16.5 L33.5 21" stroke="${dark}" stroke-width="2" stroke-linecap="round" fill="none"/>
    <path d="M19 52 Q23 50 25 54 M19 59 Q23 57 25 61 M41 52 Q37 50 35 54 M41 59 Q37 57 35 61" stroke="${dark}" stroke-width="2.2" stroke-linecap="round" fill="none"/>` : "";
  const patches = calico ? `
    <ellipse cx="22.5" cy="22" rx="6.5" ry="5.5" fill="${c.furDark}"/>
    <path d="M36 12 L41 8 L42 18 Z" fill="#2B2B33"/>
    <ellipse cx="38" cy="54" rx="6" ry="8" fill="#2B2B33"/>
    <ellipse cx="23" cy="60" rx="4.5" ry="5" fill="${c.furDark}"/>` : "";
  const fluffy = c.style === "fluffy";
  const tuft = (x, y, r, col) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${col}" stroke="#2a1f18" stroke-width="1.3"/>`;
  const fluffBody = fluffy ? [[16.5, 60, 4.6], [14.5, 52, 4.8], [16.5, 44, 4.4], [43.5, 60, 4.6], [45.5, 52, 4.8], [43.5, 44, 4.4], [20, 39.5, 4], [40, 39.5, 4]].map(([x, y, r]) => tuft(x, y, r, c.fur)).join("") : "";
  const fluffHead = fluffy ? Array.from({ length: 13 }, (_, i) => { const a = (Math.PI * (0.02 + i * 0.077)); const side = i % 2 ? 1 : -1; return null; }).join("") : "";
  const ruff = fluffy ? [[16.5, 30, 4.4], [15.5, 36, 4.2], [20, 40, 4.4], [25, 41.5, 4.2], [30, 42, 4.4], [35, 41.5, 4.2], [40, 40, 4.4], [44.5, 36, 4.2], [43.5, 30, 4.4]].map(([x, y, r]) => tuft(x, y, r, c.belly)).join("") : "";
  const chestFluff = fluffy ? `<ellipse cx="30" cy="52" rx="7.5" ry="11" fill="${c.belly}"/>${[[26, 47], [34, 48], [30, 53], [26, 58], [34, 59]].map(([x, y]) => `<path d="M${x - 2.4} ${y} Q${x} ${y + 3.4} ${x + 2.4} ${y}" stroke="${c.fur}" stroke-width="1.1" fill="none" stroke-linecap="round" opacity=".75"/>`).join("")}` : "";
  const tailFluff = fluffy ? [[55, 42, 4.2], [57.5, 48, 4.4], [56.5, 55, 4.2], [51, 60, 4.4], [49, 40, 3.8]].map(([x, y, r]) => tuft(x, y, r, c.fur)).join("") : "";
  const reaper = c.style === "reaper";
  // Grim Reaper: black hooded robe, a scythe behind her, and long straight blonde hair (a little irregular so it doesn't look drawn with a ruler)
  const ROBE = "#1d1d27", HAIR = ["#EBCB6A", "#F3DC8C", "#E3BE55", "#F7E6A6", "#DDB64D"];
  const jit = (n) => { const x = Math.sin(n * 91.7 + 3.1) * 43758.5453; return x - Math.floor(x); };
  const hairSide = (m) => {                    // hair that follows the curve of the head, then hangs in a few thin tapered tips; m = -1 left, +1 right
    const X = (dx) => (30 + m * dx).toFixed(2), j = (n) => jit(n + (m > 0 ? 7 : 0));
    const t1 = 52 + j(1) * 5, t2 = 47 + j(2) * 5, t3 = 41 + j(3) * 4;
    const body = `<path d="M${X(10)} 12.5 C${X(16.5)} 13 ${X(18.6)} 21 ${X(18.4)} 30 C${X(18.3)} 38 ${X(18.6)} 44 ${X(17.6)} ${t3.toFixed(1)} C${X(16.6)} 44 ${X(15.8)} 47 ${X(15.4)} ${t2.toFixed(1)} C${X(14.6)} 46 ${X(14)} 49 ${X(13.2)} ${t1.toFixed(1)} C${X(13)} 44 ${X(13.4)} 38 ${X(13.6)} 30 Z" fill="${HAIR[0]}" stroke="#B8923A" stroke-width=".5" stroke-linejoin="round"/>`;
    const lines = [[16.8, 36], [15.2, 38]].map(([dx, len], i) => `<path d="M${X(dx + .4)} 20 C${X(dx + 1.4)} 28 ${X(dx + .2)} ${len - 8} ${X(dx)} ${len}" stroke="#CFA441" stroke-width=".6" fill="none" stroke-linecap="round" opacity=".7"/>`).join("");
    return body + lines;
  };
  const bangs = `<path d="M30 9 C21 8.6 15.4 14 15.2 23 C17.2 19.6 20.6 18.6 23.6 19.6 C26 19 28.2 17.2 30 14.5 C31.8 17.2 34 19 36.4 19.6 C39.4 18.6 42.8 19.6 44.8 23 C44.6 14 39 8.6 30 9 Z" fill="${HAIR[1]}" stroke="#B8923A" stroke-width=".6" stroke-linejoin="round"/>` +
    [[-9, 12.5], [-6.5, 13.5], [-4, 14.2], [4, 14.2], [6.5, 13.5], [9, 12.5]].map(([dx, y0], i) => `<path d="M${30 + dx * 0.3} 10 Q${30 + dx * 0.8} ${y0} ${30 + dx} ${(19 - Math.abs(dx) * 0.15).toFixed(1)}" stroke="${i % 2 ? "#F9EBB5" : "#CFA441"}" stroke-width=".7" fill="none" stroke-linecap="round" opacity=".7"/>`).join("");
  const scythe = reaper ? `<path d="M52.5 73 L53.2 13" stroke="#6b4a2b" stroke-width="2.2" stroke-linecap="round"/><path d="M53.5 13.5 C49 5.5 41 6.5 36.5 11.5 C43 9.8 49 12 53.5 20 Z" fill="#CBD0D8" stroke="#555a66" stroke-width=".9" stroke-linejoin="round"/>` : "";
  const hood = reaper ? `<path d="M10.5 36 C7 17 19 5 30 3.2 C41 5 53 17 49.5 36 C47 45 13 45 10.5 36 Z" fill="${ROBE}" stroke="#0c0c12" stroke-width=".9"/>` : "";
  const eagle = c.style === "eagle";
  const hairSides = eagle ? hairSide(-1) + hairSide(1) : "";
  const bow = reaper ? `<path d="M39 12 L44.6 9.2 L44.2 15.4 Z M39 12 L34.2 9 L34.6 15 Z" fill="#E98FB0" stroke="#A5546F" stroke-width=".7" stroke-linejoin="round"/><circle cx="39" cy="12" r="1.6" fill="#F4B6CB" stroke="#A5546F" stroke-width=".7"/>` : "";
  const witch = c.style === "witch", dotted = witch || eagle;
  // Dottie: white with orange polka dots, in a black witch hat with a tiny Benson (the Siamese) on it
  const bodyClip = `${id}bc`, headClip = `${id}hc`;
  const dot = (x, y, r) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${witch ? "#E58A2B" : "#1d1d27"}"/>`;
  const witchClips = dotted ? `<defs><clipPath id="${bodyClip}"><path d="M17 67 C14 50 21 37 30 37 C39 37 46 50 43 67 Z"/></clipPath><clipPath id="${headClip}"><circle cx="30" cy="27" r="14"/></clipPath></defs>` : "";
  const bodyDots = dotted ? `<g clip-path="url(#${bodyClip})">${[[24, 44.5, 2.8], [35.5, 42.5, 2.3], [29.5, 51, 3], [21.5, 57, 2.4], [38.5, 56, 2.8], [29, 62.5, 2.5], [44, 47, 2.2]].map(d => dot(...d)).join("")}</g>` : "";
  const headDots = dotted ? `<g clip-path="url(#${headClip})">${[[20.5, 23.5, 2.9], [39, 22, 2.5], [34.5, 33, 2], [22, 33, 1.9], [30, 17, 2]].map(d => dot(...d)).join("")}</g>` : "";
  const tailDots = dotted ? [[56.4, 57.5, 1.7], [57.2, 50, 1.6], [53.8, 42.6, 1.5]].map(d => dot(...d)).join("") : "";
  const witchHat = witch ? `<ellipse cx="30" cy="16" rx="17.5" ry="4.4" transform="rotate(-4 30 16)" fill="#2e2638" stroke="#2a1f18" stroke-width="1.5"/>
    <path d="M21 15.5 C23 8 26 2 31 -3 C34 -6 37 -7.2 40.5 -6 C36.5 -4 36 0 36.6 4 C37.1 8 38 12 39 15.5 Z" fill="#2e2638" stroke="#2a1f18" stroke-width="1.5" stroke-linejoin="round"/>
    <path d="M21.9 11.6 C27 12.6 33 12.6 38.1 11.6 L38.7 15.2 C33 16.3 27 16.3 21.3 15.2 Z" fill="#E58A2B" stroke="#2a1f18" stroke-width="1"/>
    <path d="M26.7 3.8 L27.5 0.2 L30.2 2.3 M34.3 3.8 L33.5 0.2 L31 2.3" fill="#5B3E33" stroke="#2a1f18" stroke-width=".7" stroke-linejoin="round"/>
    <circle cx="30.5" cy="6.4" r="4.3" fill="#F1E2C6" stroke="#2a1f18" stroke-width=".8"/><ellipse cx="30.5" cy="7.7" rx="2.4" ry="2" fill="#5B3E33" opacity=".85"/><circle cx="29.2" cy="6.1" r=".65" fill="#4EA8F0"/><circle cx="31.8" cy="6.1" r=".65" fill="#4EA8F0"/>` : "";
  const cap = eagle ? `<path d="M16 19.5 C15.5 8 22.5 3.2 30 3.2 C37.5 3.2 44.5 8 44 19.5 Z" fill="#1F7A4D" stroke="#2a1f18" stroke-width="1.5" stroke-linejoin="round"/>
    <path d="M30 3.4 C27 8 26.5 14 27.5 19.5 M30 3.4 C33 8 33.5 14 32.5 19.5" stroke="#16603B" stroke-width=".9" fill="none"/>
    <ellipse cx="30" cy="20.2" rx="14.5" ry="3.7" fill="#16603B" stroke="#2a1f18" stroke-width="1.5"/>
    <circle cx="30" cy="3.4" r="1.3" fill="#16603B" stroke="#2a1f18" stroke-width=".8"/>
    <circle cx="30" cy="12.6" r="4.3" fill="#F6F1E4" stroke="#2a1f18" stroke-width=".7"/>
    <path d="M30 9.6 C30.9 9.6 31.3 10.4 31.2 11.2 C33 10.2 35 10.4 36.2 11.6 C34.4 11.5 32.8 12.1 31.4 13.1 L31.8 15.2 L30 14.4 L28.2 15.2 L28.6 13.1 C27.2 12.1 25.6 11.5 23.8 11.6 C25 10.4 27 10.2 28.8 11.2 C28.7 10.4 29.1 9.6 30 9.6 Z" fill="#16603B" stroke="#16603B" stroke-width=".4" stroke-linejoin="round"/>
    <path d="M17.2 19.2 C21 23.6 39 23.6 42.8 19.2" fill="none" stroke="#2a1f18" stroke-width="1.2"/>` : "";
  const mask = siamese ? `<ellipse cx="30" cy="31" rx="7.5" ry="6" fill="${dark}" opacity=".85"/>` : "";
  const chest = tux ? `<path d="M30 40 C25 46 25 58 30 64 C35 58 35 46 30 40 Z" fill="#FFFFFF"/>` : "";
  const muzzle = tux ? `<ellipse cx="30" cy="33" rx="5.5" ry="4.2" fill="#FFFFFF"/>` : "";
  return `<svg class="cat-piece" viewBox="0 0 60 80" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"${witch ? ' style="overflow:visible"' : ""}>
  ${witchClips}
  <ellipse cx="30" cy="74.5" rx="21" ry="3.6" fill="rgba(0,0,0,.22)"/>
  <ellipse cx="30" cy="69" rx="20" ry="6.5" fill="${c.base}" stroke="#2a1f18" stroke-width="1.6"/>
  <path d="M46 63 C60 62 60 44 51 40" stroke="#2a1f18" stroke-width="${fluffy ? 13 : 9.4}" stroke-linecap="round" fill="none"/><path d="M46 63 C60 62 60 44 51 40" stroke="${tail}" stroke-width="${fluffy ? 10.5 : 6.5}" stroke-linecap="round" fill="none"/>${tailFluff}${tailDots}
  ${fluffBody}
  ${scythe}
  <path d="${reaper ? "M14 68 C10 50 20 37 30 37 C40 37 50 50 46 68 Z" : "M17 67 C14 50 21 37 30 37 C39 37 46 50 43 67 Z"}" fill="${reaper ? ROBE : c.fur}" stroke="#2a1f18" stroke-width="1.6" stroke-linejoin="round"/>
  ${reaper ? `<path d="M30 42 L30 66 M22 48 L20 66 M38 48 L40 66" stroke="#0c0c12" stroke-width="1" opacity=".55" fill="none"/><path d="M14.5 66.5 Q30 70 45.5 66.5" stroke="#5a5a70" stroke-width="1.2" fill="none"/>` : ""}
  ${chest}${chestFluff}${patches}${stripes}${bodyDots}
  <ellipse cx="24" cy="66.5" rx="5" ry="3.2" fill="${paw}" stroke="#2a1f18" stroke-width="1.4"/><ellipse cx="36" cy="66.5" rx="5" ry="3.2" fill="${paw}" stroke="#2a1f18" stroke-width="1.4"/>
  ${hood}${hairSides}
  ${reaper || eagle ? "" : `<polygon points="17.5,22 18.5,5 30,14.5" fill="${earOuter}" stroke="#2a1f18" stroke-width="1.6" stroke-linejoin="round"/>`}${fluffy ? `<path d="M18.5 5 L17.5 1.5 M18.5 5 L21 2 M41.5 5 L42.5 1.5 M41.5 5 L39 2" stroke="${dark}" stroke-width="1.6" stroke-linecap="round"/>` : ""}${reaper || eagle ? "" : `<polygon points="42.5,22 41.5,5 30,14.5" fill="${earOuter}" stroke="#2a1f18" stroke-width="1.6" stroke-linejoin="round"/>
  <polygon points="21,19 21.5,9.5 27.5,15.5" fill="#F4A6B4"/><polygon points="39,19 38.5,9.5 32.5,15.5" fill="#F4A6B4"/>`}
  ${ruff}
  <circle cx="30" cy="27" r="${fluffy ? 15 : 14}" fill="${c.fur}" stroke="#2a1f18" stroke-width="1.6"/>
  ${calico ? `<ellipse cx="22.5" cy="22" rx="6.5" ry="5.5" fill="${c.furDark}"/>` : ""}
  ${headDots}${mask}${muzzle}${tabby ? `<path d="M30 15 L30 21 M25.5 16.5 L26.5 21 M34.5 16.5 L33.5 21" stroke="${dark}" stroke-width="2" stroke-linecap="round" fill="none"/>` : ""}

  <ellipse cx="24.5" cy="27" rx="2.6" ry="3" fill="${c.eye}"/><ellipse cx="35.5" cy="27" rx="2.6" ry="3" fill="${c.eye}"/>
  <ellipse cx="24.5" cy="27" rx="1.1" ry="2.4" fill="#111"/><ellipse cx="35.5" cy="27" rx="1.1" ry="2.4" fill="#111"/>
  <circle cx="25.2" cy="26" r=".8" fill="#fff"/><circle cx="36.2" cy="26" r=".8" fill="#fff"/>
  <path d="M28.2 31 L31.8 31 L30 33.2 Z" fill="#E98FA0"/>
  <path d="M30 33.2 Q28 36 25.8 34.6 M30 33.2 Q32 36 34.2 34.6" stroke="${tux || siamese ? "#444" : dark}" stroke-width=".9" fill="none" stroke-linecap="round"/>
  <path d="M20 31 L12 29.5 M20 33 L12 34 M40 31 L48 29.5 M40 33 L48 34" stroke="#2a1f18" stroke-opacity=".55" stroke-width=".7" stroke-linecap="round"/>
  ${witchHat}${cap}
</svg>`;
}

/** An element holding one cat piece, `px` pixels tall. */
export function catPiece(kind, px = 56) {
  const span = document.createElement("span");
  span.className = "cat-wrap";
  span.style.height = px + "px";
  span.style.width = Math.round(px * 0.75) + "px";
  span.innerHTML = catSVGString(kind);
  return span;
}
