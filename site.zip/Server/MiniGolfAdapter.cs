using System.Text.Json;
using LanternLounge.Core;
using LanternLounge.Games.MiniGolf;

namespace LanternLounge.Server;

// Mini Golf online: everybody plays at once on the server's clock, and balls bump each other.
// (Test version: only two holes are played; see MiniGolfRules.HolesPerCourse.)
public sealed class MiniGolfAdapter : GameAdapter
{
    private readonly MiniGolfModule module = new MiniGolfModule();
    public override string GameId => MiniGolfModule.GameId;
    public override IGameModule Module => module;

    /// <summary>Four seats; bots fill empty ones. The host may turn the bots off down to two players.</summary>
    public override int Seats => MiniGolfRules.MaxPlayers;

    /// <summary>A rematch moves on to the next course; the first game picks one from the seed.</summary>
    public override MatchConfig Config(ulong seed, object previousState) => Config(seed, previousState, Seats);

    public override MatchConfig Config(ulong seed, object previousState, int players)
    {
        var options = new Dictionary<string, string>();
        if (previousState is MiniGolfState previous)
            options["course"] = ((previous.Course + 1) % MiniGolfCourses.All.Length).ToString();
        return new MatchConfig(players, seed, options);
    }

    /// <summary>Real time: the server's clock gathers everyone's controls ten times a second.</summary>
    public override bool IsRealtime => true;

    /// <summary>Each player picks a ball color and a hat as "color:hat" (duplicates allowed).</summary>
    public override bool FreeChoice => true;
    public override bool IsValidChoice(string choice)
    {
        if (string.IsNullOrEmpty(choice)) return false;
        var parts = choice.Split(':');
        return parts.Length == 2 && Array.IndexOf(BallColors, parts[0]) >= 0 && Array.IndexOf(Hats, parts[1]) >= 0;
    }
    public override string DefaultChoice(int seatIndex) => BallColors[(seatIndex * 3) % BallColors.Length] + ":none";
    private static readonly string[] BallColors = { "red", "orange", "yellow", "lime", "green", "teal", "sky", "blue", "purple", "pink", "white", "black" };
    private static readonly string[] Hats = { "none", "tophat", "party", "cap", "crown", "cowboy", "wizard", "propeller", "chef", "pirate", "halo" };
    public override int TickMs => MiniGolfModule.TickMs;

    /// <summary>Move: { "kind": "shoot", "seq": number (higher than the last one), "angle": radians, "power": 0..1 } or { "kind": "next", "seq": number }</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        switch (GetString(move, "kind"))
        {
            case "next":
                if (!TryGetInt(move, "seq", out int nextSeq)) { error = "A next needs a seq."; return false; }
                action = new GolfInput(nextSeq, 0, 0, true);
                return true;
            case "shoot":
                if (!TryGetInt(move, "seq", out int seq) ||
                    !move.TryGetProperty("angle", out var angle) || angle.ValueKind != JsonValueKind.Number ||
                    !move.TryGetProperty("power", out var power) || power.ValueKind != JsonValueKind.Number)
                {
                    error = "A shot needs a seq, an angle and a power.";
                    return false;
                }
                action = new GolfInput(seq, angle.GetDouble(), power.GetDouble(), false);
                return true;
            default:
                error = "A Mini Golf move is shoot or next.";
                return false;
        }
    }

    public override object MakeTick(object[] inputs, int dtMs)
    {
        var list = new GolfInput[Seats];
        for (int i = 0; i < list.Length && i < inputs.Length; i++) list[i] = inputs[i] as GolfInput;
        return new MiniGolfTick(dtMs, list);
    }

    public override object ViewFor(object state, int seat) => module.ViewFor((MiniGolfState)state, seat);

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(seat, seed);

    private sealed class Bot : BotPlayer
    {
        private readonly int seat;
        private readonly SeededRandom random;
        private readonly double skill;
        private int readyAt = -1;     // game time (ms) when this bot takes its next shot
        private int seq;
        private GolfInput last;

        public Bot(int seat, ulong seed)
        {
            this.seat = seat;
            random = new SeededRandom(seed);
            skill = 2.6 + 0.3 * seat;   // each bot misses a little differently
        }

        /// <summary>A bot's "move" is its controls for the next tick: the same shot again while it waits, a new one when its ball is ready.</summary>
        public override object ChooseMove(object state)
        {
            var s = (MiniGolfState)state;
            var b = s.Balls[seat];
            if (s.Phase != GolfPhase.Play || b.Mode != BallMode.Rest) { readyAt = -1; return last; }
            if (seq < b.LastSeq) seq = b.LastSeq;
            if (readyAt < 0) readyAt = s.TimeMs + 700 + seat * 350 + ((s.TickId * 37 + seat * 11) % 9) * 140;
            if (s.TimeMs < readyAt) return last;
            MiniGolfBot.Plan(s.CurrentHole, b.X, b.Y, random, skill, out double angle, out double power);
            readyAt = -1;
            last = new GolfInput(++seq, angle, power, false);
            return last;
        }
    }
}
