using System.Text.Json;
using LanternLounge.Core;
using LanternLounge.Games.CatsAndLadders;

namespace LanternLounge.Server;

// Cats and Ladders online. (Goes next to GameAdapters.cs. Not hooked into GameCatalog yet.)
public sealed class CatsAndLaddersAdapter : GameAdapter
{
    private readonly CatsAndLaddersModule module = new CatsAndLaddersModule();
    public override string GameId => CatsAndLaddersModule.GameId;
    public override IGameModule Module => module;
    public override int MinPlayers => Seats;

    /// <summary>The cat pieces to choose from in the waiting room (four players, seven cats, nobody shares).</summary>
    public override IReadOnlyList<string> Choices { get; } = new[] { "tabby", "tuxedo", "siamese", "calico", "gray", "fluffy", "black", "reaper", "witch", "eagle" };

    /// <summary>Move: { "kind": "roll" } on your turn, or { "kind": "react", "emoji": "smile" | "sad" | "angry" | "kiss" | "peace" } once your turn is over.</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        switch (GetString(move, "kind"))
        {
            case "roll":
                action = CatsAction.Roll;
                return true;
            case "react":
                int reaction = Array.IndexOf(Reactions, GetString(move, "emoji"));
                if (reaction < 1) { error = "A reaction is smile, sad, angry, kiss or peace."; return false; }
                action = new CatsAction(reaction);
                return true;
            default:
                error = "A Cats and Ladders move is roll or react.";
                return false;
        }
    }

    private static readonly string[] Reactions = { "", "smile", "sad", "angry", "kiss", "peace" };

    public override object ViewFor(object state, int seat)
    {
        var s = (CatsAndLaddersState)state;
        return new
        {
            positions = s.Positions,
            currentSeat = s.CurrentSeat,
            rolls = s.Rolls,
            winner = s.Winner,
            last = s.LastSeat < 0 ? null : new
            {
                seat = s.LastSeat,
                die = s.Last.Die,
                from = s.Last.From,
                landed = s.Last.Landed,
                to = s.Last.To,
                kind = s.Last.Kind.ToString().ToLowerInvariant()
            },
            moods = Array.ConvertAll(s.Moods, m => Reactions[m]),
            moodNos = s.MoodNos,
            ladders = CatsAndLaddersRules.Ladders,
            chutes = CatsAndLaddersRules.Chutes
        };
    }

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot();

    /// <summary>A bot's only decision is to roll the die.</summary>
    private sealed class Bot : BotPlayer
    {
        public override object ChooseMove(object state) => CatsAction.Roll;
    }
}
