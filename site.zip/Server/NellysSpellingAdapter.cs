using System.Linq;
using System.Text.Json;
using LanternLounge.Core;
using LanternLounge.Games.NellysSpelling;

namespace LanternLounge.Server;

// Nelly's Spelling online. One person spells (seat 0, whoever opens the room); anyone else who joins watches.
// (Goes next to GameAdapters.cs. Not hooked into GameCatalog yet.)
public sealed class NellysSpellingAdapter : GameAdapter
{
    private readonly SpellingModule module = new SpellingModule();
    public override string GameId => SpellingModule.GameId;
    public override IGameModule Module => module;
    public override int MinPlayers => 1;

    /// <summary>
    /// Move: { "kind": "ready" | "define" | "sentence" | "back" | "enter" | "next" } or { "kind": "letter", "ch": "a" }.
    /// </summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        switch (GetString(move, "kind"))
        {
            case "ready": action = SpellingAction.Of(SpellingKind.Ready); return true;
            case "define": action = SpellingAction.Of(SpellingKind.Define); return true;
            case "sentence": action = SpellingAction.Of(SpellingKind.Sentence); return true;
            case "back": action = SpellingAction.Of(SpellingKind.Back); return true;
            case "enter": action = SpellingAction.Of(SpellingKind.Enter); return true;
            case "next": action = SpellingAction.Of(SpellingKind.Next); return true;
            case "letter":
                string ch = GetString(move, "ch");
                if (ch == null || ch.Length != 1 || char.ToLowerInvariant(ch[0]) < 'a' || char.ToLowerInvariant(ch[0]) > 'z')
                {
                    error = "A letter is a single letter from a to z.";
                    return false;
                }
                action = SpellingAction.Type(char.ToLowerInvariant(ch[0]));
                return true;
            default:
                error = "A spelling move is ready, define, letter, back, enter or next.";
                return false;
        }
    }

    private static readonly string[] Phases = { "define", "spell", "result", "done" };

    /// <summary>Everyone sees the same thing. The word itself is only sent once the word is finished.</summary>
    public override object ViewFor(object state, int seat)
    {
        var s = (SpellingState)state;
        bool done = s.Phase == SpellingPhase.Done;
        bool showWord = s.Phase == SpellingPhase.Result;
        var word = done ? default(SpellingWord) : s.Word;
        return new
        {
            phase = Phases[(int)s.Phase],
            showDef = s.ShowDef,
            panel = s.ShowSentence ? "sentence" : "definition",
            sentence = done ? null : word.Sentence,
            index = s.Index,
            total = SpellingRules.Words.Length,
            length = done ? 0 : word.Letters.Length,
            gap = done ? -1 : word.GapAfter,
            definition = done ? null : word.Definition,
            rows = s.Rows,
            marks = done ? new string[0] : s.Rows.Select(r => SpellingRules.Mark(word.Letters, r)).ToArray(),
            current = s.Current,
            maxTries = SpellingRules.MaxTries,
            outcome = s.Outcome == 1 ? "correct" : s.Outcome == 2 ? "missed" : "none",
            word = showWord ? word.Word : null,
            correct = s.Correct,
            events = s.Events,
            summary = done ? s.Order.Select((o, i) => new { word = SpellingRules.Words[o].Word, ok = s.Results[i] == 1 }).ToArray() : null
        };
    }

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot();

    /// <summary>Only used if the speller's seat is ever taken over by a bot: it just spells every word right.</summary>
    private sealed class Bot : BotPlayer
    {
        public override object ChooseMove(object state)
        {
            var s = (SpellingState)state;
            switch (s.Phase)
            {
                case SpellingPhase.Define: return SpellingAction.Of(SpellingKind.Ready);
                case SpellingPhase.Result: return SpellingAction.Of(SpellingKind.Next);
                default:
                    if (s.ShowDef) return SpellingAction.Of(SpellingKind.Ready);
                    string target = s.Word.Letters;
                    return s.Current.Length < target.Length ? SpellingAction.Type(target[s.Current.Length]) : SpellingAction.Of(SpellingKind.Enter);
            }
        }
    }
}
