using System.Linq;
using System.Text.Json;
using LanternLounge.Core;
using LanternLounge.Games.Trouble;

namespace LanternLounge.Server;

// Trouble online. (Goes next to GameAdapters.cs. Not hooked into GameCatalog yet.)
public sealed class TroubleAdapter : GameAdapter
{
    private readonly TroubleModule module = new TroubleModule();
    public override string GameId => TroubleModule.GameId;
    public override IGameModule Module => module;
    public override int MinPlayers => Seats;

    /// <summary>The cats to choose from in the waiting room (four players, eight cats, nobody shares). Each player's four pieces are their cat.</summary>
    public override IReadOnlyList<string> Choices { get; } = new[] { "tabby", "tuxedo", "siamese", "calico", "gray", "fluffy", "black", "reaper", "witch" };

    /// <summary>Move: { "kind": "roll" } to roll the die, then { "kind": "move", "peg": 0..3 } to move one of your pegs.</summary>
    public override bool TryParseMove(JsonElement move, out object action, out string error)
    {
        action = null;
        error = null;
        switch (GetString(move, "kind"))
        {
            case "roll":
                action = TroubleAction.Roll;
                return true;
            case "move":
                if (!TryGetInt(move, "peg", out int peg) || peg < 0 || peg >= TroubleRules.PegsEach)
                {
                    error = "Pick one of your four cats.";
                    return false;
                }
                action = TroubleAction.Move(peg);
                return true;
            default:
                error = "A Trouble move is roll or move.";
                return false;
        }
    }

    private static readonly string[] Kinds = { "none", "roll", "move", "rollmove" };

    public override object ViewFor(object state, int seat)
    {
        var s = (TroubleState)state;
        var e = s.Last;
        return new
        {
            pegs = s.Pegs,
            currentSeat = s.CurrentSeat,
            pending = s.Pending,
            tries = s.Tries,
            rolls = s.Rolls,
            actions = s.Actions,
            winner = s.Winner,
            legal = s.Pending > 0 && !s.IsOver ? TroubleRules.LegalPegs(s.Pegs, s.CurrentSeat, s.Pending).ToArray() : new int[0],
            last = e.Kind == TroubleKind.None ? null : new
            {
                kind = Kinds[(int)e.Kind],
                seat = e.Seat,
                die = e.Die,
                peg = e.Peg,
                from = e.From,
                to = e.To,
                capSeat = e.CapSeat,
                capPeg = e.CapPeg,
                capFrom = e.CapFrom
            }
        };
    }

    public override BotPlayer CreateBot(int seat, ulong seed) => new Bot(seat);

    /// <summary>A bot rolls, then moves the peg the shared "sensible player" rule picks.</summary>
    private sealed class Bot : BotPlayer
    {
        private readonly int seat;
        public Bot(int seat) { this.seat = seat; }

        public override object ChooseMove(object state)
        {
            var s = (TroubleState)state;
            if (s.Pending == 0) return TroubleAction.Roll;
            return TroubleAction.Move(TroubleRules.PickPeg(s.Pegs, seat, s.Pending));
        }
    }
}
