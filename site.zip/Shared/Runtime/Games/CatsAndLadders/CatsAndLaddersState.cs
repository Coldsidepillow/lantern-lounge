using System;

namespace LanternLounge.Games.CatsAndLadders
{
    /// <summary>Everyone's square, whose turn it is, and what the last roll did. Nothing is hidden.</summary>
    public sealed class CatsAndLaddersState
    {
        public const int NoSeat = -1;

        internal CatsAndLaddersState(int[] positions, ulong seed, int currentSeat, int rolls, int winner, int lastSeat, Move last, int[] moods = null, int[] moodNos = null)
        {
            Moods = moods ?? new int[CatsAndLaddersRules.Players];
            MoodNos = moodNos ?? new int[CatsAndLaddersRules.Players];
            Positions = positions;
            Seed = seed;
            CurrentSeat = currentSeat;
            Rolls = rolls;
            Winner = winner;
            LastSeat = lastSeat;
            Last = last;
        }

        internal static CatsAndLaddersState CreateNew(ulong seed, int firstSeat) =>
            new CatsAndLaddersState(new int[CatsAndLaddersRules.Players], seed, firstSeat, 0, NoSeat, NoSeat, default);

        public int[] Positions { get; }

        /// <summary>Each seat's latest reaction (0 none, 1 smile, 2 sad, 3 angry, 4 kiss, 5 peace) and how many reactions that seat has made, so screens can tell a new one.</summary>
        public int[] Moods { get; }
        public int[] MoodNos { get; }
        public ulong Seed { get; }
        public int CurrentSeat { get; }
        /// <summary>How many rolls have been made so far.</summary>
        public int Rolls { get; }
        public int Winner { get; }
        public bool IsOver => Winner != NoSeat;
        /// <summary>Who made the last roll (NoSeat before the first one), and what it did.</summary>
        public int LastSeat { get; }
        public Move Last { get; }

        public int[] CopyPositions() => (int[])Positions.Clone();
    }
}
