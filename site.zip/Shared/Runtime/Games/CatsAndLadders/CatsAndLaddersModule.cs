using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.CatsAndLadders
{
    /// <summary>
    /// What a player can do: roll the die on their turn (the server rolls it, so nobody can cheat), or send a little
    /// reaction (1 smile, 2 sad, 3 angry, 4 kiss, 5 peace) once their own turn is over.
    /// </summary>
    public readonly struct CatsAction
    {
        public CatsAction(int reaction) { Reaction = reaction; }
        /// <summary>0 means roll the die.</summary>
        public int Reaction { get; }
        public bool IsRoll => Reaction == 0;
        public static CatsAction Roll => new CatsAction(0);
    }

    /// <summary>
    /// Cats and Ladders: one to five players race their cat pieces from square 1 to square 100. Roll the die and move that many
    /// squares. A ladder carries you up, a chute slides you down. You need the exact number to land on 100.
    /// Options: "firstSeat" = "0".."4", or "random" (default). The match has config.PlayerCount players (1 to 5).
    /// </summary>
    public sealed class CatsAndLaddersModule : GameModule<CatsAndLaddersState, CatsAction, CatsAndLaddersState>
    {
        public const string GameId = "cats-and-ladders";

        public static readonly GameInfo Definition =
            new GameInfo(GameId, "Cats and Ladders", 1, CatsAndLaddersRules.MaxPlayers, GameStatus.Playable, "cats-and-ladders");

        private static readonly IReadOnlyList<int> NoSeats = Array.Empty<int>();

        public override GameInfo Info => Definition;

        protected override CatsAndLaddersState CreateInitialState(MatchConfig config)
        {
            var random = new SeededRandom(config.Seed);
            string first = config.GetOption("firstSeat", "random");
            int players = Math.Max(1, Math.Min(CatsAndLaddersRules.MaxPlayers, config.PlayerCount));
            if (!int.TryParse(first, out int seat) || seat < 0 || seat >= players)
                seat = random.NextInt(players);
            return CatsAndLaddersState.CreateNew(config.Seed, players, seat);
        }

        public override ValidationResult Validate(CatsAndLaddersState state, int seat, CatsAction action)
        {
            if (state == null) return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no board.");
            if (state.IsOver) return ValidationResult.Fail(ErrorCodes.GameOver, "This game is already over.");
            if (seat < 0 || seat >= state.Players) return ValidationResult.Fail(ErrorCodes.BadSeat, "That seat isn't playing.");
            if (!action.IsRoll)
            {
                if (action.Reaction < 1 || action.Reaction > 5) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Pick smile, sad, angry, kiss or peace.");
                if (seat == state.CurrentSeat) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Roll first, then react.");   // reactions never hold up your own turn
                return ValidationResult.Success;
            }
            if (seat != state.CurrentSeat) return ValidationResult.Fail(ErrorCodes.NotYourTurn, "It isn't your turn yet.");
            return ValidationResult.Success;
        }

        protected override CatsAndLaddersState ApplyValidated(CatsAndLaddersState state, int seat, CatsAction action)
        {
            if (!action.IsRoll)
            {
                int[] moods = (int[])state.Moods.Clone(), moodNos = (int[])state.MoodNos.Clone();
                moods[seat] = action.Reaction;
                moodNos[seat]++;
                return new CatsAndLaddersState(state.Positions, state.Seed, state.CurrentSeat, state.Rolls, state.Winner, state.LastSeat, state.Last, moods, moodNos);
            }
            int rollNo = state.Rolls + 1;
            var move = CatsAndLaddersRules.Step(state.Positions[seat], CatsAndLaddersRules.Die(state.Seed, rollNo));
            int[] positions = state.CopyPositions();
            positions[seat] = move.To;
            bool won = move.To == CatsAndLaddersRules.Last;
            int next = won ? CatsAndLaddersState.NoSeat : (seat + 1) % state.Players;
            return new CatsAndLaddersState(positions, state.Seed, next, rollNo, won ? seat : CatsAndLaddersState.NoSeat, seat, move, state.Moods, state.MoodNos);
        }

        public override CatsAndLaddersState ViewFor(CatsAndLaddersState state, int seat) => state;

        public override MatchResult Result(CatsAndLaddersState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? MatchResult.Win(state.Winner) : MatchResult.InProgress;
        }

        public override IReadOnlyList<int> SeatsToAct(CatsAndLaddersState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? NoSeats : new[] { state.CurrentSeat };
        }

        /// <summary>If someone walks away from the table, the die just gets rolled for them.</summary>
        public override bool TryGetTimeoutAction(CatsAndLaddersState state, int seat, out CatsAction action)
        {
            action = default;
            if (state == null || state.IsOver || seat != state.CurrentSeat) return false;
            action = CatsAction.Roll;
            return true;
        }
    }
}
