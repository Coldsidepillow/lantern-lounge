using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.CatsAndLadders
{
    /// <summary>
    /// What a player can do: roll the die on their turn (the server rolls it, so nobody can cheat), or send a little
    /// reaction (1 smile, 2 sad, 3 angry, 4 kiss) once their own turn is over.
    /// </summary>
    public readonly struct CatsAction
    {
        public CatsAction(int reaction) { Reaction = reaction; }
        /// <summary>0 means roll the die.</summary>
        public int Reaction { get; }
        public bool IsRoll => Reaction == 0;
        public static CatsAction Roll => new CatsAction(0);
    }

    /// <summary>
    /// Cats and Ladders: four players race four cat pieces from square 1 to square 100. Roll the die and move that many
    /// squares. A ladder carries you up, a chute slides you down. You need the exact number to land on 100.
    /// Options: "firstSeat" = "0".."3", or "random" (default).
    /// </summary>
    public sealed class CatsAndLaddersModule : GameModule<CatsAndLaddersState, CatsAction, CatsAndLaddersState>
    {
        public const string GameId = "cats-and-ladders";

        public static readonly GameInfo Definition =
            new GameInfo(GameId, "Cats and Ladders", CatsAndLaddersRules.Players, CatsAndLaddersRules.Players, GameStatus.Playable, "cats-and-ladders");

        private static readonly IReadOnlyList<int> NoSeats = Array.Empty<int>();

        public override GameInfo Info => Definition;

        protected override CatsAndLaddersState CreateInitialState(MatchConfig config)
        {
            var random = new SeededRandom(config.Seed);
            string first = config.GetOption("firstSeat", "random");
            if (!int.TryParse(first, out int seat) || seat < 0 || seat >= CatsAndLaddersRules.Players)
                seat = random.NextInt(CatsAndLaddersRules.Players);
            return CatsAndLaddersState.CreateNew(config.Seed, seat);
        }

        public override ValidationResult Validate(CatsAndLaddersState state, int seat, CatsAction action)
        {
            if (state == null) return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no board.");
            if (state.IsOver) return ValidationResult.Fail(ErrorCodes.GameOver, "This game is already over.");
            if (seat < 0 || seat >= CatsAndLaddersRules.Players) return ValidationResult.Fail(ErrorCodes.BadSeat, "Cats and Ladders has seats 0 to 3 only.");
            if (!action.IsRoll)
            {
                if (action.Reaction < 1 || action.Reaction > 4) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Pick smile, sad, angry or kiss.");
                if (seat == state.CurrentSeat) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Roll first, then react.");   // reactions never hold up your own turn
                return ValidationResult.Success;
            }
            if (seat != state.CurrentSeat) return ValidationResult.Fail(ErrorCodes.NotYourTurn, "It isn't your turn yet.");
            return ValidationResult.Success;
        }

        protected override CatsAndLaddersState ApplyValidated(CatsAndLaddersState state, int seat, CatsAction action)
        {
            if (!action.IsRoll)
            {
                int[] moods = (int[])state.Moods.Clone(), moodNos = (int[])state.MoodNos.Clone();
                moods[seat] = action.Reaction;
                moodNos[seat]++;
                return new CatsAndLaddersState(state.Positions, state.Seed, state.CurrentSeat, state.Rolls, state.Winner, state.LastSeat, state.Last, moods, moodNos);
            }
            int rollNo = state.Rolls + 1;
            var move = CatsAndLaddersRules.Step(state.Positions[seat], CatsAndLaddersRules.Die(state.Seed, rollNo));
            int[] positions = state.CopyPositions();
            positions[seat] = move.To;
            bool won = move.To == CatsAndLaddersRules.Last;
            int next = won ? CatsAndLaddersState.NoSeat : (seat + 1) % CatsAndLaddersRules.Players;
            return new CatsAndLaddersState(positions, state.Seed, next, rollNo, won ? seat : CatsAndLaddersState.NoSeat, seat, move, state.Moods, state.MoodNos);
        }

        public override CatsAndLaddersState ViewFor(CatsAndLaddersState state, int seat) => state;

        public override MatchResult Result(CatsAndLaddersState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? MatchResult.Win(state.Winner) : MatchResult.InProgress;
        }

        public override IReadOnlyList<int> SeatsToAct(CatsAndLaddersState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? NoSeats : new[] { state.CurrentSeat };
        }

        /// <summary>If someone walks away from the table, the die just gets rolled for them.</summary>
        public override bool TryGetTimeoutAction(CatsAndLaddersState state, int seat, out CatsAction action)
        {
            action = default;
            if (state == null || state.IsOver || seat != state.CurrentSeat) return false;
            action = CatsAction.Roll;
            return true;
        }
    }
}
