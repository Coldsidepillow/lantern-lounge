using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.CatsAndLadders
{
    /// <summary>The board: 100 squares, ladders that carry a cat up and chutes that slide it down. Squares are numbered 1 to 100; 0 is "not on the board yet".</summary>
    public static class CatsAndLaddersRules
    {
        public const int Players = 4;
        public const int Last = 100;

        /// <summary>Bottom square of each ladder, and where it leads.</summary>
        public static readonly int[][] Ladders =
        {
            new[] { 1, 38 }, new[] { 4, 14 }, new[] { 9, 31 }, new[] { 21, 42 }, new[] { 28, 84 },
            new[] { 36, 44 }, new[] { 51, 67 }, new[] { 71, 91 }, new[] { 80, 100 }
        };

        /// <summary>Top square of each chute, and where it slides to.</summary>
        public static readonly int[][] Chutes =
        {
            new[] { 16, 6 }, new[] { 47, 26 }, new[] { 49, 11 }, new[] { 56, 53 }, new[] { 62, 19 },
            new[] { 64, 60 }, new[] { 87, 24 }, new[] { 93, 73 }, new[] { 95, 75 }, new[] { 98, 78 }
        };

        private static readonly Dictionary<int, int> LadderMap = Build(Ladders);
        private static readonly Dictionary<int, int> ChuteMap = Build(Chutes);

        private static Dictionary<int, int> Build(int[][] pairs)
        {
            var map = new Dictionary<int, int>();
            foreach (var p in pairs) map[p[0]] = p[1];
            return map;
        }

        /// <summary>The die for roll number <paramref name="rollNo"/> of a match: always the same for the same seed, so the server and a replay agree.</summary>
        public static int Die(ulong seed, int rollNo)
        {
            var random = new SeededRandom(seed * 31UL + (ulong)rollNo * 7919UL + 17UL);
            random.NextInt(6);   // the first number from a fresh generator is thrown away
            return random.NextInt(6) + 1;
        }

        /// <summary>Works out one turn from <paramref name="from"/> with a die. Rolling past 100 means staying put.</summary>
        public static Move Step(int from, int die)
        {
            int landed = from + die;
            if (landed > Last) return new Move(from, die, from, from, MoveKind.Stuck);
            if (LadderMap.TryGetValue(landed, out int up)) return new Move(from, die, landed, up, MoveKind.Ladder);
            if (ChuteMap.TryGetValue(landed, out int down)) return new Move(from, die, landed, down, MoveKind.Chute);
            return new Move(from, die, landed, landed, MoveKind.Plain);
        }
    }

    public enum MoveKind { Plain, Ladder, Chute, Stuck }

    /// <summary>What happened on one roll.</summary>
    public readonly struct Move
    {
        public Move(int from, int die, int landed, int to, MoveKind kind)
        {
            From = from; Die = die; Landed = landed; To = to; Kind = kind;
        }
        public int From { get; }
        public int Die { get; }
        /// <summary>The square the die counted to (before any ladder or chute).</summary>
        public int Landed { get; }
        /// <summary>Where the cat ends up.</summary>
        public int To { get; }
        public MoveKind Kind { get; }
    }
}
