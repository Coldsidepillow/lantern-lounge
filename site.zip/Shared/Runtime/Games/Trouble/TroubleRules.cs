using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.Trouble
{
    /// <summary>
    /// The rules of Trouble. Four players, four pegs each, a ring of 28 track squares.
    /// A peg's progress: -1 = at home, 0 = on its own start square, 1..27 = further around the ring (clockwise),
    /// 28..31 = the four squares of its own finish lane. Get all four pegs into the finish lane to win.
    /// </summary>
    public static class TroubleRules
    {
        public const int Players = 4;
        public const int PegsEach = 4;
        public const int TrackLength = 28;
        public const int StartGap = 7;          // each player's start square is 7 squares after the last one's
        public const int Home = -1;
        public const int FinishFirst = 28;
        public const int FinishLast = 31;
        public const int ExitRoll = 6;

        /// <summary>The die for roll number <paramref name="rollNo"/> of a match: always the same for the same seed.</summary>
        public static int Die(ulong seed, int rollNo)
        {
            var random = new SeededRandom(seed * 37UL + (ulong)rollNo * 6007UL + 29UL);
            random.NextInt(6);   // the first number from a fresh generator is thrown away
            return random.NextInt(6) + 1;
        }

        /// <summary>Which of the 28 ring squares a peg of <paramref name="seat"/> is on at <paramref name="progress"/> (0..27).</summary>
        public static int TrackIndex(int seat, int progress) => (seat * StartGap + progress) % TrackLength;

        public static int[] NewPegs()
        {
            var pegs = new int[Players * PegsEach];
            for (int i = 0; i < pegs.Length; i++) pegs[i] = Home;
            return pegs;
        }

        public static bool AllHome(int[] pegs, int seat)
        {
            for (int i = 0; i < PegsEach; i++) if (pegs[seat * PegsEach + i] != Home) return false;
            return true;
        }

        public static bool HasWon(int[] pegs, int seat)
        {
            for (int i = 0; i < PegsEach; i++) if (pegs[seat * PegsEach + i] < FinishFirst) return false;
            return true;
        }

        /// <summary>Can this peg move <paramref name="die"/> squares? Only a 6 gets a peg out; a peg can't land on your own peg or run past the end of the finish lane.</summary>
        public static bool CanMove(int[] pegs, int seat, int peg, int die, out int to)
        {
            to = 0;
            int p = pegs[seat * PegsEach + peg];
            if (p == Home)
            {
                if (die != ExitRoll) return false;
                to = 0;
            }
            else
            {
                to = p + die;
                if (to > FinishLast) return false;
            }
            for (int i = 0; i < PegsEach; i++)
                if (i != peg && pegs[seat * PegsEach + i] == to) return false;
            return true;
        }

        public static List<int> LegalPegs(int[] pegs, int seat, int die)
        {
            var list = new List<int>();
            for (int i = 0; i < PegsEach; i++) if (CanMove(pegs, seat, i, die, out _)) list.Add(i);
            return list;
        }

        /// <summary>The genuinely different things this die lets you do: pegs still at home are all the same, so only the first one counts.</summary>
        public static List<int> Choices(int[] pegs, int seat, int die)
        {
            var list = new List<int>();
            bool homeCounted = false;
            for (int i = 0; i < PegsEach; i++)
            {
                if (!CanMove(pegs, seat, i, die, out _)) continue;
                if (pegs[seat * PegsEach + i] == Home)
                {
                    if (homeCounted) continue;
                    homeCounted = true;
                }
                list.Add(i);
            }
            return list;
        }

        /// <summary>What a move did: where the peg ended up, and whose peg (if any) it knocked back home.</summary>
        public readonly struct Outcome
        {
            public Outcome(int from, int to, int capSeat, int capPeg, int capFrom)
            {
                From = from; To = to; CapSeat = capSeat; CapPeg = capPeg; CapFrom = capFrom;
            }
            public int From { get; }
            public int To { get; }
            /// <summary>-1 when nobody was knocked home.</summary>
            public int CapSeat { get; }
            public int CapPeg { get; }
            /// <summary>The captured peg's progress before it went home.</summary>
            public int CapFrom { get; }
        }

        /// <summary>Moves one peg (the move must be legal) and returns what happened. <paramref name="pegs"/> is changed in place.</summary>
        public static Outcome ApplyMove(int[] pegs, int seat, int peg, int die)
        {
            CanMove(pegs, seat, peg, die, out int to);
            int from = pegs[seat * PegsEach + peg];
            pegs[seat * PegsEach + peg] = to;
            int capSeat = -1, capPeg = -1, capFrom = 0;
            if (to < TrackLength)
            {
                int square = TrackIndex(seat, to);
                for (int o = 0; o < Players && capSeat < 0; o++)
                {
                    if (o == seat) continue;
                    for (int j = 0; j < PegsEach; j++)
                    {
                        int q = pegs[o * PegsEach + j];
                        if (q >= 0 && q < TrackLength && TrackIndex(o, q) == square)
                        {
                            capSeat = o; capPeg = j; capFrom = q;
                            pegs[o * PegsEach + j] = Home;
                            break;
                        }
                    }
                }
            }
            return new Outcome(from, to, capSeat, capPeg, capFrom);
        }

        /// <summary>The peg a sensible player (or a bot, or a timed-out turn) would move: knock someone home, else reach the finish lane, else get out, else push the front runner.</summary>
        public static int PickPeg(int[] pegs, int seat, int die)
        {
            int best = -1, bestScore = int.MinValue;
            foreach (int peg in LegalPegs(pegs, seat, die))
            {
                int p = pegs[seat * PegsEach + peg];
                CanMove(pegs, seat, peg, die, out int to);
                int score;
                if (WouldCapture(pegs, seat, to)) score = 200 + to;
                else if (to >= FinishFirst && p < FinishFirst) score = 150 + to;
                else if (p == Home) score = 100;
                else score = 10 + p;
                if (score > bestScore) { bestScore = score; best = peg; }
            }
            return best;
        }

        private static bool WouldCapture(int[] pegs, int seat, int to)
        {
            if (to >= TrackLength) return false;
            int square = TrackIndex(seat, to);
            for (int o = 0; o < Players; o++)
            {
                if (o == seat) continue;
                for (int j = 0; j < PegsEach; j++)
                {
                    int q = pegs[o * PegsEach + j];
                    if (q >= 0 && q < TrackLength && TrackIndex(o, q) == square) return true;
                }
            }
            return false;
        }
    }
}
