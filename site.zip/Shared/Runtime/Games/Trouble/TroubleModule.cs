using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.Trouble
{
    /// <summary>What a player can do: roll the die (Peg = -1), or move one of their four pegs (Peg 0 to 3) after rolling.</summary>
    public readonly struct TroubleAction
    {
        public TroubleAction(int peg) { Peg = peg; }
        public int Peg { get; }
        public bool IsRoll => Peg < 0;
        public static TroubleAction Roll => new TroubleAction(-1);
        public static TroubleAction Move(int peg) => new TroubleAction(peg);
    }

    /// <summary>
    /// Trouble: roll the die (the server rolls it, so nobody can cheat). A 1 or a 6 lets a peg out of home, and both also give you another roll. With every cat at home you get three tries.
    /// Land on someone else's peg and it goes back home. Exact count needed to fill your finish lane.
    /// Options: "firstSeat" = "0".."4", or "random" (default). One module per board map: Classic (4 players) or Star (5 players).
    /// </summary>
    public sealed class TroubleModule : GameModule<TroubleState, TroubleAction, TroubleState>
    {
        public const string GameId = "trouble";

        /// <summary>The classic board's info (the star board's is on its own module).</summary>
        public static readonly GameInfo Definition =
            new GameInfo(GameId, "Benson", TroubleBoard.Classic.Players, TroubleBoard.Classic.Players, GameStatus.Playable, "trouble");

        private static readonly IReadOnlyList<int> NoSeats = Array.Empty<int>();

        private readonly TroubleBoard board;
        private readonly GameInfo info;

        public TroubleModule() : this(TroubleBoard.Classic) { }

        public TroubleModule(TroubleBoard board)
        {
            this.board = board;
            info = board == TroubleBoard.Classic
                ? Definition
                : new GameInfo(board.GameId, board.Name, board.Players, board.Players, GameStatus.Playable, "trouble");
        }

        public TroubleBoard Board => board;

        public override GameInfo Info => info;

        protected override TroubleState CreateInitialState(MatchConfig config)
        {
            var random = new SeededRandom(config.Seed);
            string first = config.GetOption("firstSeat", "random");
            if (!int.TryParse(first, out int seat) || seat < 0 || seat >= board.Players)
                seat = random.NextInt(board.Players);
            return TroubleState.CreateNew(board, config.Seed, seat);
        }

        public override ValidationResult Validate(TroubleState state, int seat, TroubleAction action)
        {
            if (state == null) return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no board.");
            if (state.IsOver) return ValidationResult.Fail(ErrorCodes.GameOver, "This game is already over.");
            if (seat < 0 || seat >= board.Players) return ValidationResult.Fail(ErrorCodes.BadSeat, $"{board.Name} has seats 0 to {board.Players - 1} only.");
            if (seat != state.CurrentSeat) return ValidationResult.Fail(ErrorCodes.NotYourTurn, "It isn't your turn yet.");
            if (action.IsRoll)
            {
                if (state.Pending > 0) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Move a peg first.");
                return ValidationResult.Success;
            }
            if (state.Pending == 0) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Roll die first.");
            if (action.Peg >= TroubleRules.PegsEach) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Pick one of your four cats.");
            if (!TroubleRules.CanMove(board, state.Pegs, seat, action.Peg, state.Pending, out _))
                return ValidationResult.Fail(ErrorCodes.InvalidAction, "That cat can't move that far.");
            return ValidationResult.Success;
        }

        protected override TroubleState ApplyValidated(TroubleState state, int seat, TroubleAction action)
        {
            int[] pegs = state.CopyPegs();
            int actions = state.Actions + 1;
            if (action.IsRoll)
            {
                int rollNo = state.Rolls + 1;
                int die = TroubleRules.Die(state.Seed, rollNo);
                var legal = TroubleRules.Choices(board, pegs, seat, die);
                if (legal.Count > 1)
                {
                    // a real choice: wait for the player to pick a peg
                    var ev = new TroubleEvent(TroubleKind.Roll, seat, die, -1, 0, 0, -1, -1, 0);
                    return new TroubleState(pegs, state.Seed, seat, die, state.Tries, rollNo, actions, TroubleState.NoSeat, ev);
                }
                if (legal.Count == 1)
                {
                    // only one thing to do: do it
                    var o = TroubleRules.ApplyMove(board, pegs, seat, legal[0], die);
                    var ev = new TroubleEvent(TroubleKind.RollMove, seat, die, legal[0], o.From, o.To, o.CapSeat, o.CapPeg, o.CapFrom);
                    return Finish(state, pegs, seat, die, rollNo, actions, ev, false);
                }
                var none = new TroubleEvent(TroubleKind.Roll, seat, die, -1, 0, 0, -1, -1, 0);
                return Finish(state, pegs, seat, die, rollNo, actions, none, true);
            }
            else
            {
                int die = state.Pending;
                var o = TroubleRules.ApplyMove(board, pegs, seat, action.Peg, die);
                var ev = new TroubleEvent(TroubleKind.Move, seat, die, action.Peg, o.From, o.To, o.CapSeat, o.CapPeg, o.CapFrom);
                return Finish(state, pegs, seat, die, state.Rolls, actions, ev, false);
            }
        }

        /// <summary>The turn is used up: pick who goes next. A 1 or a 6 means roll again; three tries at a 1 or a 6 when everything is at home.</summary>
        private TroubleState Finish(TroubleState state, int[] pegs, int seat, int die, int rolls, int actions, TroubleEvent ev, bool noMove)
        {
            if (TroubleRules.HasWon(board, pegs, seat))
                return new TroubleState(pegs, state.Seed, seat, 0, 1, rolls, actions, seat, ev);
            if (TroubleRules.IsExitRoll(die))
                return new TroubleState(pegs, state.Seed, seat, 0, TroubleRules.AllHome(pegs, seat) ? TroubleRules.HomeTries : 1, rolls, actions, TroubleState.NoSeat, ev);
            if (noMove && TroubleRules.AllHome(pegs, seat) && state.Tries > 1)
                return new TroubleState(pegs, state.Seed, seat, 0, state.Tries - 1, rolls, actions, TroubleState.NoSeat, ev);
            int next = (seat + 1) % board.Players;
            return new TroubleState(pegs, state.Seed, next, 0, TroubleRules.AllHome(pegs, next) ? TroubleRules.HomeTries : 1, rolls, actions, TroubleState.NoSeat, ev);
        }

        public override TroubleState ViewFor(TroubleState state, int seat) => state;

        public override MatchResult Result(TroubleState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? MatchResult.Win(state.Winner) : MatchResult.InProgress;
        }

        public override IReadOnlyList<int> SeatsToAct(TroubleState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? NoSeats : new[] { state.CurrentSeat };
        }

        /// <summary>If someone walks away from the table, the die gets rolled and a sensible peg moved for them.</summary>
        public override bool TryGetTimeoutAction(TroubleState state, int seat, out TroubleAction action)
        {
            action = default;
            if (state == null || state.IsOver || seat != state.CurrentSeat) return false;
            action = state.Pending > 0 ? TroubleAction.Move(TroubleRules.PickPeg(board, state.Pegs, seat, state.Pending)) : TroubleAction.Roll;
            return true;
        }
    }
}
