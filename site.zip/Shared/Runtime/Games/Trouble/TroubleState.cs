using System;

namespace LanternLounge.Games.Trouble
{
    public enum TroubleKind { None, Roll, Move, RollMove }

    /// <summary>What the latest action did, so screens can play it back.</summary>
    public readonly struct TroubleEvent
    {
        public TroubleEvent(TroubleKind kind, int seat, int die, int peg, int from, int to, int capSeat, int capPeg, int capFrom)
        {
            Kind = kind; Seat = seat; Die = die; Peg = peg; From = from; To = to; CapSeat = capSeat; CapPeg = capPeg; CapFrom = capFrom;
        }
        public TroubleKind Kind { get; }
        public int Seat { get; }
        public int Die { get; }
        public int Peg { get; }
        public int From { get; }
        public int To { get; }
        public int CapSeat { get; }
        public int CapPeg { get; }
        public int CapFrom { get; }
    }

    /// <summary>Where every peg is, whose turn it is, and the die waiting to be used. Nothing is hidden.</summary>
    public sealed class TroubleState
    {
        public const int NoSeat = -1;

        internal TroubleState(int[] pegs, ulong seed, int currentSeat, int pending, int tries, int rolls, int actions, int winner, TroubleEvent last)
        {
            Pegs = pegs; Seed = seed; CurrentSeat = currentSeat; Pending = pending; Tries = tries;
            Rolls = rolls; Actions = actions; Winner = winner; Last = last;
        }

        internal static TroubleState CreateNew(ulong seed, int firstSeat) =>
            new TroubleState(TroubleRules.NewPegs(), seed, firstSeat, 0, 3, 0, 0, NoSeat, default);

        /// <summary>16 numbers: seat * 4 + peg. See <see cref="TroubleRules"/> for what a number means.</summary>
        public int[] Pegs { get; }
        public ulong Seed { get; }
        public int CurrentSeat { get; }
        /// <summary>The die the current player has rolled and still has to use (0 = they have not rolled yet).</summary>
        public int Pending { get; }
        /// <summary>Rolls left in this turn while all four pegs are still at home (you get three tries to throw a 6).</summary>
        public int Tries { get; }
        public int Rolls { get; }
        /// <summary>Counts every roll and move, so screens can tell something new happened.</summary>
        public int Actions { get; }
        public int Winner { get; }
        public bool IsOver => Winner != NoSeat;
        public TroubleEvent Last { get; }

        public int[] CopyPegs() => (int[])Pegs.Clone();
    }
}
