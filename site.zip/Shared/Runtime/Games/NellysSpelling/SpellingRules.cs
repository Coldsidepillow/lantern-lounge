using System;
using LanternLounge.Core;

namespace LanternLounge.Games.NellysSpelling
{
    public readonly struct SpellingWord
    {
        public SpellingWord(string word, string definition, string sentence) { Word = word; Definition = definition; Sentence = sentence; }
        public string Word { get; }
        public string Definition { get; }
        /// <summary>A sentence that uses the word, with the word itself left blank (____).</summary>
        public string Sentence { get; }
        /// <summary>The letters to type: lower case, no spaces ("free verse" is nine letters).</summary>
        public string Letters => Word.Replace(" ", "").ToLowerInvariant();
        /// <summary>How many letters come before the space in a two-word answer, or -1 for a single word.</summary>
        public int GapAfter => Word.IndexOf(' ');
    }

    /// <summary>The word list and the few fixed numbers. Seat 0 spells; the other seats only watch.</summary>
    public static class SpellingRules
    {
        public const int Seats = 4;
        public const int Speller = 0;
        public const int MaxTries = 6;

        public static readonly SpellingWord[] Words =
        {
            new SpellingWord("imagine", "picture something in your mind", "Close your eyes and ____ a big pink castle."),
            new SpellingWord("bounce", "spring back after hitting something", "The ball will ____ on the floor."),
            new SpellingWord("inventor", "a person who creates something for the first time", "The ____ made a new toy."),
            new SpellingWord("observer", "someone who watches something", "The ____ watched the birds from the window."),
            new SpellingWord("alliteration", "several words or syllables in a row start with the same sound", "\"Silly snakes slide slowly\" is an example of ____."),
            new SpellingWord("free verse", "poem in which some verses rhyme and some do not", "My poem is ____, so not all the lines rhyme."),
            new SpellingWord("limerick", "a funny poem of five lines with a specific rhyme pattern", "I read a funny ____ to my class."),
            new SpellingWord("rhyme", "when words end with the same sound", "\"Cat\" and \"hat\" make a ____."),
        };

        /// <summary>
        /// Marks a try against the word, like Wordle: '2' right letter in the right box, '1' right letter in the wrong box,
        /// '0' letter that is not (or is no longer) in the word. Both strings are lower case letters only.
        /// </summary>
        public static string Mark(string target, string guess)
        {
            var marks = new char[guess.Length];
            var left = new int[26];
            for (int i = 0; i < target.Length; i++)
                if (i >= guess.Length || guess[i] != target[i]) left[target[i] - 'a']++;
            for (int i = 0; i < guess.Length; i++)
            {
                if (i < target.Length && guess[i] == target[i]) marks[i] = '2';
                else if (guess[i] >= 'a' && guess[i] <= 'z' && left[guess[i] - 'a'] > 0) { marks[i] = '1'; left[guess[i] - 'a']--; }
                else marks[i] = '0';
            }
            return new string(marks);
        }

        /// <summary>The order the words come in this match (shuffled by the seed, so every game is a little different).</summary>
        public static int[] Order(ulong seed)
        {
            var random = new SeededRandom(seed);
            int[] order = new int[Words.Length];
            for (int i = 0; i < order.Length; i++) order[i] = i;
            for (int i = order.Length - 1; i > 0; i--)
            {
                int j = random.NextInt(i + 1);
                int t = order[i]; order[i] = order[j]; order[j] = t;
            }
            return order;
        }
    }
}
