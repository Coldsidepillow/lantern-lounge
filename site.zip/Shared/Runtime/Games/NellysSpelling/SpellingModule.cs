using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.NellysSpelling
{
    public enum SpellingKind { Ready, Define, Letter, Back, Enter, Next, Sentence }

    /// <summary>
    /// What the speller can do: Ready (leave the definition and start spelling), Define (look at the definition again),
    /// Letter, Back, Enter (check the word), Next (go on to the next word).
    /// </summary>
    public readonly struct SpellingAction
    {
        public SpellingAction(SpellingKind kind, char letter = '\0') { Kind = kind; Letter = letter; }
        public SpellingKind Kind { get; }
        public char Letter { get; }
        public static SpellingAction Of(SpellingKind kind) => new SpellingAction(kind);
        public static SpellingAction Type(char letter) => new SpellingAction(SpellingKind.Letter, letter);
    }

    /// <summary>
    /// Nelly's Spelling: a one-player spelling test that looks like Wordle. Each word shows its definition first, then
    /// you spell it in a grid (six tries, no letter hints). Seat 0 plays; the other seats watch.
    /// </summary>
    public sealed class SpellingModule : GameModule<SpellingState, SpellingAction, SpellingState>
    {
        public const string GameId = "nellys-spelling";

        public static readonly GameInfo Definition =
            new GameInfo(GameId, "Unit 2, week 5 spelling", 1, SpellingRules.Seats, GameStatus.Playable, "nellys-spelling");

        private static readonly IReadOnlyList<int> NoSeats = Array.Empty<int>();
        private static readonly IReadOnlyList<int> SpellerOnly = new[] { SpellingRules.Speller };

        public override GameInfo Info => Definition;

        protected override SpellingState CreateInitialState(MatchConfig config) => SpellingState.CreateNew(config.Seed);

        public override ValidationResult Validate(SpellingState state, int seat, SpellingAction action)
        {
            if (state == null) return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no game.");
            if (state.IsOver) return ValidationResult.Fail(ErrorCodes.GameOver, "This game is already over.");
            if (seat < 0 || seat >= SpellingRules.Seats) return ValidationResult.Fail(ErrorCodes.BadSeat, "There are seats 0 to 3 only.");
            if (seat != SpellingRules.Speller) return ValidationResult.Fail(ErrorCodes.NotYourTurn, "You are watching. Only the speller can play.");
            switch (action.Kind)
            {
                case SpellingKind.Ready:
                    if (state.Phase == SpellingPhase.Define || (state.Phase == SpellingPhase.Spell && state.ShowDef)) return ValidationResult.Success;
                    return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no definition to close.");
                case SpellingKind.Define:
                case SpellingKind.Sentence:
                    if (state.Phase == SpellingPhase.Spell && !state.ShowDef) return ValidationResult.Success;
                    return ValidationResult.Fail(ErrorCodes.InvalidAction, "The definition and the sentence can be shown while you spell.");
                case SpellingKind.Letter:
                    if (state.Phase != SpellingPhase.Spell || state.ShowDef) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Not spelling right now.");
                    if (action.Letter < 'a' || action.Letter > 'z') return ValidationResult.Fail(ErrorCodes.InvalidAction, "Letters a to z only.");
                    if (state.Current.Length >= state.Word.Letters.Length) return ValidationResult.Fail(ErrorCodes.InvalidAction, "That row is full.");
                    return ValidationResult.Success;
                case SpellingKind.Back:
                    if (state.Phase != SpellingPhase.Spell || state.ShowDef || state.Current.Length == 0) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Nothing to erase.");
                    return ValidationResult.Success;
                case SpellingKind.Enter:
                    if (state.Phase != SpellingPhase.Spell || state.ShowDef) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Not spelling right now.");
                    if (state.Current.Length != state.Word.Letters.Length) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Fill in every box first.");
                    return ValidationResult.Success;
                case SpellingKind.Next:
                    if (state.Phase != SpellingPhase.Result) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Finish this word first.");
                    return ValidationResult.Success;
                default:
                    return ValidationResult.Fail(ErrorCodes.InvalidAction, "Unknown move.");
            }
        }

        protected override SpellingState ApplyValidated(SpellingState state, int seat, SpellingAction action)
        {
            var s = state.Copy();
            s.Events = state.Events + 1;
            switch (action.Kind)
            {
                case SpellingKind.Ready:
                    s.Phase = SpellingPhase.Spell;
                    s.ShowDef = false;
                    s.ShowSentence = false;
                    break;
                case SpellingKind.Define:
                    s.ShowDef = true;
                    s.ShowSentence = false;
                    break;
                case SpellingKind.Sentence:
                    s.ShowDef = true;
                    s.ShowSentence = true;
                    break;
                case SpellingKind.Letter:
                    s.Current = state.Current + action.Letter;
                    break;
                case SpellingKind.Back:
                    s.Current = state.Current.Substring(0, state.Current.Length - 1);
                    break;
                case SpellingKind.Enter:
                {
                    bool right = state.Current == state.Word.Letters;
                    var rows = new string[state.Rows.Length + 1];
                    Array.Copy(state.Rows, rows, state.Rows.Length);
                    rows[rows.Length - 1] = state.Current;
                    s.Rows = rows;
                    s.Current = "";
                    if (right || rows.Length >= SpellingRules.MaxTries)
                    {
                        s.Phase = SpellingPhase.Result;
                        s.Outcome = right ? 1 : 2;
                        s.Results = (int[])state.Results.Clone();
                        s.Results[state.Index] = s.Outcome;
                    }
                    break;
                }
                case SpellingKind.Next:
                    s.Index = state.Index + 1;
                    s.Rows = Array.Empty<string>();
                    s.Current = "";
                    s.Outcome = 0;
                    if (s.Index >= SpellingRules.Words.Length) s.Phase = SpellingPhase.Done;
                    else { s.Phase = SpellingPhase.Define; s.ShowDef = true; }
                    break;
            }
            return s;
        }

        public override SpellingState ViewFor(SpellingState state, int seat) => state;

        public override MatchResult Result(SpellingState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? MatchResult.Win(SpellingRules.Speller) : MatchResult.InProgress;
        }

        public override IReadOnlyList<int> SeatsToAct(SpellingState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? NoSeats : SpellerOnly;
        }
    }
}
