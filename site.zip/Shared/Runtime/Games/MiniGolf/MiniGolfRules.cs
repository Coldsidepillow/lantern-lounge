using System;
using System.Collections.Generic;

namespace LanternLounge.Games.MiniGolf
{
    /// <summary>The numbers that make the ball roll. The website draws what this code simulates.</summary>
    public static class MiniGolfRules
    {
        public const int MaxPlayers = 4;
        public const int HolesPerCourse = 3;   // TEST: only the first three holes of a course are played (the full course has 9); hole 3 is a work in progress
        public const int MaxStrokes = 8;

        public const double BallRadius = 0.28;
        public const double HoleRadius = 0.46;
        public const double MaxSpeed = 12.5;          // units per second at full power
        public const double Dt = 1.0 / 120.0;
        public const int SampleEvery = 4;             // the path is sent 30 times a second
        public const int MaxSteps = 12 * 120;         // a shot never rolls longer than 12 seconds
        public const double StopSpeed = 0.18;
        public const double GrassDecel = 2.4;
        public const double SandDecel = 11.0;
        public const double IceDecel = 0.45;
        public const double WallBounce = 0.72;
        public const double BumperBounce = 1.08;
        public const double BumperRadius = 0.45;
        public const double CaptureSpeed = 6.0;       // faster than this and the ball skips over the hole
        public const double Boost = 16.0;
        public const double BoostMax = 17.0;
        public const double BallBounce = 0.9;         // how lively two balls are when they hit each other

        /// <summary>Where each player's ball starts around the tee, so four balls don't sit on one spot.</summary>
        public static readonly double[][] TeeOffsets =
        {
            new[] { -0.3, -0.3 }, new[] { 0.3, -0.3 }, new[] { -0.3, 0.3 }, new[] { 0.3, 0.3 }
        };

        public enum ShotEnd { Rest, Sunk, Water }

        public sealed class ShotResult
        {
            public double[] Path;       // x, y, x, y ... (30 samples a second)
            public int[] Bounces;       // sample numbers where the ball hit something
            public ShotEnd End;
            public double X, Y;         // where the ball finished
        }

        private static double R2(double v) => Math.Round(v * 100.0) / 100.0;

        private static char Other(char portal)
        {
            switch (portal)
            {
                case 'a': return 'b';
                case 'b': return 'a';
                case 'c': return 'd';
                default: return 'c';
            }
        }

        public static bool IsPortal(char t) => t == 'a' || t == 'b' || t == 'c' || t == 'd';

        public enum StepEnd { Rolling, Stopped, Water, Sunk, Portal }

        /// <summary>A ball in flight: where it is, how fast it goes, and a little memory for the portal it just came out of.</summary>
        public sealed class Body
        {
            public double X, Y, Vx, Vy;
            public int PortalCell = -1;
            public bool Bounced;
        }

        /// <summary>One step (1/120 s) of one ball on its own: friction, boost pads, portals, walls, bumpers and the hole.</summary>
        public static StepEnd StepBall(MiniGolfHole hole, Body b)
        {
            double x = b.X, y = b.Y, vx = b.Vx, vy = b.Vy;
            int cx = (int)Math.Floor(x), cy = (int)Math.Floor(y);
            char t = hole.TileAt(cx, cy);
            if (t == 'w' || t == ' ') return StepEnd.Water;

            double speed = Math.Sqrt(vx * vx + vy * vy);
            double decel = t == 's' ? SandDecel : t == 'i' ? IceDecel : GrassDecel;
            double slowed = Math.Max(0.0, speed - decel * Dt);
            if (speed > 0.0) { vx *= slowed / speed; vy *= slowed / speed; }
            speed = slowed;

            bool onPad = false;
            if (t == '>') { vx += Boost * Dt; onPad = true; }
            else if (t == '<') { vx -= Boost * Dt; onPad = true; }
            else if (t == '^') { vy -= Boost * Dt; onPad = true; }
            else if (t == 'v') { vy += Boost * Dt; onPad = true; }
            if (onPad)
            {
                double sp = Math.Sqrt(vx * vx + vy * vy);
                if (sp > BoostMax) { vx *= BoostMax / sp; vy *= BoostMax / sp; }
                speed = Math.Sqrt(vx * vx + vy * vy);
            }

            // portals: a<->b and c<->d. You pop out of the other one and keep rolling.
            if (IsPortal(t))
            {
                if (b.PortalCell != cx * 1000 + cy && hole.TryGetPortal(Other(t), out double px, out double py))
                {
                    b.X = px; b.Y = py; b.Vx = vx; b.Vy = vy;
                    b.PortalCell = (int)Math.Floor(px) * 1000 + (int)Math.Floor(py);
                    return StepEnd.Portal;
                }
            }
            else b.PortalCell = -1;

            if (speed < StopSpeed && !onPad) { b.Vx = 0.0; b.Vy = 0.0; return StepEnd.Stopped; }

            x += vx * Dt; y += vy * Dt;

            // walls: push the ball out of any wall cell it overlaps and bounce it
            int x0 = (int)Math.Floor(x - BallRadius), x1 = (int)Math.Floor(x + BallRadius);
            int y0 = (int)Math.Floor(y - BallRadius), y1 = (int)Math.Floor(y + BallRadius);
            for (int wy = y0; wy <= y1; wy++)
            {
                for (int wx = x0; wx <= x1; wx++)
                {
                    if (hole.TileAt(wx, wy) != '#') continue;
                    double qx = Math.Max(wx, Math.Min(x, wx + 1));
                    double qy = Math.Max(wy, Math.Min(y, wy + 1));
                    double dx = x - qx, dy = y - qy;
                    double d = Math.Sqrt(dx * dx + dy * dy);
                    if (d >= BallRadius) continue;
                    double nx, ny;
                    if (d < 1e-9)
                    {
                        double sp = Math.Sqrt(vx * vx + vy * vy);
                        if (sp < 1e-9) sp = 1.0;
                        nx = -vx / sp; ny = -vy / sp; d = 0.0;
                    }
                    else { nx = dx / d; ny = dy / d; }
                    x += nx * (BallRadius - d); y += ny * (BallRadius - d);
                    double vn = vx * nx + vy * ny;
                    if (vn < 0.0) { vx -= (1.0 + WallBounce) * vn * nx; vy -= (1.0 + WallBounce) * vn * ny; b.Bounced = true; }
                }
            }

            // bumpers: round pillars that kick the ball back a little harder than it came
            double reach = BallRadius + BumperRadius;
            int bx0 = (int)Math.Floor(x - reach), bx1 = (int)Math.Floor(x + reach);
            int by0 = (int)Math.Floor(y - reach), by1 = (int)Math.Floor(y + reach);
            for (int wy = by0; wy <= by1; wy++)
            {
                for (int wx = bx0; wx <= bx1; wx++)
                {
                    if (hole.TileAt(wx, wy) != 'o') continue;
                    double dx = x - (wx + 0.5), dy = y - (wy + 0.5);
                    double d = Math.Sqrt(dx * dx + dy * dy);
                    if (d >= reach || d < 1e-9) continue;
                    double nx = dx / d, ny = dy / d;
                    x += nx * (reach - d); y += ny * (reach - d);
                    double vn = vx * nx + vy * ny;
                    if (vn < 0.0) { vx -= (1.0 + BumperBounce) * vn * nx; vy -= (1.0 + BumperBounce) * vn * ny; b.Bounced = true; }
                }
            }
            b.X = x; b.Y = y; b.Vx = vx; b.Vy = vy;

            // the hole: slow enough and the ball drops in
            double hx = x - hole.HoleX, hy = y - hole.HoleY;
            if (Math.Sqrt(hx * hx + hy * hy) < HoleRadius - 0.05 && Math.Sqrt(vx * vx + vy * vy) < CaptureSpeed)
            {
                b.X = hole.HoleX; b.Y = hole.HoleY;
                return StepEnd.Sunk;
            }
            return StepEnd.Rolling;
        }

        /// <summary>Hits a ball from (sx, sy) with the given velocity and follows it until it stops, sinks or splashes. Other balls are ignored (the bots use this to plan).</summary>
        public static ShotResult Simulate(MiniGolfHole hole, double sx, double sy, double vx, double vy)
        {
            var b = new Body { X = sx, Y = sy, Vx = vx, Vy = vy };
            var path = new List<double> { R2(b.X), R2(b.Y) };
            var bounces = new List<int>();
            var end = ShotEnd.Rest;
            for (int step = 0; step < MaxSteps; step++)
            {
                var r = StepBall(hole, b);
                if (r == StepEnd.Water) { end = ShotEnd.Water; break; }
                if (r == StepEnd.Stopped) break;
                if (r == StepEnd.Sunk) { end = ShotEnd.Sunk; break; }
                if (r == StepEnd.Portal) { path.Add(R2(b.X)); path.Add(R2(b.Y)); continue; }
                if ((step + 1) % SampleEvery == 0)
                {
                    path.Add(R2(b.X)); path.Add(R2(b.Y));
                    if (b.Bounced) bounces.Add(path.Count / 2 - 1);
                    b.Bounced = false;
                }
            }
            path.Add(R2(b.X)); path.Add(R2(b.Y));
            return new ShotResult { Path = path.ToArray(), Bounces = bounces.ToArray(), End = end, X = b.X, Y = b.Y };
        }
    }

    /// <summary>One hole: a grid of tiles plus where the tee, the hole and the portals are.</summary>
    public sealed class MiniGolfHole
    {
        private readonly Dictionary<char, double[]> portals = new Dictionary<char, double[]>();

        public MiniGolfHole(string name, int par, string[] rows)
        {
            Name = name; Par = par; Rows = rows;
            Height = rows.Length; Width = rows[0].Length;
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    char c = rows[y][x];
                    if (c == 'T') { TeeX = x + 0.5; TeeY = y + 0.5; }
                    else if (c == 'H') { HoleX = x + 0.5; HoleY = y + 0.5; }
                    else if (MiniGolfRules.IsPortal(c)) portals[c] = new[] { x + 0.5, y + 0.5 };
                }
            }
        }

        public string Name { get; }
        public int Par { get; }
        public string[] Rows { get; }
        public int Width { get; }
        public int Height { get; }
        public double TeeX { get; }
        public double TeeY { get; }
        public double HoleX { get; }
        public double HoleY { get; }

        public char TileAt(int cx, int cy)
        {
            if (cx < 0 || cy < 0 || cx >= Width || cy >= Height) return '#';
            return Rows[cy][cx];
        }

        public bool TryGetPortal(char which, out double x, out double y)
        {
            if (portals.TryGetValue(which, out var p)) { x = p[0]; y = p[1]; return true; }
            x = 0; y = 0;
            return false;
        }
    }
}
