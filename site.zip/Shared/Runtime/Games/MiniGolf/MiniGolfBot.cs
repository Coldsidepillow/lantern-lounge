using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.MiniGolf
{
    /// <summary>
    /// A bot golfer. It tries ninety-six directions at eight powers by actually rolling the ball in its head,
    /// favours spots closer to the hole (measured along the fairway, so bends and portals count), avoids
    /// shots that could splash with a small wobble, looks one shot further ahead, and then misses a little
    /// on purpose so it plays like a person rather than a robot.
    /// </summary>
    public static class MiniGolfBot
    {
        private static readonly double[] Powers = { 0.2, 0.3, 0.42, 0.55, 0.68, 0.8, 0.9, 1.0 };
        private static readonly double[][] Wobbles = { new[] { 0.035, 1.0 }, new[] { -0.035, 1.0 }, new[] { 0.0, 1.06 }, new[] { 0.0, 0.94 } };

        private sealed class Candidate
        {
            public double Score, Angle, Power, X, Y, Adjusted;
            public bool Sunk;
            public int Risk;
        }

        /// <summary>Plans one shot from (sx, sy). Other balls are ignored: bumps are part of the fun.</summary>
        public static void Plan(MiniGolfHole hole, double sx, double sy, SeededRandom random, double skill, out double angle, out double power)
        {
            var dist = Distances(hole);
            var first = Candidates(hole, dist, sx, sy);
            if (first.Count == 0) { angle = random.NextInt(628) / 100.0; power = 0.5; return; }

            // the best few distinct landing spots, minus the ones that could splash with a small wobble
            var picks = new List<Candidate>();
            foreach (var c in first)
            {
                if (picks.Count >= 28) break;
                bool near = false;
                foreach (var p in picks) if (Math.Abs(p.X - c.X) < 0.5 && Math.Abs(p.Y - c.Y) < 0.5) { near = true; break; }
                if (near) continue;
                c.Risk = Risk(hole, sx, sy, c);
                c.Adjusted = c.Score + c.Risk * 7.0;
                picks.Add(c);
            }
            picks.Sort((a, b) => a.Adjusted.CompareTo(b.Adjusted));

            var best = picks[0];
            if (!best.Sunk)
            {
                double bestTotal = double.MaxValue;
                for (int i = 0; i < picks.Count && i < 6; i++)
                {
                    var c = picks[i];
                    double total;
                    if (c.Sunk) total = -1000.0;
                    else
                    {
                        var next = Candidates(hole, dist, c.X, c.Y);
                        total = (next.Count > 0 ? next[0].Score : c.Score + 50.0) + 4.0 + c.Risk * 7.0;
                    }
                    if (total < bestTotal) { bestTotal = total; best = c; }
                }
            }

            double noise = (random.NextInt(1000) / 1000.0 - 0.5) * 0.07 * skill;
            double powerNoise = 1.0 + (random.NextInt(1000) / 1000.0 - 0.5) * 0.1 * skill;
            angle = best.Angle + noise;
            power = Math.Min(1.0, Math.Max(0.05, best.Power * powerNoise));
        }

        private static List<Candidate> Candidates(MiniGolfHole hole, int[,] dist, double sx, double sy)
        {
            var list = new List<Candidate>();
            for (int k = 0; k < 96; k++)
            {
                double angle = k / 96.0 * Math.PI * 2.0;
                foreach (double power in Powers)
                {
                    var r = MiniGolfRules.Simulate(hole, sx, sy, Math.Cos(angle) * MiniGolfRules.MaxSpeed * power, Math.Sin(angle) * MiniGolfRules.MaxSpeed * power);
                    double score;
                    if (!Score(hole, dist, r, power, out score)) continue;
                    list.Add(new Candidate { Score = score, Angle = angle, Power = power, X = r.X, Y = r.Y, Sunk = r.End == MiniGolfRules.ShotEnd.Sunk });
                }
            }
            list.Sort((a, b) => a.Score.CompareTo(b.Score));
            return list;
        }

        private static bool Score(MiniGolfHole hole, int[,] dist, MiniGolfRules.ShotResult r, double power, out double score)
        {
            score = 0;
            if (r.End == MiniGolfRules.ShotEnd.Water) return false;
            if (r.End == MiniGolfRules.ShotEnd.Sunk) { score = -1000.0 + power; return true; }
            int cx = (int)Math.Floor(r.X), cy = (int)Math.Floor(r.Y);
            if (cx < 0 || cy < 0 || cx >= hole.Width || cy >= hole.Height) return false;
            int d = dist[cy, cx];
            if (d < 0) return false;
            double hx = r.X - hole.HoleX, hy = r.Y - hole.HoleY;
            score = d + Math.Sqrt(hx * hx + hy * hy) * 0.1;
            return true;
        }

        private static int Risk(MiniGolfHole hole, double sx, double sy, Candidate c)
        {
            int bad = 0;
            foreach (var w in Wobbles)
            {
                double p = Math.Min(1.0, c.Power * w[1]), a = c.Angle + w[0];
                var r = MiniGolfRules.Simulate(hole, sx, sy, Math.Cos(a) * MiniGolfRules.MaxSpeed * p, Math.Sin(a) * MiniGolfRules.MaxSpeed * p);
                if (r.End == MiniGolfRules.ShotEnd.Water) bad++;
            }
            return bad;
        }

        /// <summary>How many tiles from each tile to the hole, walking (and hopping through portals). -1 where the ball can't be.</summary>
        public static int[,] Distances(MiniGolfHole hole)
        {
            var seen = new int[hole.Height, hole.Width];
            for (int y = 0; y < hole.Height; y++) for (int x = 0; x < hole.Width; x++) seen[y, x] = -1;
            int hx = (int)Math.Floor(hole.HoleX), hy = (int)Math.Floor(hole.HoleY);
            var queue = new Queue<int[]>();
            seen[hy, hx] = 0;
            queue.Enqueue(new[] { hx, hy });
            int[][] steps = { new[] { 1, 0 }, new[] { -1, 0 }, new[] { 0, 1 }, new[] { 0, -1 } };
            while (queue.Count > 0)
            {
                var cur = queue.Dequeue();
                int x = cur[0], y = cur[1];
                var links = new List<int[]>();
                foreach (var st in steps) links.Add(new[] { x + st[0], y + st[1] });
                char here = hole.TileAt(x, y);
                if (MiniGolfRules.IsPortal(here))
                {
                    char other = here == 'a' ? 'b' : here == 'b' ? 'a' : here == 'c' ? 'd' : 'c';
                    if (hole.TryGetPortal(other, out double px, out double py)) links.Add(new[] { (int)Math.Floor(px), (int)Math.Floor(py) });
                }
                foreach (var l in links)
                {
                    char t = hole.TileAt(l[0], l[1]);
                    if (t == '#' || t == 'w' || t == 'o' || t == ' ') continue;
                    if (seen[l[1], l[0]] != -1) continue;
                    seen[l[1], l[0]] = seen[y, x] + 1;
                    queue.Enqueue(new[] { l[0], l[1] });
                }
            }
            return seen;
        }
    }
}
