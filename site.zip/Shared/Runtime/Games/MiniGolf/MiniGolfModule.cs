using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.MiniGolf
{
    /// <summary>
    /// Mini Golf: two to four players play nine holes on one of four courses (36 different holes in all).
    /// Everybody plays at the same time: whenever your ball has stopped you can aim, pull back for power and
    /// let go. Balls bump each other, so a ball that gets in your way can be knocked off line (or into the
    /// water) and you can be bumped too. Fewest strokes after nine holes wins. Water costs a stroke when it
    /// was your own shot and sends the ball back to where it was. Eight strokes and the ball is picked up;
    /// a hole never lasts more than three minutes.
    ///
    /// This game runs in real time. Instead of turns, the server sends one <see cref="MiniGolfTick"/> action every
    /// tenth of a second, carrying everyone's latest controls.
    ///
    /// Options read from <see cref="MatchConfig.Options"/>: "course" = "0".."3", or "random" (default).
    /// </summary>
    public sealed class MiniGolfModule : GameModule<MiniGolfState, MiniGolfTick, MiniGolfView>
    {
        public const string GameId = "mini-golf";

        public const int TickMs = 100;
        public const int HoleOverMs = 9000;
        public const int HoleLimitMs = 180000;

        public static readonly GameInfo Definition =
            new GameInfo(GameId, "Mini Golf", 2, MiniGolfRules.MaxPlayers, GameStatus.Playable, "mini-golf");

        private static readonly IReadOnlyList<int> NoSeats = Array.Empty<int>();
        private const double StepMs = MiniGolfRules.Dt * 1000.0;

        public override GameInfo Info => Definition;

        protected override MiniGolfState CreateInitialState(MatchConfig config)
        {
            string chosen = config.GetOption("course", "random");
            int course;
            if (!int.TryParse(chosen, out course) || course < 0 || course >= MiniGolfCourses.All.Length)
                course = new SeededRandom(config.Seed).NextInt(MiniGolfCourses.All.Length);
            var state = new MiniGolfState(config.PlayerCount, course);
            StartHole(state, 0);
            return state;
        }

        private static void StartHole(MiniGolfState s, int hole)
        {
            var h = MiniGolfCourses.All[s.Course][hole];
            s.Hole = hole;
            s.Phase = GolfPhase.Play;
            s.TimeMs = 0;
            s.OverMs = 0;
            for (int p = 0; p < s.PlayerCount; p++)
            {
                var old = s.Balls[p];
                // shots already sent stay used up, even on the next hole
                s.Balls[p] = new GolfBall
                {
                    X = h.TeeX + MiniGolfRules.TeeOffsets[p][0], Y = h.TeeY + MiniGolfRules.TeeOffsets[p][1],
                    LastSeq = old.LastSeq, Mode = BallMode.Rest
                };
                s.Balls[p].Ox = s.Balls[p].X; s.Balls[p].Oy = s.Balls[p].Y;
            }
        }

        public override ValidationResult Validate(MiniGolfState state, int seat, MiniGolfTick action)
        {
            if (state == null) return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no course.");
            if (action == null || action.Inputs == null || action.Inputs.Length != state.PlayerCount || action.DtMs < 0)
                return ValidationResult.Fail(ErrorCodes.InvalidAction, "That isn't a valid tick.");
            if (state.IsOver) return ValidationResult.Fail(ErrorCodes.GameOver, "The round is over.");
            return ValidationResult.Success;
        }

        protected override MiniGolfState ApplyValidated(MiniGolfState state, int seat, MiniGolfTick tick)
        {
            var s = state.Clone();
            s.TickId = state.TickId + 1;

            if (s.Phase == GolfPhase.HoleOver)
            {
                s.OverMs += tick.DtMs;
                bool skip = false;
                for (int p = 0; p < s.PlayerCount; p++)
                {
                    var inp = tick.Inputs[p];
                    if (inp == null || !inp.Next || inp.Seq <= s.Balls[p].LastSeq) continue;
                    s.Balls[p].LastSeq = inp.Seq;   // a "next" counts once, like a shot
                    skip = true;
                }
                if (s.OverMs >= HoleOverMs || skip)
                {
                    if (s.Hole + 1 >= MiniGolfRules.HolesPerCourse) s.Phase = GolfPhase.Over;
                    else StartHole(s, s.Hole + 1);
                }
                return s;
            }

            var hole = s.CurrentHole;
            var balls = s.Balls;

            // new hits: only a ball that is lying still can be hit, and each shot (Seq) counts once
            for (int p = 0; p < balls.Length; p++)
            {
                var inp = tick.Inputs[p];
                var b = balls[p];
                if (inp == null || inp.Next || inp.Seq <= b.LastSeq) continue;
                b.LastSeq = inp.Seq;
                if (b.Mode != BallMode.Rest) continue;
                if (double.IsNaN(inp.Angle) || double.IsInfinity(inp.Angle) || double.IsNaN(inp.Power) || double.IsInfinity(inp.Power) || inp.Power < 0.03) continue;
                double speed = MiniGolfRules.MaxSpeed * Math.Min(1.0, inp.Power);
                b.Vx = Math.Cos(inp.Angle) * speed; b.Vy = Math.Sin(inp.Angle) * speed;
                b.Ox = b.X; b.Oy = b.Y;
                b.Own = true; b.Strokes++; b.Mode = BallMode.Roll; b.PortalCell = -1;
                s.Events.Add(new GolfEvent("hit", p, b.X, b.Y));
            }

            int steps = Math.Max(1, (int)Math.Round(tick.DtMs / StepMs));
            var rolling = new bool[balls.Length];
            var trails = new List<double>[balls.Length];
            for (int p = 0; p < balls.Length; p++) { rolling[p] = balls[p].Mode == BallMode.Roll; trails[p] = new List<double>(); }
            var body = new MiniGolfRules.Body();

            for (int i = 0; i < steps; i++)
            {
                for (int p = 0; p < balls.Length; p++)
                {
                    var b = balls[p];
                    if (b.Mode != BallMode.Roll) continue;
                    body.X = b.X; body.Y = b.Y; body.Vx = b.Vx; body.Vy = b.Vy; body.PortalCell = b.PortalCell; body.Bounced = false;
                    var r = MiniGolfRules.StepBall(hole, body);
                    b.X = body.X; b.Y = body.Y; b.Vx = body.Vx; b.Vy = body.Vy; b.PortalCell = body.PortalCell;
                    switch (r)
                    {
                        case MiniGolfRules.StepEnd.Stopped:
                            b.Mode = BallMode.Rest; b.Own = false;
                            PickUpIfSpent(b);
                            break;
                        case MiniGolfRules.StepEnd.Water:
                            var splash = new GolfEvent("splash", p, b.X, b.Y) { Pen = b.Own };
                            s.Events.Add(splash);
                            if (b.Own) b.Strokes++;
                            b.X = b.Ox; b.Y = b.Oy; b.Vx = 0; b.Vy = 0; b.Mode = BallMode.Rest; b.Own = false; b.PortalCell = -1;
                            PickUpIfSpent(b);
                            break;
                        case MiniGolfRules.StepEnd.Sunk:
                            b.Mode = BallMode.Sunk; b.Vx = 0; b.Vy = 0;
                            s.Events.Add(new GolfEvent("sunk", p, b.X, b.Y));
                            break;
                    }
                    if (body.Bounced) s.Events.Add(new GolfEvent("wall", p, b.X, b.Y));
                }
                Collide(s);
                if ((i + 1) % MiniGolfRules.SampleEvery == 0)
                {
                    for (int p = 0; p < balls.Length; p++)
                    {
                        if (!rolling[p] && balls[p].Mode != BallMode.Roll) continue;
                        trails[p].Add(Math.Round(balls[p].X, 2)); trails[p].Add(Math.Round(balls[p].Y, 2));
                    }
                }
            }
            // a ball that stopped during this tick ends its trail on the exact spot where it lies
            for (int p = 0; p < balls.Length; p++)
            {
                if ((rolling[p] || trails[p].Count > 0) && balls[p].Mode != BallMode.Roll)
                {
                    trails[p].Add(Math.Round(balls[p].X, 2)); trails[p].Add(Math.Round(balls[p].Y, 2));
                }
                s.Trails[p] = trails[p].ToArray();
            }

            s.TimeMs += tick.DtMs;
            if (s.TimeMs >= HoleLimitMs)
            {
                foreach (var b in balls)
                {
                    if (!b.Live) continue;
                    b.Mode = BallMode.Out; b.GaveUp = true; b.Vx = 0; b.Vy = 0;
                    b.Strokes = Math.Min(MiniGolfRules.MaxStrokes, b.Strokes + 2);
                }
            }
            bool anyLive = false;
            foreach (var b in balls) if (b.Live) anyLive = true;
            if (!anyLive)
            {
                s.Phase = GolfPhase.HoleOver;
                s.OverMs = 0;
                var row = new int[balls.Length];
                for (int p = 0; p < row.Length; p++) row[p] = balls[p].Strokes;
                s.Scores.Add(row);
            }
            return s;
        }

        /// <summary>A ball that stopped after its last allowed stroke is picked up.</summary>
        private static void PickUpIfSpent(GolfBall b)
        {
            if (b.Strokes >= MiniGolfRules.MaxStrokes)
            {
                b.Mode = BallMode.Out; b.GaveUp = true; b.Strokes = MiniGolfRules.MaxStrokes;
            }
        }

        /// <summary>
        /// Balls that overlap bump: they push apart and swap speed along the line between them (a bit lively),
        /// and a ball that was lying still starts rolling.
        /// </summary>
        private static void Collide(MiniGolfState s)
        {
            var balls = s.Balls;
            double min = MiniGolfRules.BallRadius * 2.0;
            for (int i = 0; i < balls.Length; i++)
            {
                for (int j = i + 1; j < balls.Length; j++)
                {
                    var a = balls[i]; var c = balls[j];
                    if (!a.Live || !c.Live) continue;
                    double dx = c.X - a.X, dy = c.Y - a.Y;
                    double d = Math.Sqrt(dx * dx + dy * dy);
                    if (d >= min) continue;
                    if (d < 1e-6) { dx = 1.0; dy = 0.0; d = 1.0; }
                    double nx = dx / d, ny = dy / d, push = (min - d) / 2.0;
                    int by = Math.Sqrt(a.Vx * a.Vx + a.Vy * a.Vy) >= Math.Sqrt(c.Vx * c.Vx + c.Vy * c.Vy) ? i : j;
                    a.X -= nx * push; a.Y -= ny * push; c.X += nx * push; c.Y += ny * push;
                    double rv = (c.Vx - a.Vx) * nx + (c.Vy - a.Vy) * ny;   // negative = coming together
                    if (rv >= 0.0) continue;
                    double j2 = -(1.0 + MiniGolfRules.BallBounce) * rv / 2.0;
                    a.Vx -= j2 * nx; a.Vy -= j2 * ny; c.Vx += j2 * nx; c.Vy += j2 * ny;
                    foreach (var q in new[] { a, c })
                    {
                        if (q.Mode == BallMode.Rest && Math.Sqrt(q.Vx * q.Vx + q.Vy * q.Vy) > MiniGolfRules.StopSpeed)
                        {
                            q.Mode = BallMode.Roll; q.Ox = q.X; q.Oy = q.Y; q.Own = false; q.PortalCell = -1;
                        }
                    }
                    s.Events.Add(new GolfEvent("bump", -1, (a.X + c.X) / 2.0, (a.Y + c.Y) / 2.0) { A = i, B = j, By = by });
                }
            }
        }

        public override MiniGolfView ViewFor(MiniGolfState state, int seat) => new MiniGolfView(state, seat);

        public override MatchResult Result(MiniGolfState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            if (!state.IsOver) return MatchResult.InProgress;
            var totals = state.Totals();
            int best = int.MaxValue;
            foreach (int t in totals) best = Math.Min(best, t);
            var winners = new List<int>();
            for (int i = 0; i < totals.Length; i++) if (totals[i] == best) winners.Add(i);
            return MatchResult.Win(winners.ToArray());
        }

        /// <summary>Everyone plays at once, so every seat whose ball is still in play acts every tick.</summary>
        public override IReadOnlyList<int> SeatsToAct(MiniGolfState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            if (state.IsOver) return NoSeats;
            var seats = new List<int>();
            for (int p = 0; p < state.PlayerCount; p++) seats.Add(p);
            return seats;
        }
    }
}
