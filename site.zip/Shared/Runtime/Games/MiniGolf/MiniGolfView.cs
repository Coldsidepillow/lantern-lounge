using System.Collections.Generic;

namespace LanternLounge.Games.MiniGolf
{
    public sealed class GolfBallView
    {
        public double X { get; set; }
        public double Y { get; set; }
        /// <summary>"rest", "roll", "sunk" or "out" (picked up).</summary>
        public string State { get; set; }
        public int Strokes { get; set; }
        public bool GaveUp { get; set; }
        /// <summary>Where this ball went during the last tick: x, y, x, y ...</summary>
        public double[] Trail { get; set; }
    }

    /// <summary>Mini golf hides nothing: everyone sees every ball and every score.</summary>
    public sealed class MiniGolfView
    {
        internal MiniGolfView(MiniGolfState s, int seat)
        {
            You = seat;
            Course = s.Course;
            CourseName = MiniGolfCourses.CourseNames[s.Course];
            Hole = s.Hole;
            HoleCount = MiniGolfRules.HolesPerCourse;
            Phase = s.Phase == GolfPhase.Play ? "play" : s.Phase == GolfPhase.HoleOver ? "holeover" : "over";
            PlayerCount = s.PlayerCount;
            var h = s.CurrentHole;
            HoleName = h.Name;
            Par = h.Par;
            Map = h.Rows;
            Tee = new[] { h.TeeX, h.TeeY };
            Cup = new[] { h.HoleX, h.HoleY };
            Balls = new GolfBallView[s.PlayerCount];
            for (int i = 0; i < Balls.Length; i++)
            {
                var b = s.Balls[i];
                Balls[i] = new GolfBallView
                {
                    X = System.Math.Round(b.X, 2), Y = System.Math.Round(b.Y, 2),
                    State = b.Mode == BallMode.Rest ? "rest" : b.Mode == BallMode.Roll ? "roll" : b.Mode == BallMode.Sunk ? "sunk" : "out",
                    Strokes = b.Strokes, GaveUp = b.GaveUp, Trail = s.Trails[i]
                };
            }
            Scores = new List<int[]>(s.Scores);
            Pars = new int[MiniGolfRules.HolesPerCourse];
            for (int i = 0; i < Pars.Length; i++) Pars[i] = MiniGolfCourses.All[s.Course][i].Par;
            Totals = s.Totals();
            Tick = s.TickId;
            Events = s.Events.ToArray();
        }

        public int You { get; }
        public int Course { get; }
        public string CourseName { get; }
        public int Hole { get; }
        public int HoleCount { get; }
        public string Phase { get; }
        public int PlayerCount { get; }
        public string HoleName { get; }
        public int Par { get; }
        public string[] Map { get; }
        public double[] Tee { get; }
        public double[] Cup { get; }
        public GolfBallView[] Balls { get; }
        public List<int[]> Scores { get; }
        public int[] Pars { get; }
        public int[] Totals { get; }
        public int Tick { get; }
        public GolfEvent[] Events { get; }
    }
}
