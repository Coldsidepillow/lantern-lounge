using System;
using System.Collections.Generic;

namespace LanternLounge.Games.MiniGolf
{
    public enum GolfPhase { Play, HoleOver, Over }

    public enum BallMode { Rest, Roll, Sunk, Out }

    /// <summary>One player's controls: a new shot (a higher Seq than last time) or "Next" to skip the scorecard.</summary>
    public sealed class GolfInput
    {
        public GolfInput(int seq, double angle, double power, bool next)
        {
            Seq = seq; Angle = angle; Power = power; Next = next;
        }

        public int Seq { get; }
        public double Angle { get; }
        public double Power { get; }
        public bool Next { get; }
    }

    /// <summary>The server's clock: 100 ms of game time, with everyone's latest controls (null where a seat has none).</summary>
    public sealed class MiniGolfTick
    {
        public MiniGolfTick(int dtMs, GolfInput[] inputs) { DtMs = dtMs; Inputs = inputs; }
        public int DtMs { get; }
        public GolfInput[] Inputs { get; }
    }

    /// <summary>Something that happened during a tick, so the website can play a sound or splash.</summary>
    public sealed class GolfEvent
    {
        public GolfEvent(string kind, int seat, double x, double y) { K = kind; Seat = seat; X = x; Y = y; A = -1; B = -1; By = -1; }
        /// <summary>"hit", "wall", "bump", "splash" or "sunk".</summary>
        public string K { get; }
        public int Seat { get; }
        public double X { get; }
        public double Y { get; }
        public int A { get; internal set; }
        public int B { get; internal set; }
        public int By { get; internal set; }
        public bool Pen { get; internal set; }
    }

    public sealed class GolfBall
    {
        public double X, Y, Vx, Vy;
        public double Ox, Oy;                 // where it was when it was last hit: a splash puts it back here
        public BallMode Mode;
        public bool Own;                      // true while it is rolling from its owner's own shot
        public int Strokes;
        public bool GaveUp;
        public int LastSeq;
        public int PortalCell = -1;
        public bool Bounced;

        public GolfBall Copy() => (GolfBall)MemberwiseClone();
        public bool Live => Mode == BallMode.Rest || Mode == BallMode.Roll;
    }

    /// <summary>The whole round. Read-only outside <see cref="MiniGolfModule"/>, which copies it before each tick.</summary>
    public sealed class MiniGolfState
    {
        internal MiniGolfState(int playerCount, int course)
        {
            PlayerCount = playerCount;
            Course = course;
            Balls = new GolfBall[playerCount];
            Trails = new double[playerCount][];
            for (int i = 0; i < playerCount; i++) { Balls[i] = new GolfBall(); Trails[i] = Array.Empty<double>(); }
            Scores = new List<int[]>();
            Events = new List<GolfEvent>();
        }

        private MiniGolfState(MiniGolfState o)
        {
            PlayerCount = o.PlayerCount; Course = o.Course;
            Hole = o.Hole; Phase = o.Phase; TimeMs = o.TimeMs; OverMs = o.OverMs; TickId = o.TickId;
            Balls = new GolfBall[PlayerCount];
            Trails = new double[PlayerCount][];
            for (int i = 0; i < PlayerCount; i++) { Balls[i] = o.Balls[i].Copy(); Trails[i] = Array.Empty<double>(); }
            Scores = new List<int[]>(o.Scores);
            Events = new List<GolfEvent>();
        }

        public int PlayerCount { get; }
        public int Course { get; }
        public int Hole { get; internal set; }
        public GolfPhase Phase { get; internal set; }
        public int TimeMs { get; internal set; }
        public int OverMs { get; internal set; }
        public int TickId { get; internal set; }
        public GolfBall[] Balls { get; }
        /// <summary>Where each ball went during the last tick (x, y, x, y ...), so the website can roll it smoothly.</summary>
        public double[][] Trails { get; }
        public List<GolfEvent> Events { get; }
        /// <summary>Strokes per player for each finished hole.</summary>
        public List<int[]> Scores { get; }

        public bool IsOver => Phase == GolfPhase.Over;
        public MiniGolfHole CurrentHole => MiniGolfCourses.All[Course][Hole];

        internal MiniGolfState Clone() => new MiniGolfState(this);

        public int[] Totals()
        {
            var t = new int[PlayerCount];
            foreach (var row in Scores) for (int i = 0; i < PlayerCount; i++) t[i] += row[i];
            return t;
        }
    }
}
