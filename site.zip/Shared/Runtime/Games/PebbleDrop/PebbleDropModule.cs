using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.PebbleDrop
{
    /// <summary>
    /// Pebble Drop: two to five players (Red, Yellow, Blue, Green, Purple) take turns dropping pebbles into a
    /// 16-column, 12-row board. The first to line up four of their own pebbles across, up and
    /// down, or on either slant wins. A full board with no line is a draw.
    ///
    /// Options read from <see cref="MatchConfig.Options"/>:
    ///   "firstSeat" = "0".."4", or "random" (default; uses the match seed).
    /// </summary>
    public sealed class PebbleDropModule : GameModule<PebbleDropState, DropAction, PebbleDropState>
    {
        public const string GameId = "pebble-drop";

        public const string ColumnOutOfRange = "column_out_of_range";
        public const string ColumnFull = "column_full";

        public static readonly GameInfo Definition =
            new GameInfo(GameId, "Pebble Drop", PebbleDropState.MinPlayerCount, PebbleDropState.Players, GameStatus.Playable, "pebble-drop");

        // Centre columns first: the order both the timeout and the bot fall back to.
        internal static readonly int[] CentreFirst = BuildCentreFirst();

        public static readonly string[] ColorNames = { "Red", "Yellow", "Blue", "Green", "Purple" };

        private static int[] BuildCentreFirst()
        {
            var order = new int[PebbleDropState.Columns];
            int left = PebbleDropState.Columns / 2 - 1, right = left + 1, i = 0;
            while (i < order.Length)
            {
                if (right < PebbleDropState.Columns) order[i++] = right++;
                if (left >= 0 && i < order.Length) order[i++] = left--;
            }
            return order;
        }

        private static readonly IReadOnlyList<int> NoSeats = Array.Empty<int>();

        public override GameInfo Info => Definition;

        protected override PebbleDropState CreateInitialState(MatchConfig config)
        {
            int players = Math.Max(PebbleDropState.MinPlayerCount, Math.Min(PebbleDropState.Players, config.PlayerCount));
            string first = config.GetOption("firstSeat", "random");
            if (!int.TryParse(first, out int seat) || seat < 0 || seat >= players)
            {
                seat = new SeededRandom(config.Seed).NextInt(players);
            }
            return PebbleDropState.CreateEmpty(seat, players);
        }

        /// <summary>A fresh board for a rematch; the next player round the table moves first.</summary>
        public PebbleDropState Rematch(PebbleDropState previous)
        {
            if (previous == null) throw new ArgumentNullException(nameof(previous));
            return PebbleDropState.CreateEmpty(NextSeat(previous.FirstSeat, previous.PlayerCount), previous.PlayerCount);
        }

        /// <summary>A fresh board with a chosen first player (Reset).</summary>
        public PebbleDropState NewBoard(int firstSeat, int playerCount)
        {
            if (playerCount < PebbleDropState.MinPlayerCount || playerCount > PebbleDropState.Players) throw new ArgumentOutOfRangeException(nameof(playerCount));
            if (firstSeat < 0 || firstSeat >= playerCount) throw new ArgumentOutOfRangeException(nameof(firstSeat));
            return PebbleDropState.CreateEmpty(firstSeat, playerCount);
        }

        public static int NextSeat(int seat, int playerCount) => (seat + 1) % playerCount;

        public override ValidationResult Validate(PebbleDropState state, int seat, DropAction action)
        {
            if (state == null) return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no board.");
            if (state.IsOver) return ValidationResult.Fail(ErrorCodes.GameOver, "This match is already over.");
            if (seat < 0 || seat >= state.PlayerCount) return ValidationResult.Fail(ErrorCodes.BadSeat, "That seat isn't playing this match.");
            if (seat != state.CurrentSeat) return ValidationResult.Fail(ErrorCodes.NotYourTurn, "It isn't your turn yet.");
            if (action.Column < 0 || action.Column >= PebbleDropState.Columns)
                return ValidationResult.Fail(ColumnOutOfRange, "Pick one of the 16 columns.");
            if (state.IsColumnFull(action.Column))
                return ValidationResult.Fail(ColumnFull, "That column is full. Pick another one.");
            return ValidationResult.Success;
        }

        protected override PebbleDropState ApplyValidated(PebbleDropState state, int seat, DropAction action)
        {
            int[] cells = state.CopyCells();
            int row = PebbleDropRules.LandingRow(cells, action.Column);
            int index = PebbleDropState.Index(row, action.Column);
            cells[index] = seat;

            int[] line = PebbleDropRules.FindLine(cells, row, action.Column, seat);
            int moves = state.MoveCount + 1;
            bool won = line != null;
            bool draw = !won && moves == PebbleDropState.CellCount;
            int next = won || draw ? PebbleDropState.NoSeat : NextSeat(seat, state.PlayerCount);

            return new PebbleDropState(
                cells,
                state.FirstSeat,
                next,
                moves,
                won ? seat : PebbleDropState.NoSeat,
                line,
                draw,
                index,
                state.PlayerCount);
        }

        /// <summary>Nothing is hidden in Pebble Drop, so every seat sees the whole board.</summary>
        public override PebbleDropState ViewFor(PebbleDropState state, int seat) => state;

        public override MatchResult Result(PebbleDropState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            if (state.Winner != PebbleDropState.NoSeat) return MatchResult.Win(state.Winner);
            if (state.IsDraw) return MatchResult.Draw();
            return MatchResult.InProgress;
        }

        public override IReadOnlyList<int> SeatsToAct(PebbleDropState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? NoSeats : new[] { state.CurrentSeat };
        }

        /// <summary>When a turn timer runs out, the pebble goes into the centre-most open column.</summary>
        public override bool TryGetTimeoutAction(PebbleDropState state, int seat, out DropAction action)
        {
            action = default;
            if (state == null || state.IsOver || seat != state.CurrentSeat) return false;
            foreach (int column in CentreFirst)
            {
                if (!state.IsColumnFull(column))
                {
                    action = new DropAction(column);
                    return true;
                }
            }
            return false;
        }
    }
}
