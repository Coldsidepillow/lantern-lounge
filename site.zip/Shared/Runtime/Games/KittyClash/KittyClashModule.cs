using System;
using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.KittyClash
{
    /// <summary>What a player can do: flip one face-down card (Card 0 to 39).</summary>
    public readonly struct KittyClashAction
    {
        public KittyClashAction(int card) { Card = card; }
        public int Card { get; }
        public static KittyClashAction Flip(int card) => new KittyClashAction(card);
    }

    /// <summary>
    /// Kitty Clash: a memory match with 20 pairs of cats. On your turn flip two cards. If they match you keep the pair
    /// and flip again. If not, they stay face up for a moment so everyone can study them, then flip back over and the
    /// next player goes. Most pairs wins. Options: "firstSeat" = "0".."3", or "random" (default).
    /// </summary>
    public sealed class KittyClashModule : GameModule<KittyClashState, KittyClashAction, KittyClashView>
    {
        public const string GameId = "kitty-clash";

        public static readonly GameInfo Definition =
            new GameInfo(GameId, "Kitty Clash", 2, KittyClashRules.MaxPlayers, GameStatus.Playable, "kitty-clash");

        private static readonly IReadOnlyList<int> NoSeats = Array.Empty<int>();

        public override GameInfo Info => Definition;

        protected override KittyClashState CreateInitialState(MatchConfig config)
        {
            var random = new SeededRandom(config.Seed ^ 0x5DEECE66DUL);
            int players = Math.Max(1, Math.Min(KittyClashRules.MaxPlayers, config.PlayerCount));
            string first = config.GetOption("firstSeat", "random");
            if (!int.TryParse(first, out int seat) || seat < 0 || seat >= players) seat = random.NextInt(players);
            return KittyClashState.CreateNew(config.Seed, players, seat);
        }

        public override ValidationResult Validate(KittyClashState state, int seat, KittyClashAction action)
        {
            if (state == null) return ValidationResult.Fail(ErrorCodes.InvalidAction, "There is no table.");
            if (state.IsOver) return ValidationResult.Fail(ErrorCodes.GameOver, "This game is already over.");
            if (seat < 0 || seat >= state.Players) return ValidationResult.Fail(ErrorCodes.BadSeat, "That seat isn't playing.");
            if (seat != state.CurrentSeat) return ValidationResult.Fail(ErrorCodes.NotYourTurn, "It isn't your turn yet.");
            if (action.Card < 0 || action.Card >= KittyClashRules.Cards) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Pick one of the cards.");
            if (state.Owner[action.Card] != KittyClashRules.NoSeat) return ValidationResult.Fail(ErrorCodes.InvalidAction, "That pair is already taken.");
            if (action.Card == state.First) return ValidationResult.Fail(ErrorCodes.InvalidAction, "Pick a different card.");
            return ValidationResult.Success;
        }

        protected override KittyClashState ApplyValidated(KittyClashState state, int seat, KittyClashAction action)
        {
            int card = action.Card;
            var owner = (int[])state.Owner.Clone();
            var seen = (bool[])state.Seen.Clone();
            var scores = (int[])state.Scores.Clone();
            seen[card] = true;
            int actions = state.Actions + 1;
            int face = state.Faces[card];

            if (state.First == KittyClashRules.NoCard)
            {
                // First flip of the turn. Any old miss turns back over now.
                var ev = new KittyEvent(KittyKind.First, seat, card, face, KittyClashRules.NoCard, -1);
                return new KittyClashState(state.Faces, owner, seen, scores, card, KittyClashRules.NoCard, KittyClashRules.NoCard,
                    seat, state.Players, state.Seed, actions, ev);
            }

            int a = state.First, faceA = state.Faces[a];
            if (faceA == face)
            {
                owner[a] = seat; owner[card] = seat;
                scores[seat]++;
                var ev = new KittyEvent(KittyKind.Match, seat, a, faceA, card, face);
                // A match earns another turn.
                return new KittyClashState(state.Faces, owner, seen, scores, KittyClashRules.NoCard, KittyClashRules.NoCard, KittyClashRules.NoCard,
                    seat, state.Players, state.Seed, actions, ev);
            }
            else
            {
                var ev = new KittyEvent(KittyKind.Miss, seat, a, faceA, card, face);
                int next = (seat + 1) % state.Players;
                return new KittyClashState(state.Faces, owner, seen, scores, KittyClashRules.NoCard, a, card,
                    next, state.Players, state.Seed, actions, ev);
            }
        }

        /// <summary>Only what is face up. Cards nobody has flipped stay -1 for everyone.</summary>
        public override KittyClashView ViewFor(KittyClashState state, int seat)
        {
            var shown = new int[KittyClashRules.Cards];
            for (int i = 0; i < shown.Length; i++)
            {
                bool up = state.Owner[i] != KittyClashRules.NoSeat || i == state.First || i == state.MissA || i == state.MissB;
                shown[i] = up ? state.Faces[i] : -1;
            }
            return new KittyClashView(shown, state);
        }

        public override MatchResult Result(KittyClashState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            if (!state.IsOver) return MatchResult.InProgress;
            int best = 0;
            foreach (int s in state.Scores) best = Math.Max(best, s);
            var winners = new List<int>();
            for (int i = 0; i < state.Scores.Length; i++) if (state.Scores[i] == best) winners.Add(i);
            return winners.Count == state.Players ? MatchResult.Draw() : MatchResult.Win(winners.ToArray());
        }

        public override IReadOnlyList<int> SeatsToAct(KittyClashState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            return state.IsOver ? NoSeats : new[] { state.CurrentSeat };
        }

        /// <summary>If someone walks away, a random card still in play is flipped for them.</summary>
        public override bool TryGetTimeoutAction(KittyClashState state, int seat, out KittyClashAction action)
        {
            action = default;
            if (state == null || state.IsOver || seat != state.CurrentSeat) return false;
            int open = 0;
            for (int i = 0; i < KittyClashRules.Cards; i++) if (Pickable(state, i)) open++;
            if (open == 0) return false;
            int n = KittyClashRules.Pick(state.Seed, state.Actions, open);
            for (int i = 0; i < KittyClashRules.Cards; i++)
                if (Pickable(state, i) && n-- == 0) { action = KittyClashAction.Flip(i); return true; }
            return false;
        }

        private static bool Pickable(KittyClashState s, int i) => s.Owner[i] == KittyClashRules.NoSeat && i != s.First;
    }

    /// <summary>What every player is allowed to see.</summary>
    public sealed class KittyClashView
    {
        internal KittyClashView(int[] shown, KittyClashState s)
        {
            Cards = shown; Owner = s.Owner; Scores = s.Scores; First = s.First; MissA = s.MissA; MissB = s.MissB;
            CurrentSeat = s.CurrentSeat; Players = s.Players; Actions = s.Actions; PairsLeft = s.PairsLeft; Last = s.Last;
        }
        /// <summary>For each card: the cat showing (0 to 19), or -1 if face down.</summary>
        public int[] Cards { get; }
        public int[] Owner { get; }
        public int[] Scores { get; }
        public int First { get; }
        public int MissA { get; }
        public int MissB { get; }
        public int CurrentSeat { get; }
        public int Players { get; }
        public int Actions { get; }
        public int PairsLeft { get; }
        public KittyEvent Last { get; }
    }
}
