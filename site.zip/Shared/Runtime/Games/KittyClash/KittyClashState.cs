using System;

namespace LanternLounge.Games.KittyClash
{
    public enum KittyKind { None, First, Match, Miss }

    /// <summary>What the latest flip did, so screens can play it back. For First only A and FaceA are used.</summary>
    public readonly struct KittyEvent
    {
        public KittyEvent(KittyKind kind, int seat, int a, int faceA, int b, int faceB)
        {
            Kind = kind; Seat = seat; A = a; FaceA = faceA; B = b; FaceB = faceB;
        }
        public KittyKind Kind { get; }
        public int Seat { get; }
        public int A { get; }
        public int FaceA { get; }
        public int B { get; }
        public int FaceB { get; }
    }

    /// <summary>
    /// The whole table. Faces is the secret: nobody but the server may see a card's cat until it is flipped.
    /// Seen only ever grows and records which cards have been shown to everyone, so a bot can "remember" fairly.
    /// </summary>
    public sealed class KittyClashState
    {
        internal KittyClashState(int[] faces, int[] owner, bool[] seen, int[] scores, int first, int missA, int missB,
                                 int currentSeat, int players, ulong seed, int actions, KittyEvent last)
        {
            Faces = faces; Owner = owner; Seen = seen; Scores = scores; First = first; MissA = missA; MissB = missB;
            CurrentSeat = currentSeat; Players = players; Seed = seed; Actions = actions; Last = last;
        }

        internal static KittyClashState CreateNew(ulong seed, int players, int firstSeat)
        {
            var owner = new int[KittyClashRules.Cards];
            for (int i = 0; i < owner.Length; i++) owner[i] = KittyClashRules.NoSeat;
            return new KittyClashState(KittyClashRules.Deal(seed), owner, new bool[KittyClashRules.Cards], new int[players],
                KittyClashRules.NoCard, KittyClashRules.NoCard, KittyClashRules.NoCard, firstSeat, players, seed, 0, default);
        }

        public int[] Faces { get; }
        /// <summary>For each card: the seat that matched it, or -1 if it is still in play.</summary>
        public int[] Owner { get; }
        public bool[] Seen { get; }
        /// <summary>Pairs won by each seat.</summary>
        public int[] Scores { get; }
        /// <summary>The card flipped first this turn (waiting for a second), or -1.</summary>
        public int First { get; }
        /// <summary>The two cards of the last miss, still face up for everyone to study, or -1 when there is none.</summary>
        public int MissA { get; }
        public int MissB { get; }
        public int CurrentSeat { get; }
        public int Players { get; }
        public ulong Seed { get; }
        /// <summary>Counts every flip so screens can tell something new happened.</summary>
        public int Actions { get; }
        public KittyEvent Last { get; }

        public int PairsLeft
        {
            get { int sum = 0; foreach (int s in Scores) sum += s; return KittyClashRules.Pairs - sum; }
        }
        public bool IsOver => PairsLeft == 0;
    }
}
