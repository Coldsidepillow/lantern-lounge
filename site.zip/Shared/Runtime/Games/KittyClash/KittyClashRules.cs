using System;

namespace LanternLounge.Games.KittyClash
{
    /// <summary>The matching rules in one place: 40 cards, 20 cats, every cat on exactly two cards.</summary>
    public static class KittyClashRules
    {
        public const int Pairs = 20;
        public const int Cards = Pairs * 2;
        public const int MaxPlayers = 4;
        public const int NoCard = -1;
        public const int NoSeat = -1;

        /// <summary>Which cat is on each card position. The seed shuffles it, so nobody can peek at it before it is flipped.</summary>
        public static int[] Deal(ulong seed)
        {
            var faces = new int[Cards];
            for (int i = 0; i < Cards; i++) faces[i] = i / 2;
            var random = new LanternLounge.Core.SeededRandom(seed);
            for (int i = Cards - 1; i > 0; i--)
            {
                int j = random.NextInt(i + 1);
                int t = faces[i]; faces[i] = faces[j]; faces[j] = t;
            }
            return faces;
        }

        /// <summary>A cheap repeatable number from a seed and a counter (used for bots and timeouts).</summary>
        public static int Pick(ulong seed, int salt, int max)
        {
            unchecked
            {
                ulong z = seed + (ulong)(salt + 1) * 0x9E3779B97F4A7C15UL;
                z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
                z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
                z ^= z >> 31;
                return (int)(z % (ulong)max);
            }
        }
    }
}
