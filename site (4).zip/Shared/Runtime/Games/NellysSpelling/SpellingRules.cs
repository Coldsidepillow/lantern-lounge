using System;
using LanternLounge.Core;

namespace LanternLounge.Games.NellysSpelling
{
    public readonly struct SpellingWord
    {
        public SpellingWord(string word, string definition) { Word = word; Definition = definition; }
        public string Word { get; }
        public string Definition { get; }
        /// <summary>The letters to type: lower case, no spaces ("free verse" is nine letters).</summary>
        public string Letters => Word.Replace(" ", "").ToLowerInvariant();
        /// <summary>How many letters come before the space in a two-word answer, or -1 for a single word.</summary>
        public int GapAfter => Word.IndexOf(' ');
    }

    /// <summary>The word list and the few fixed numbers. Seat 0 spells; the other seats only watch.</summary>
    public static class SpellingRules
    {
        public const int Seats = 4;
        public const int Speller = 0;
        public const int MaxTries = 6;

        public static readonly SpellingWord[] Words =
        {
            new SpellingWord("imagine", "picture something in your mind"),
            new SpellingWord("bounce", "spring back after hitting something"),
            new SpellingWord("inventor", "a person who creates something for the first time"),
            new SpellingWord("observer", "someone who watches something"),
            new SpellingWord("alliteration", "several words or syllables in a row start with the same sound"),
            new SpellingWord("free verse", "poem in which some verses rhyme and some do not"),
            new SpellingWord("limerick", "a funny poem of five lines with a specific rhyme pattern"),
            new SpellingWord("rhyme", "when words end with the same sound"),
        };

        /// <summary>The order the words come in this match (shuffled by the seed, so every game is a little different).</summary>
        public static int[] Order(ulong seed)
        {
            var random = new SeededRandom(seed);
            int[] order = new int[Words.Length];
            for (int i = 0; i < order.Length; i++) order[i] = i;
            for (int i = order.Length - 1; i > 0; i--)
            {
                int j = random.NextInt(i + 1);
                int t = order[i]; order[i] = order[j]; order[j] = t;
            }
            return order;
        }
    }
}
