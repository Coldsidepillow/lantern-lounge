using System;

namespace LanternLounge.Games.NellysSpelling
{
    public enum SpellingPhase { Define = 0, Spell = 1, Result = 2, Done = 3 }

    /// <summary>
    /// Where the spelling test is: which word, whether the definition is showing, the tries so far and what is typed now.
    /// Only the speller's screen needs to act on it; everyone else gets the same picture so they can watch.
    /// </summary>
    public sealed class SpellingState
    {
        internal SpellingState() { }

        internal static SpellingState CreateNew(ulong seed) => new SpellingState
        {
            Order = SpellingRules.Order(seed),
            Phase = SpellingPhase.Define,
            ShowDef = true,
            Rows = Array.Empty<string>(),
            Current = "",
            Results = new int[SpellingRules.Words.Length]
        };

        public int[] Order { get; internal set; }
        public int Index { get; internal set; }
        public SpellingPhase Phase { get; internal set; }
        /// <summary>True while the definition is on the speller's screen.</summary>
        public bool ShowDef { get; internal set; }
        /// <summary>The tries made on this word (all wrong, except the last one if it was right).</summary>
        public string[] Rows { get; internal set; }
        public string Current { get; internal set; }
        /// <summary>0 not finished, 1 spelled it, 2 ran out of tries.</summary>
        public int Outcome { get; internal set; }
        /// <summary>Per word in play order: 0 not yet, 1 right, 2 missed.</summary>
        public int[] Results { get; internal set; }
        /// <summary>Counts every accepted action so screens can tell something new happened.</summary>
        public int Events { get; internal set; }

        public bool IsOver => Phase == SpellingPhase.Done;
        public SpellingWord Word => SpellingRules.Words[Order[Index]];

        public int Correct
        {
            get { int n = 0; foreach (int r in Results) if (r == 1) n++; return n; }
        }

        internal SpellingState Copy() => (SpellingState)MemberwiseClone();
    }
}
