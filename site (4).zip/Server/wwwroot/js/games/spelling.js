// Unit 2, week 5 spelling online: a one-player spelling test that looks like Wordle (pink, white, purple and black).
// Each word shows its definition first, then the spelling grid comes up. Six tries, no letter hints, and the
// definition can be opened again at any time. One person spells (seat 0); everyone else who joins just watches.
import { h } from "../ui.js";

const KEY_ROWS = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];

export default {
  id: "nellys-spelling",
  name: "Unit 2, week 5 spelling",
  theme: "theme-spelling",
  hideSeats: false,
  artClass: "art-spelling",
  art: () => [h("span.sp-art-text", "Unit 2, week 5 spelling")],
  create
};

function create(area, api) {
  let room = null, view = null, destroyed = false;
  let lastEvents = -1, lastMatch = -1, lastWord = -1, lastRows = 0, freshMiss = false, lastPhase = "";
  const root = h("div.sp-wrap");
  area.replaceChildren(root);
  const confetti = h("div.sp-confetti");
  area.appendChild(confetti);

  const speller = () => api.you === 0;
  const playing = () => room && room.status === "playing" && view && view.phase !== "done";
  const canType = () => speller() && playing() && view.phase === "spell" && !view.showDef;
  const nameOf = () => api.seatName(0);
  const snd = (n) => { try { api.sound && api.sound[n] && api.sound[n](); } catch (e) { /* ignore */ } };

  // ----- things the speller can do -----
  const send = (move) => { if (speller() && playing()) api.send(move); };
  function typeLetter(ch) {
    if (!canType() || view.current.length >= view.length) return;
    api.sendQuiet({ kind: "letter", ch: ch.toLowerCase() });
    snd("tap");
  }
  function backspace() { if (canType() && view.current.length > 0) api.sendQuiet({ kind: "back" }); }
  function shakeRow() {
    const cur = root.querySelector(".sp-row.cur");
    if (cur) { cur.classList.remove("nope"); void cur.offsetWidth; cur.classList.add("nope"); }
  }
  // The server checks the row (an unfinished row is refused with a message); a stale screen can't block a quick Enter.
  function enter() { if (canType()) api.send({ kind: "enter" }); }

  // ----- the grid -----
  function rowEl(text, kind, n, gap, extra) {
    const cols = [];
    const cells = [];
    for (let i = 0; i < n; i++) {
      if (i === gap) { cols.push("minmax(0, 0.5fr)"); cells.push(h("span.sp-gap")); }
      cols.push("minmax(0, 1fr)");
      const ch = text ? text[i] : "";
      cells.push(h("span.sp-box" + (ch ? ".has" : ""), ch ? ch.toUpperCase() : ""));
    }
    const max = n * 60 + (n - 1) * 5 + (gap >= 0 ? 22 : 0);
    return h("div.sp-row." + kind + (extra ? "." + extra : ""), { style: { gridTemplateColumns: cols.join(" "), maxWidth: max + "px", "--n": String(n) } }, cells);
  }

  function grid() {
    const v = view, n = v.length, rows = [];
    const lastIsRight = v.phase === "result" && v.outcome === "correct";
    v.rows.forEach((t, i) => {
      const right = lastIsRight && i === v.rows.length - 1;
      rows.push(rowEl(t, right ? "ok" : "miss", n, v.gap, !right && freshMiss && i === v.rows.length - 1 ? "fresh" : ""));
    });
    if (v.phase === "spell") rows.push(rowEl(v.current, "cur", n, v.gap));
    while (rows.length < v.maxTries) rows.push(rowEl("", "empty", n, v.gap));
    return h("div.sp-grid", rows);
  }

  // ----- the keyboard -----
  function keyboard() {
    const key = (label, fn, cls) => h("button.sp-key" + (cls ? "." + cls : ""), { type: "button", onclick: fn, "aria-label": cls === "back" ? "Backspace" : label }, label);
    const letter = (c) => key(c, () => typeLetter(c));
    return h("div.sp-kb",
      h("div.sp-kbrow", [...KEY_ROWS[0]].map(letter)),
      h("div.sp-kbrow", h("span.sp-half"), [...KEY_ROWS[1]].map(letter), h("span.sp-half")),
      h("div.sp-kbrow", key("ENTER", enter, "wide"), [...KEY_ROWS[2]].map(letter), key("⌫", backspace, "wide.back")));
  }

  // ----- the screens -----
  function header() {
    const v = view;
    const help = v.phase === "spell" && speller() && !v.showDef
      ? h("button.sp-help", { type: "button", "aria-label": "Show the definition", onclick: () => send({ kind: "define" }) }, h("span.sp-q", "?"), h("span.sp-help-t", "Definition"))
      : h("span.sp-help.ghost");
    return h("div.sp-head", help, h("div.sp-title", "Unit 2, week 5 spelling"),
      h("div.sp-count", v.phase === "done" ? "Done" : `Word ${v.index + 1}/${v.total}`));
  }

  function defCard(button) {
    return h("div.sp-card",
      h("div.sp-pill", "DEFINITION"),
      h("div.sp-def", view.definition),
      button);
  }

  function watchNote(text) { return h("div.sp-watch", text); }

  function resultPanel() {
    const v = view, last = v.index + 1 >= v.total;
    const btn = speller()
      ? h("button.sp-btn", { type: "button", onclick: () => send({ kind: "next" }) }, last ? "See my score" : "Next word")
      : watchNote(`Waiting for ${nameOf()}...`);
    if (v.outcome === "correct") {
      return h("div.sp-result.ok", h("div.sp-yay", "Good Job Nelly!"), h("div.sp-sub", `You spelled ${v.word}`), btn);
    }
    return h("div.sp-result.missed", h("div.sp-sub", "Not this time. The word is"), h("div.sp-word", v.word), btn);
  }

  function donePanel() {
    const v = view, all = v.correct === v.total;
    return h("div.sp-card.done",
      h("div.sp-yay", all ? "Good Job Nelly!" : "All done!"),
      h("div.sp-sub", `${v.correct} of ${v.total} spelled right`),
      h("div.sp-list", v.summary.map(x => h("div.sp-item" + (x.ok ? ".ok" : ".no"), h("span.sp-mark", x.ok ? "✓" : "✗"), x.word))));
  }

  function paint() {
    if (!view) return;
    const v = view, kids = [header()];
    if (v.phase === "done") {
      kids.push(donePanel());
    } else if (v.phase === "define") {
      kids.push(h("div.sp-stage",
        h("div.sp-pill.big", `WORD ${v.index + 1} OF ${v.total}`),
        defCard(speller()
          ? h("button.sp-btn", { type: "button", onclick: () => send({ kind: "ready" }) }, "Start spelling")
          : watchNote(`${nameOf()} is reading the definition...`))));
    } else {
      kids.push(h("div.sp-try", v.phase === "spell" ? `Try ${Math.min(v.rows.length + 1, v.maxTries)} of ${v.maxTries}` : ""));
      kids.push(grid());
      if (v.phase === "result") kids.push(resultPanel());
      else if (speller()) kids.push(keyboard());
      else kids.push(watchNote(`Watching ${nameOf()} spell`));
      if (v.showDef && v.phase === "spell") {
        kids.push(h("div.sp-modal", defCard(speller()
          ? h("button.sp-btn", { type: "button", onclick: () => send({ kind: "ready" }) }, "Back to spelling")
          : watchNote(`${nameOf()} is looking at the definition`))));
      }
    }
    root.replaceChildren(...kids);
    freshMiss = false;
  }

  function burst() {
    const colors = ["#FF5CA8", "#7B3FC4", "#FFD9EA", "#15101C", "#FFFFFF"];
    confetti.replaceChildren(...Array.from({ length: 36 }, (_, i) => h("span", {
      style: { left: Math.round(Math.random() * 100) + "%", background: colors[i % colors.length], animationDelay: (Math.random() * 0.4).toFixed(2) + "s", "--dx": Math.round(Math.random() * 120 - 60) + "px" }
    })));
    setTimeout(() => { if (!destroyed) confetti.replaceChildren(); }, 2600);
  }

  // ----- the keyboard on a computer -----
  const typing = () => { const el = document.activeElement; return el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA"); };
  const onKey = (e) => {
    if (destroyed || !view || !speller() || !playing() || typing() || e.ctrlKey || e.metaKey || e.altKey) return;
    if (view.phase === "spell" && !view.showDef) {
      if (/^[a-zA-Z]$/.test(e.key)) { typeLetter(e.key); e.preventDefault(); }
      else if (e.key === "Backspace") { backspace(); e.preventDefault(); }
      else if (e.key === "Enter") { enter(); e.preventDefault(); }
    } else if (e.key === "Enter" || e.key === " ") {
      if (view.phase === "define" || (view.phase === "spell" && view.showDef)) send({ kind: "ready" });
      else if (view.phase === "result") send({ kind: "next" });
      e.preventDefault();
    }
  };
  window.addEventListener("keydown", onKey);

  return {
    update(r) {
      room = r;
      const v = r.view;
      if (!v) return;
      if (r.match !== lastMatch) { lastMatch = r.match; lastEvents = -1; lastWord = -1; lastRows = 0; }
      const fresh = v.events !== lastEvents;
      if (v.index !== lastWord) { lastWord = v.index; lastRows = 0; }
      if (fresh && lastEvents >= 0) {
        if (v.phase === "spell" && v.rows.length > lastRows) { freshMiss = true; snd("card"); }
        if (v.phase === "result" && lastPhase !== "result") {
          if (v.outcome === "correct") { snd("win"); burst(); } else snd("card");
        }
        if (v.phase === "done" && lastPhase !== "done") { snd("win"); if (v.correct === v.total) burst(); }
      }
      lastRows = v.rows.length; lastEvents = v.events; lastPhase = v.phase;
      view = v;
      paint();
    },
    onError(request) { if (request === "move") shakeRow(); },
    seatInfo(seat) { return seat === 0 && view ? `${view.correct} of ${view.total}` : seat === 0 ? "" : "watching"; },
    seatClass(seat) { return seat === 0 && room && room.status === "playing" ? "turn" : ""; },
    banner(r) {
      const v = r.view;
      if (!v || r.status !== "playing") return ["", false];
      if (!speller()) return [`Watching ${nameOf()} spell`, false];
      if (v.phase === "define") return ["Read the definition, then start spelling.", true];
      if (v.phase === "spell") return [v.showDef ? "Here is the definition." : "Spell the word!", true];
      if (v.phase === "result") return [v.outcome === "correct" ? "Good Job Nelly!" : "Good try! On to the next one.", true];
      return ["", false];
    },
    ranking(r) {
      const v = r.view;
      return v ? [{ seat: 0, text: `${v.correct} of ${v.total} spelled right` }] : [];
    },
    destroy() { destroyed = true; window.removeEventListener("keydown", onKey); }
  };
}
