// The cat playing pieces: little glossy plastic cat figures, drawn as SVG (no image files).
export const CATS = {
  tabby:   { name: "Hank", fur: "#F2993A", furDark: "#C9701F", belly: "#FFE0B5", eye: "#5BBF5B", base: "#F2993A", style: "tabby" },
  tuxedo:  { name: "Oreo",         fur: "#2D2D38", furDark: "#16161d", belly: "#FFFFFF", eye: "#E6C84A", base: "#3C3C4C", style: "tuxedo" },
  siamese: { name: "Benson",      fur: "#F1E2C6", furDark: "#5B3E33", belly: "#FFF6E4", eye: "#4EA8F0", base: "#D9C29B", style: "siamese" },
  calico:  { name: "Theo",      fur: "#FFFFFF", furDark: "#E58A2B", belly: "#FFFFFF", eye: "#D9A441", base: "#F5F1EA", style: "calico" },
  gray:    { name: "Smokey",       fur: "#8E96A6", furDark: "#626B7C", belly: "#D5D9E2", eye: "#E0B93C", base: "#8E96A6", style: "tabby" },
  fluffy:  { name: "Winnie", fur: "#9A6A43", furDark: "#6E4527", belly: "#E0BD93", eye: "#E0A93C", base: "#9A6A43", style: "fluffy" },
  black:   { name: "Shadow",       fur: "#26262E", furDark: "#101015", belly: "#33333E", eye: "#F0D23C", base: "#34343F", style: "plain" }
};
export const CAT_IDS = Object.keys(CATS);
export const catName = (id) => (CATS[id] ? CATS[id].name : "Cat");

let uid = 0;
/** One cat piece as an SVG element string. Taller than wide (60 x 80). */
export function catSVGString(kind) {
  const c = CATS[kind] || CATS.tabby;
  const id = "cp" + (uid++);
  const dark = c.furDark;
  const siamese = c.style === "siamese", tux = c.style === "tuxedo", calico = c.style === "calico", tabby = c.style === "tabby";
  const earOuter = siamese ? dark : c.fur;
  const paw = siamese ? dark : tux ? "#FFFFFF" : c.fur;
  const tail = siamese ? dark : calico ? c.furDark : c.fur;
  const stripes = tabby ? `
    <path d="M30 15 L30 21 M25.5 16.5 L26.5 21 M34.5 16.5 L33.5 21" stroke="${dark}" stroke-width="2" stroke-linecap="round" fill="none"/>
    <path d="M19 52 Q23 50 25 54 M19 59 Q23 57 25 61 M41 52 Q37 50 35 54 M41 59 Q37 57 35 61" stroke="${dark}" stroke-width="2.2" stroke-linecap="round" fill="none"/>` : "";
  const patches = calico ? `
    <ellipse cx="22.5" cy="22" rx="6.5" ry="5.5" fill="${c.furDark}"/>
    <path d="M36 12 L41 8 L42 18 Z" fill="#2B2B33"/>
    <ellipse cx="38" cy="54" rx="6" ry="8" fill="#2B2B33"/>
    <ellipse cx="23" cy="60" rx="4.5" ry="5" fill="${c.furDark}"/>` : "";
  const fluffy = c.style === "fluffy";
  const tuft = (x, y, r, col) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${col}"/>`;
  const fluffBody = fluffy ? [[16.5, 60, 4.6], [14.5, 52, 4.8], [16.5, 44, 4.4], [43.5, 60, 4.6], [45.5, 52, 4.8], [43.5, 44, 4.4], [20, 39.5, 4], [40, 39.5, 4]].map(([x, y, r]) => tuft(x, y, r, c.fur)).join("") : "";
  const fluffHead = fluffy ? Array.from({ length: 13 }, (_, i) => { const a = (Math.PI * (0.02 + i * 0.077)); const side = i % 2 ? 1 : -1; return null; }).join("") : "";
  const ruff = fluffy ? [[16.5, 30, 4.4], [15.5, 36, 4.2], [20, 40, 4.4], [25, 41.5, 4.2], [30, 42, 4.4], [35, 41.5, 4.2], [40, 40, 4.4], [44.5, 36, 4.2], [43.5, 30, 4.4]].map(([x, y, r]) => tuft(x, y, r, c.belly)).join("") : "";
  const chestFluff = fluffy ? `<ellipse cx="30" cy="52" rx="7.5" ry="11" fill="${c.belly}"/>${[[26, 47], [34, 48], [30, 53], [26, 58], [34, 59]].map(([x, y]) => `<path d="M${x - 2.4} ${y} Q${x} ${y + 3.4} ${x + 2.4} ${y}" stroke="${c.fur}" stroke-width="1.1" fill="none" stroke-linecap="round" opacity=".75"/>`).join("")}` : "";
  const tailFluff = fluffy ? [[55, 42, 4.2], [57.5, 48, 4.4], [56.5, 55, 4.2], [51, 60, 4.4], [49, 40, 3.8]].map(([x, y, r]) => tuft(x, y, r, c.fur)).join("") : "";
  const mask = siamese ? `<ellipse cx="30" cy="31" rx="7.5" ry="6" fill="${dark}" opacity=".85"/>` : "";
  const chest = tux ? `<path d="M30 40 C25 46 25 58 30 64 C35 58 35 46 30 40 Z" fill="#FFFFFF"/>` : "";
  const muzzle = tux ? `<ellipse cx="30" cy="33" rx="5.5" ry="4.2" fill="#FFFFFF"/>` : "";
  return `<svg class="cat-piece" viewBox="0 0 60 80" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <defs>
    <radialGradient id="${id}b" cx="35%" cy="25%" r="85%"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".35" stop-color="#fff" stop-opacity=".08"/><stop offset="1" stop-color="#000" stop-opacity=".30"/></radialGradient>
    <linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".45"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
  </defs>
  <ellipse cx="30" cy="74.5" rx="21" ry="4.2" fill="rgba(0,0,0,.30)"/>
  <ellipse cx="30" cy="69" rx="20" ry="6.5" fill="${c.base}"/>
  <ellipse cx="30" cy="69" rx="20" ry="6.5" fill="url(#${id}b)"/>
  <path d="M46 63 C60 62 60 44 51 40" stroke="${tail}" stroke-width="${fluffy ? 10.5 : 6.5}" stroke-linecap="round" fill="none"/>${tailFluff}
  <path d="M46 63 C60 62 60 44 51 40" stroke="url(#${id}s)" stroke-width="2" stroke-linecap="round" fill="none" opacity=".7"/>
  ${fluffBody}
  <path d="M17 67 C14 50 21 37 30 37 C39 37 46 50 43 67 Z" fill="${c.fur}"/>
  ${chest}${chestFluff}${patches}${stripes}
  <path d="M17 67 C14 50 21 37 30 37 C39 37 46 50 43 67 Z" fill="url(#${id}b)"/>
  <ellipse cx="24" cy="66.5" rx="5" ry="3.2" fill="${paw}"/><ellipse cx="36" cy="66.5" rx="5" ry="3.2" fill="${paw}"/>
  <ellipse cx="24" cy="66.5" rx="5" ry="3.2" fill="url(#${id}b)"/><ellipse cx="36" cy="66.5" rx="5" ry="3.2" fill="url(#${id}b)"/>
  <polygon points="17.5,22 18.5,5 30,14.5" fill="${earOuter}"/>${fluffy ? `<path d="M18.5 5 L17.5 1.5 M18.5 5 L21 2 M41.5 5 L42.5 1.5 M41.5 5 L39 2" stroke="${dark}" stroke-width="1.6" stroke-linecap="round"/>` : ""}<polygon points="42.5,22 41.5,5 30,14.5" fill="${earOuter}"/>
  <polygon points="21,19 21.5,9.5 27.5,15.5" fill="#F4A6B4"/><polygon points="39,19 38.5,9.5 32.5,15.5" fill="#F4A6B4"/>
  ${ruff}
  <circle cx="30" cy="27" r="${fluffy ? 15 : 14}" fill="${c.fur}"/>
  ${calico ? `<ellipse cx="22.5" cy="22" rx="6.5" ry="5.5" fill="${c.furDark}"/>` : ""}
  ${mask}${muzzle}${tabby ? `<path d="M30 15 L30 21 M25.5 16.5 L26.5 21 M34.5 16.5 L33.5 21" stroke="${dark}" stroke-width="2" stroke-linecap="round" fill="none"/>` : ""}
  <circle cx="30" cy="27" r="14" fill="url(#${id}b)"/>
  <ellipse cx="24.5" cy="27" rx="2.6" ry="3" fill="${c.eye}"/><ellipse cx="35.5" cy="27" rx="2.6" ry="3" fill="${c.eye}"/>
  <ellipse cx="24.5" cy="27" rx="1.1" ry="2.4" fill="#111"/><ellipse cx="35.5" cy="27" rx="1.1" ry="2.4" fill="#111"/>
  <circle cx="25.2" cy="26" r=".8" fill="#fff"/><circle cx="36.2" cy="26" r=".8" fill="#fff"/>
  <path d="M28.2 31 L31.8 31 L30 33.2 Z" fill="#E98FA0"/>
  <path d="M30 33.2 Q28 36 25.8 34.6 M30 33.2 Q32 36 34.2 34.6" stroke="${tux || siamese ? "#444" : dark}" stroke-width=".9" fill="none" stroke-linecap="round"/>
  <path d="M20 31 L12 29.5 M20 33 L12 34 M40 31 L48 29.5 M40 33 L48 34" stroke="rgba(255,255,255,.7)" stroke-width=".7" stroke-linecap="round"/>
  <ellipse cx="24.5" cy="17.5" rx="5" ry="2.4" transform="rotate(-28 24.5 17.5)" fill="#fff" opacity=".6"/>
  <path d="M21 44 C19 52 19.5 60 21 64" stroke="#fff" stroke-width="2.4" stroke-linecap="round" fill="none" opacity=".35"/>
</svg>`;
}

/** An element holding one cat piece, `px` pixels tall. */
export function catPiece(kind, px = 56) {
  const span = document.createElement("span");
  span.className = "cat-wrap";
  span.style.height = px + "px";
  span.style.width = Math.round(px * 0.75) + "px";
  span.innerHTML = catSVGString(kind);
  return span;
}
