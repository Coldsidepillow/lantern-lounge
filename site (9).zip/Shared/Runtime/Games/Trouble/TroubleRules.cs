using System.Collections.Generic;
using LanternLounge.Core;

namespace LanternLounge.Games.Trouble
{
    /// <summary>
    /// One board map: how many players it seats, how many squares are on the ring, and how far apart the start squares are.
    /// Classic is the square board (4 players, 28 squares). Star is the star-shaped board (5 players, 30 squares).
    /// </summary>
    public sealed class TroubleBoard
    {
        public TroubleBoard(string gameId, string name, int players, int trackLength, int startGap)
        {
            GameId = gameId; Name = name; Players = players; TrackLength = trackLength; StartGap = startGap;
        }

        public string GameId { get; }
        public string Name { get; }
        public int Players { get; }
        /// <summary>Squares on the ring.</summary>
        public int TrackLength { get; }
        /// <summary>Each player's start square is this many squares after the last player's.</summary>
        public int StartGap { get; }
        /// <summary>A peg's progress number for the first square of its own finish lane.</summary>
        public int FinishFirst => TrackLength;
        public int FinishLast => TrackLength + 3;

        public static readonly TroubleBoard Classic = new TroubleBoard("trouble", "Benson", 4, 28, 7);
        public static readonly TroubleBoard Star = new TroubleBoard("trouble-star", "Benson Star", 5, 30, 6);
    }

    /// <summary>
    /// The rules of Trouble. Four pegs each on a ring of squares (the board decides how many players and squares).
    /// A peg's progress: -1 = at home, 0 = on its own start square, 1..TrackLength-1 = further around the ring (clockwise),
    /// TrackLength..TrackLength+3 = the four squares of its own finish lane. Get all four pegs into the finish lane to win.
    /// </summary>
    public static class TroubleRules
    {
        public const int PegsEach = 4;
        public const int Home = -1;
        /// <summary>A 6 gives you another roll.</summary>
        public const int ExitRoll = 6;
        /// <summary>Rolls you get in a turn while all four cats are at home (you need a 1 or a 6 to get one out).</summary>
        public const int HomeTries = 2;
        /// <summary>A 1 or a 6 lets a cat out of home.</summary>
        public static bool IsExitRoll(int die) => die == 1 || die == ExitRoll;

        /// <summary>The die for roll number <paramref name="rollNo"/> of a match: always the same for the same seed.</summary>
        public static int Die(ulong seed, int rollNo)
        {
            var random = new SeededRandom(seed * 37UL + (ulong)rollNo * 6007UL + 29UL);
            random.NextInt(6);   // the first number from a fresh generator is thrown away
            return random.NextInt(6) + 1;
        }

        /// <summary>Which ring square a peg of <paramref name="seat"/> is on at <paramref name="progress"/> (0 to TrackLength-1).</summary>
        public static int TrackIndex(TroubleBoard board, int seat, int progress) => (seat * board.StartGap + progress) % board.TrackLength;

        public static int[] NewPegs(TroubleBoard board)
        {
            var pegs = new int[board.Players * PegsEach];
            for (int i = 0; i < pegs.Length; i++) pegs[i] = Home;
            return pegs;
        }

        public static bool AllHome(int[] pegs, int seat)
        {
            for (int i = 0; i < PegsEach; i++) if (pegs[seat * PegsEach + i] != Home) return false;
            return true;
        }

        public static bool HasWon(TroubleBoard board, int[] pegs, int seat)
        {
            for (int i = 0; i < PegsEach; i++) if (pegs[seat * PegsEach + i] < board.FinishFirst) return false;
            return true;
        }

        /// <summary>Can this peg move <paramref name="die"/> squares? Only a 1 or a 6 gets a peg out; a peg can't land on your own peg or run past the end of the finish lane.</summary>
        public static bool CanMove(TroubleBoard board, int[] pegs, int seat, int peg, int die, out int to)
        {
            to = 0;
            int p = pegs[seat * PegsEach + peg];
            if (p == Home)
            {
                if (!IsExitRoll(die)) return false;
                to = 0;
            }
            else
            {
                to = p + die;
                if (to > board.FinishLast) return false;
            }
            for (int i = 0; i < PegsEach; i++)
                if (i != peg && pegs[seat * PegsEach + i] == to) return false;
            return true;
        }

        public static List<int> LegalPegs(TroubleBoard board, int[] pegs, int seat, int die)
        {
            var list = new List<int>();
            for (int i = 0; i < PegsEach; i++) if (CanMove(board, pegs, seat, i, die, out _)) list.Add(i);
            return list;
        }

        /// <summary>The genuinely different things this die lets you do: pegs still at home are all the same, so only the first one counts.</summary>
        public static List<int> Choices(TroubleBoard board, int[] pegs, int seat, int die)
        {
            var list = new List<int>();
            bool homeCounted = false;
            for (int i = 0; i < PegsEach; i++)
            {
                if (!CanMove(board, pegs, seat, i, die, out _)) continue;
                if (pegs[seat * PegsEach + i] == Home)
                {
                    if (homeCounted) continue;
                    homeCounted = true;
                }
                list.Add(i);
            }
            return list;
        }

        /// <summary>What a move did: where the peg ended up, and whose peg (if any) it knocked back home.</summary>
        public readonly struct Outcome
        {
            public Outcome(int from, int to, int capSeat, int capPeg, int capFrom)
            {
                From = from; To = to; CapSeat = capSeat; CapPeg = capPeg; CapFrom = capFrom;
            }
            public int From { get; }
            public int To { get; }
            /// <summary>-1 when nobody was knocked home.</summary>
            public int CapSeat { get; }
            public int CapPeg { get; }
            /// <summary>The captured peg's progress before it went home.</summary>
            public int CapFrom { get; }
        }

        /// <summary>Moves one peg (the move must be legal) and returns what happened. <paramref name="pegs"/> is changed in place.</summary>
        public static Outcome ApplyMove(TroubleBoard board, int[] pegs, int seat, int peg, int die)
        {
            CanMove(board, pegs, seat, peg, die, out int to);
            int from = pegs[seat * PegsEach + peg];
            pegs[seat * PegsEach + peg] = to;
            int capSeat = -1, capPeg = -1, capFrom = 0;
            if (to < board.TrackLength)
            {
                int square = TrackIndex(board, seat, to);
                for (int o = 0; o < board.Players && capSeat < 0; o++)
                {
                    if (o == seat) continue;
                    for (int j = 0; j < PegsEach; j++)
                    {
                        int q = pegs[o * PegsEach + j];
                        if (q >= 0 && q < board.TrackLength && TrackIndex(board, o, q) == square)
                        {
                            capSeat = o; capPeg = j; capFrom = q;
                            pegs[o * PegsEach + j] = Home;
                            break;
                        }
                    }
                }
            }
            return new Outcome(from, to, capSeat, capPeg, capFrom);
        }

        /// <summary>The peg a sensible player (or a bot, or a timed-out turn) would move: knock someone home, else reach the finish lane, else get out, else push the front runner.</summary>
        public static int PickPeg(TroubleBoard board, int[] pegs, int seat, int die)
        {
            int best = -1, bestScore = int.MinValue;
            foreach (int peg in LegalPegs(board, pegs, seat, die))
            {
                int p = pegs[seat * PegsEach + peg];
                CanMove(board, pegs, seat, peg, die, out int to);
                int score;
                if (WouldCapture(board, pegs, seat, to)) score = 200 + to;
                else if (to >= board.FinishFirst && p < board.FinishFirst) score = 150 + to;
                else if (p == Home) score = 100;
                else score = 10 + p;
                if (score > bestScore) { bestScore = score; best = peg; }
            }
            return best;
        }

        private static bool WouldCapture(TroubleBoard board, int[] pegs, int seat, int to)
        {
            if (to >= board.TrackLength) return false;
            int square = TrackIndex(board, seat, to);
            for (int o = 0; o < board.Players; o++)
            {
                if (o == seat) continue;
                for (int j = 0; j < PegsEach; j++)
                {
                    int q = pegs[o * PegsEach + j];
                    if (q >= 0 && q < board.TrackLength && TrackIndex(board, o, q) == square) return true;
                }
            }
            return false;
        }
    }
}
